from pydantic import BaseSettings
import logging
import json

logger = logging.getLogger(__name__)

class Settings(BaseSettings):
    """Application settings loaded from environment variables with compliance features."""
    # Database Configuration
    database_url: str

    # API Keys for AI Models
    api_key_openai: str
    api_key_groq: str
    api_key_gemini: str
    api_key_ollama: str
    api_key_claude: str
    api_key_xai: str
    api_key_mistral: str
    api_key_perplexity: str
    api_key_hf: str
    api_key_deepseek: str

    # Cloud Provider Credentials
    aws_access_key_id: str
    aws_secret_access_key: str
    cloudflare_api_token: str
    cloudflare_account_id: str
    cloudflare_kv_namespace_id: str

    # Service Configurations
    redis_host: str
    redis_port: int
    redis_password: str
    redis_backup_host: str = "backup-redis.local"
    cerbos_host: str
    temporal_host: str
    neo4j_uri: str
    neo4j_user: str
    neo4j_password: str
    langsmith_api_key: str
    stripe_api_key: str
    stripe_meter_id: str
    umami_url: str
    umami_website_id: str
    encryption_key: str

    # Logging and Feature Flags
    log_level: str = "INFO"
    feature_flags: dict = {"agent_orchestration": True, "rag_pipelines": True}

    # Compliance Settings
    data_retention_days: int = 365  # GDPR/CCPA retention period
    breach_alert_email: str = "ciso@vectordbcloud.com"  # Incident response
    encryption_key_rotation_days: int = 90  # Key rotation interval (SOC 2)
    audit_log_retention_days: int = 730  # 2 years for SOC 2/ISO 27001
    hipaa_enabled: bool = False  # Toggle HIPAA-specific controls
    gdpr_consent_required: bool = True  # GDPR consent enforcement
    backup_frequency_hours: int = 24  # Daily backups for disaster recovery

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    def __post_init__(self):
        logger.info(f"Settings initialized: retention={self.data_retention_days} days, HIPAA={self.hipaa_enabled}")
