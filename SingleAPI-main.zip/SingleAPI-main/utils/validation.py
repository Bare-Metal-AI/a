import logging
from typing import Any

logger = logging.getLogger(__name__)

class Validation:
    """Utility class for data validation."""

    @staticmethod
    def validate_not_empty(value: Any, field_name: str) -> None:
        """Ensure a value is not empty."""
        if not value:
            logger.error(f"Validation failed: {field_name} is empty")
            raise ValueError(f"{field_name} cannot be empty")
        logger.debug(f"Validated {field_name} is not empty")
