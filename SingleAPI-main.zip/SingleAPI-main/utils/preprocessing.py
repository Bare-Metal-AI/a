import logging
import fireducks.pandas as pd  # Updated
import spacy
import faker
from typing import Dict, Any

logger = logging.getLogger(__name__)

class PreprocessingService:
    """Service for preprocessing data with FireDucks."""

    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
        self.faker = faker.Faker()
        logger.info("Initialized PreprocessingService")

    def process_text(self, text: str, normalize: bool = False, anonymize: bool = False) -> str:
        """Process text with normalization and anonymization."""
        try:
            if normalize:
                text = " ".join(text.lower().split())
            if anonymize:
                doc = self.nlp(text)
                for ent in doc.ents:
                    if ent.label_ in ["PERSON", "ORG", "GPE"]:
                        text = text.replace(ent.text, self.faker.name() if ent.label_ == "PERSON" else self.faker.company())
            logger.debug(f"Processed text: {text[:50]}...")
            return text
        except Exception as e:
            logger.error(f"Text processing failed: {e}")
            raise RuntimeError(f"Text processing failed: {e}")

    def process_dataframe(self, data: Dict[str, Any], normalize: bool, anonymize: bool) -> Dict[str, Any]:
        """Process DataFrame data with FireDucks."""
        try:
            df = pd.DataFrame(data["content"])  # FireDucks DataFrame
            if normalize:
                df = df.apply(lambda x: x.str.lower().str.strip() if x.dtype == "object" else x)
            if anonymize:
                for col in df.columns:
                    if df[col].dtype == "object":
                        df[col] = df[col].apply(lambda x: self.faker.name() if isinstance(x, str) and len(x) > 2 else x)
            processed_content = df.to_dict()
            logger.debug(f"Processed DataFrame with {len(df)} rows")
            return {"content": processed_content, "metadata": data["metadata"]}
        except Exception as e:
            logger.error(f"DataFrame processing failed: {e}")
            raise RuntimeError(f"DataFrame processing failed: {e}")
