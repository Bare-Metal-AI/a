# VectorDBCloud Native Agent Framework

## Overview
The `native` agent framework is a lightweight, high-performance solution built into VectorDBCloud, leveraging FireDucks for fast data processing.

## Usage
```bash
curl -X POST "https://api.vectordbcloud.com/v1/agents/create" \
     -H "Authorization: Bearer your-jwt" \
     -H "X-Principal: user1" \
     -d '{"name": "my_agent", "instance_id": "pgvector-123", "collection_name": "data", "model": "gpt4o", "agent_type": "native", "tools": ["search", "analyze"]}'
```

## Tools
**search**: Queries the vector database.

**analyze**: Processes tabular data with FireDucks.

## Features
- Persistent memory via Redis.
- Tool calling with JSON parsing.
- Fast retrieval with FireDucks DataFrames.
