# VectorDBCloud

VectorDBCloud is a high-speed, low-latency, edge-supported AI ecosystem for vector database management, AI integration, and orchestration. Deployed at `https://api.vectordbcloud.com`.

## Features
- **Vector DB Management**: Supports pgvector, chromadb, qdrant, milvus, lancedb, oceanbase, weaviate.
- **AI Integration**: Generative models (GPT-4o, Grok, etc.) and embeddings (OpenAI, Hugging Face).
- **Agent Orchestration**: Multi-agent workflows with frameworks like LangChain, LlamaIndex.
- **Edge Support**: Cloudflare Workers and AWS Lambda@Edge for <10ms latency.
- **E2E Encryption**: Fernet encryption for data security.

## Installation
- **API**: See `deployment.md`.
- **Python SDK**: `pip install vectordbcloud`
- **JS/TS SDK**: `npm install vectordbcloud-js`
- **Go SDK**: `go get github.com/your-org/vectordbcloud-go`
