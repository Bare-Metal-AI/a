addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  const url = new URL(request.url);
  const tenantId = request.headers.get('X-Principal') || 'anonymous';
  const cacheKey = `${tenantId}:${url.pathname}:${url.search}`;

  // Check Cloudflare KV for cached response
  const cache = await VECTODB_KV.get(cacheKey, { type: 'json' });
  if (cache) {
    console.log(`Cache hit for ${cacheKey}`);
    return new Response(JSON.stringify(cache), {
      headers: { 'Content-Type': 'application/json', 'X-Cache': 'HIT' }
    });
  }

  // Forward to origin (API Gateway)
  const originResponse = await fetch(request);
  const responseData = await originResponse.json();

  // Cache in KV for 5 minutes
  await VECTODB_KV.put(cacheKey, JSON.stringify(responseData), { expirationTtl: 300 });
  console.log(`Cache miss for ${cacheKey}, stored in KV`);

  return new Response(JSON.stringify(responseData), {
    headers: { 'Content-Type': 'application/json', 'X-Cache': 'MISS' }
  });
}

export default {
  async fetch(request, env, ctx) {
    return handleRequest(request);
  }
};
