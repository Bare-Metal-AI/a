from .base import AIAdapter
from openai import AsyncOpenAI
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class OpenAIEmbedAdapter(AIAdapter):
    """Adapter for OpenAI embedding models."""

    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.api_key_openai)
        logger.info("Initialized OpenAIEmbed adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """OpenAI embedding adapter does not support generation."""
        logger.error("Generation not supported by OpenAIEmbed adapter")
        raise NotImplementedError("OpenAIEmbed adapter is for embeddings only")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Generate embeddings using OpenAI."""
        try:
            response = await self.client.embeddings.create(
                input=input,
                model="text-embedding-ada-002"
            )
            embeddings = [item.embedding for item in response.data]
            tokens = response.usage.total_tokens
            logger.info(f"Generated embeddings with OpenAI: {tokens} tokens")
            return embeddings if isinstance(input, list) else embeddings[0], tokens
        except Exception as e:
            logger.error(f"OpenAI embedding failed: {e}")
            raise RuntimeError(f"OpenAI embedding failed: {e}")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for OpenAI embeddings (approx $0.0001/M tokens)."""
        cost = tokens * 0.0001 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
