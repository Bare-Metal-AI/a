from .base import AIAdapter
from httpx import AsyncClient
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class PerplexityAdapter(AIAdapter):
    """Adapter for Perplexity AI."""

    def __init__(self):
        self.client = AsyncClient(base_url="https://api.perplexity.ai")
        self.api_key = settings.api_key_perplexity
        logger.info("Initialized Perplexity adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Perplexity."""
        try:
            response = await self.client.post(
                "/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": "mixtral-8x7b-instruct",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": max_tokens,
                    "temperature": temperature
                }
            )
            response.raise_for_status()
            data = response.json()
            output = data["choices"][0]["message"]["content"]
            tokens = data["usage"]["total_tokens"]
            logger.info(f"Generated text with Perplexity: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Perplexity generation failed: {e}")
            raise RuntimeError(f"Perplexity generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Perplexity does not natively support embeddings."""
        logger.error("Embedding not supported by Perplexity")
        raise NotImplementedError("Perplexity does not support embeddings")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Perplexity (approx $0.20/M tokens)."""
        cost = tokens * 0.20 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
