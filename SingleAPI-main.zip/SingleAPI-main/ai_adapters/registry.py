from .base import AIAdapter
from .gpt4o import GPT4oAdapter
from .groq import GroqAdapter
from .deepseek import DeepseekAdapter
from .claude import ClaudeAdapter
from .qwen import QwenAdapter
from .llama import LlamaAdapter
from .mixtral import MixtralAdapter
from .perplexity import PerplexityAdapter
from .openai_embed import OpenAIEmbedAdapter
from .hf_embed import HFEmbedAdapter
from .gemini import GeminiAdapter
from .ollama import OllamaAdapter
from typing import Dict
import logging
import asyncio
from functools import lru_cache

logger = logging.getLogger(__name__)

class AIAdapterRegistry:
    """Registry for AI model adapters with caching."""

    def __init__(self):
        self.adapters: Dict[str, AIAdapter] = {
            "gpt4o": GPT4oAdapter(),
            "groq-llama3-70b": GroqAdapter(),
            "deepseek": DeepseekAdapter(),
            "claude-sonnet": ClaudeAdapter(),
            "qwen": QwenAdapter(),
            "llama": LlamaAdapter(),
            "mixtral": MixtralAdapter(),
            "perplexity": PerplexityAdapter(),
            "openai-ada-002": OpenAIEmbedAdapter(),
            "hf-minilm": HFEmbedAdapter(),
            "gemini": GeminiAdapter(),
            "ollama": OllamaAdapter(),
        }
        logger.info(f"Initialized AI adapter registry with {len(self.adapters)} adapters")

    @lru_cache(maxsize=128)  # Mitigation 6: Cache adapter lookups
    def get(self, model_name: str) -> AIAdapter:
        """Retrieve an adapter by model name with caching."""
        adapter = self.adapters.get(model_name)
        if not adapter:
            logger.error(f"No adapter found for model: {model_name}")
            raise ValueError(f"Unsupported model: {model_name}")
        logger.debug(f"Retrieved adapter for model: {model_name}")
        return adapter

registry = AIAdapterRegistry()
