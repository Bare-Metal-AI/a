from abc import ABC, abstractmethod
from typing import List, Tuple
import logging

logger = logging.getLogger(__name__)

class AIAdapter(ABC):
    """Base class for AI model adapters."""

    @abstractmethod
    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text and return output with token count."""

    @abstractmethod
    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Generate embeddings and return with token count."""

    @abstractmethod
    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost based on token usage."""
