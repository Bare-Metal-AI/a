from .base import AIAdapter
from groq import AsyncGroq
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class GroqAdapter(AIAdapter):
    """Adapter for Groq-hosted models."""

    def __init__(self):
        self.client = AsyncGroq(api_key=settings.api_key_groq)

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Groq's LLaMA model."""
        try:
            response = await self.client.chat.completions.create(
                model="llama3-70b-8192",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
                temperature=temperature
            )
            output = response.choices[0].message.content
            tokens = response.usage.total_tokens if response.usage else len(prompt.split()) + len(output.split())
            logger.info(f"Generated text with Groq: {len(output)} chars, {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Groq generation failed: {e}")
            raise RuntimeError(f"Generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Embedding not supported by Groq natively."""
        logger.error("Embedding not supported by Groq adapter")
        raise NotImplementedError("Groq does not support embeddings")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Groq usage (approximate: $0.1/M tokens)."""
        cost = tokens * 0.0001 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
