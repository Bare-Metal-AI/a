from .base import AIAdapter
from httpx import AsyncClient
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class OllamaAdapter(AIAdapter):
    """Adapter for Ollama local models."""

    def __init__(self, host: str = "http://localhost:11434"):
        self.client = AsyncClient(base_url=host)
        logger.info("Initialized Ollama adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Ollama."""
        try:
            response = await self.client.post(
                "/api/generate",
                json={
                    "model": "llama2",
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature
                }
            )
            response.raise_for_status()
            data = response.json()
            output = data["response"]
            tokens = data.get("total_tokens", len(prompt.split()) + len(output.split()))
            logger.info(f"Generated text with Ollama: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Ollama generation failed: {e}")
            raise RuntimeError(f"Ollama generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Generate embeddings using Ollama."""
        try:
            response = await self.client.post(
                "/api/embeddings",
                json={"model": "llama2", "prompt": input}
            )
            response.raise_for_status()
            data = response.json()
            embeddings = data["embeddings"]
            tokens = len(str(input).split())  # Approximate
            logger.info(f"Generated embeddings with Ollama: {tokens} tokens")
            return embeddings if isinstance(input, list) else embeddings[0], tokens
        except Exception as e:
            logger.error(f"Ollama embedding failed: {e}")
            raise RuntimeError(f"Ollama embedding failed: {e}")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Ollama (local, assume $0)."""
        cost = 0.0
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f} (local)")
        return cost
