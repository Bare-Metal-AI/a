from .base import AIAdapter
from transformers import AutoTokenizer, AutoModel
import torch
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class HFEmbedAdapter(AIAdapter):
    """Adapter for Hugging Face embedding models."""

    def __init__(self):
        self.tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
        self.model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
        logger.info("Initialized HFEmbed adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """HF embedding adapter does not support generation."""
        logger.error("Generation not supported by HFEmbed adapter")
        raise NotImplementedError("HFEmbed adapter is for embeddings only")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Generate embeddings using Hugging Face model."""
        try:
            inputs = self.tokenizer(input, return_tensors="pt", padding=True, truncation=True)
            with torch.no_grad():
                outputs = self.model(**inputs)
            embeddings = outputs.last_hidden_state.mean(dim=1).squeeze().tolist()
            tokens = inputs["input_ids"].numel()
            logger.info(f"Generated embeddings with HF: {tokens} tokens")
            return embeddings if isinstance(input, list) else embeddings, tokens
        except Exception as e:
            logger.error(f"HF embedding failed: {e}")
            raise RuntimeError(f"HF embedding failed: {e}")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for HF embeddings (local, assume $0 for simplicity)."""
        cost = 0.0
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f} (local)")
        return cost
