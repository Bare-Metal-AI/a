from .base import AIAdapter
from anthropic import AsyncAnthropic
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class ClaudeAdapter(AIAdapter):
    """Adapter for Anthropic Claude model."""

    def __init__(self):
        self.client = AsyncAnthropic(api_key=settings.api_key_claude)
        logger.info("Initialized Claude adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Claude."""
        try:
            response = await self.client.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=max_tokens,
                temperature=temperature,
                messages=[{"role": "user", "content": prompt}]
            )
            output = response.content[0].text
            tokens = response.usage.input_tokens + response.usage.output_tokens
            logger.info(f"Generated text with Claude: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Claude generation failed: {e}")
            raise RuntimeError(f"Claude generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Claude does not natively support embeddings."""
        logger.error("Embedding not supported by Claude")
        raise NotImplementedError("Claude does not support embeddings")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Claude (approx $3/M input, $15/M output tokens)."""
        # Simplified: assume 50/50 split
        cost = (tokens / 2 * 3 + tokens / 2 * 15) / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
