from .base import AIAdapter
from httpx import AsyncClient
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class QwenAdapter(AIAdapter):
    """Adapter for Qwen (Alibaba) model via DashScope API."""

    def __init__(self):
        self.client = AsyncClient(base_url="https://dashscope.aliyuncs.com/api/v1")
        self.api_key = settings.api_key_qwen
        logger.info("Initialized Qwen adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Qwen."""
        try:
            response = await self.client.post(
                "/services/aigc/text-generation/generation",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": "qwen-plus",
                    "input": {"prompt": prompt},
                    "parameters": {
                        "max_tokens": max_tokens,
                        "temperature": temperature
                    }
                }
            )
            response.raise_for_status()
            data = response.json()
            output = data["output"]["text"]
            tokens = data["usage"]["total_tokens"]
            logger.info(f"Generated text with Qwen: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Qwen generation failed: {e}")
            raise RuntimeError(f"Qwen generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Qwen does not natively support embeddings via DashScope."""
        logger.error("Embedding not supported by Qwen")
        raise NotImplementedError("Qwen does not support embeddings")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Qwen (approx $0.01/M tokens)."""
        cost = tokens * 0.01 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
