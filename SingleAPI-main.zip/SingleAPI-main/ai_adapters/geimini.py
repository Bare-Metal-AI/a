from .base import AIAdapter
from google.generativeai import GenerativeModel
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class GeminiAdapter(AIAdapter):
    """Adapter for Google Gemini model."""

    def __init__(self):
        self.client = GenerativeModel("gemini-pro", api_key=settings.api_key_gemini)
        logger.info("Initialized Gemini adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Gemini."""
        try:
            response = await self.client.generate_content(
                contents=prompt,
                generation_config={"max_output_tokens": max_tokens, "temperature": temperature}
            )
            output = response.text
            tokens = len(prompt.split()) + len(output.split())  # Approximate
            logger.info(f"Generated text with Gemini: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Gemini generation failed: {e}")
            raise RuntimeError(f"Gemini generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Gemini does not natively support embeddings via this API."""
        logger.error("Embedding not supported by Gemini")
        raise NotImplementedError("Gemini does not support embeddings")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Gemini (approx $0.25/M tokens)."""
        cost = tokens * 0.25 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
