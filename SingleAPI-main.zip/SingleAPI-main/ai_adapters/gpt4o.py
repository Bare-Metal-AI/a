from .base import AIAdapter
from openai import AsyncOpenAI
from config.settings import settings
import tiktoken
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class GPT4oAdapter(AIAdapter):
    """Adapter for OpenAI GPT-4o model."""

    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.api_key_openai)
        self.tokenizer = tiktoken.get_encoding("cl100k_base")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using GPT-4o."""
        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
                temperature=temperature
            )
            output = response.choices[0].message.content
            tokens = response.usage.total_tokens
            logger.info(f"Generated text with GPT-4o: {len(output)} chars, {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"GPT-4o generation failed: {e}")
            raise RuntimeError(f"Generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Generate embeddings using OpenAI's embedding model."""
        try:
            response = await self.client.embeddings.create(
                input=input,
                model="text-embedding-ada-002"
            )
            embeddings = [item.embedding for item in response.data]
            tokens = response.usage.total_tokens
            logger.info(f"Generated embeddings with {len(embeddings)} items, {tokens} tokens")
            return embeddings if isinstance(input, list) else embeddings[0], tokens
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            raise RuntimeError(f"Embedding failed: {e}")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for GPT-4o usage (approximate pricing: $5/M input tokens)."""
        cost = tokens * 0.005 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
