from .base import AIAdapter
from httpx import AsyncClient
from config.settings import settings
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class MixtralAdapter(AIAdapter):
    """Adapter for Mixtral model via Mistral API."""

    def __init__(self):
        self.client = AsyncClient(base_url="https://api.mixtral.ai/v1")
        self.api_key = settings.api_key_mistral
        logger.info("Initialized Mixtral adapter")

    async def generate(self, prompt: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text using Mixtral."""
        try:
            response = await self.client.post(
                "/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": "mixtral-8x7b",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": max_tokens,
                    "temperature": temperature
                }
            )
            response.raise_for_status()
            data = response.json()
            output = data["choices"][0]["message"]["content"]
            tokens = data["usage"]["total_tokens"]
            logger.info(f"Generated text with Mixtral: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Mixtral generation failed: {e}")
            raise RuntimeError(f"Mixtral generation failed: {e}")

    async def embed(self, input: str | List[str]) -> Tuple[List[float] | List[List[float]], int]:
        """Mixtral does not natively support embeddings."""
        logger.error("Embedding not supported by Mixtral")
        raise NotImplementedError("Mixtral does not support embeddings")

    async def estimate_cost(self, tokens: int) -> float:
        """Estimate cost for Mixtral (approx $0.24/M tokens)."""
        cost = tokens * 0.24 / 1_000_000
        logger.debug(f"Estimated cost for {tokens} tokens: ${cost:.6f}")
        return cost
