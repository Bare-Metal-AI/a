# VectorDBCloud JavaScript/TypeScript SDK

## Installation
```bash
npm install vectordbcloud-js
```

## Usage
```javascript
const { VectorDBCloudClient } = require('vectordbcloud-js');
const client = new VectorDBCloudClient('https://api.vectordbcloud.com', 'your-token', 'user1');

client.deployInstance('pgvector', 'aws', 1, 'us-east-1').then(instance => {
    console.log(`Deployed instance: ${instance.instance_id}`);
});
```
