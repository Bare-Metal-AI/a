import axios, { AxiosInstance } from 'axios';

export class VectorDBCloudError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'VectorDBCloudError';
    }
}

export class AuthenticationError extends VectorDBCloudError {
    constructor() {
        super('Invalid credentials');
    }
}

export class PermissionError extends VectorDBCloudError {
    constructor() {
        super('Insufficient permissions');
    }
}

interface AgentTask {
    agent_id: string;
    task: string;
    dependencies?: string[];
}

export class VectorDBCloudClient {
    private client: AxiosInstance;

    constructor(apiUrl: string, token: string, principal: string) {
        this.client = axios.create({
            baseURL: apiUrl,
            headers: {
                'Authorization': `Bearer ${token}`,
                'X-Principal': principal
            }
        });
        console.log(`VectorDBCloudClient initialized for ${apiUrl}`);
    }

    async deployInstance(dbType: string, cloudProvider: string, clusterSize: number = 1, region?: string): Promise<any> {
        const data: any = { db_type: dbType, cloud_provider: cloudProvider, cluster_size: clusterSize };
        if (region) data.region = region;
        return this.request('POST', `/instances/${dbType}`, data);
    }

    async createCollection(instanceId: string, name: string): Promise<any> {
        return this.request('POST', `/collections/${instanceId}`, { name });
    }

    async upsertData(instanceId: string, collectionName: string, data: any[]): Promise<any> {
        return this.request('PUT', `/collections/${instanceId}/${collectionName}/upsert`, { data });
    }

    async fulltextSearch(instanceId: string, collectionName: string, query: string, topK: number = 10, useNlp: boolean = false): Promise<any> {
        return this.request('POST', `/search/${instanceId}/${collectionName}/fulltext`, { query, top_k: topK, use_nlp: useNlp });
    }

    async generate(prompt: string, model: string, maxTokens: number = 100, temperature: number = 0.7): Promise<any> {
        const data = { task: 'generate', generate: { prompt, model, max_tokens: maxTokens, temperature } };
        return this.request('POST', '/ai/', data);
    }

    async embed(input: string | string[], model: string): Promise<any> {
        const data = { task: 'embed', embed: { input, model } };
        return this.request('POST', '/ai/', data);
    }

    async createAgent(name: string, instanceId: string, collectionName: string, model: string, agentType: string = 'langchain', tools?: string[]): Promise<any> {
        const data: any = { name, instance_id: instanceId, collection_name: collectionName, model, agent_type: agentType };
        if (tools) data.tools = tools;
        return this.request('POST', '/agents/create', data);
    }

    async queryAgent(agentId: string, query: string, maxTokens: number = 100, temperature: number = 0.7): Promise<any> {
        const data = { agent_id: agentId, query, max_tokens: maxTokens, temperature };
        return this.request('POST', '/agents/query', data);
    }

    async orchestrateAgents(orchestrationId: string, tasks: AgentTask[]): Promise<any> {
        const data = { orchestration_id: orchestrationId, tasks };
        return this.request('POST', '/orchestration/', data);
    }

    async uploadFile(instanceId: string, collectionName: string, filePath: string, fileType: string, normalize: boolean = false, anonymize: boolean = false, etlPipeline?: string): Promise<any> {
        const formData = new FormData();
        formData.append('file', new Blob([require('fs').readFileSync(filePath)], { type: 'application/octet-stream' }), filePath);
        formData.append('instance_id', instanceId);
        formData.append('collection_name', collectionName);
        formData.append('file_type', fileType);
        formData.append('normalize', normalize.toString());
        formData.append('anonymize', anonymize.toString());
        if (etlPipeline) formData.append('etl_pipeline', etlPipeline);
        return this.request('POST', '/files/upload', formData, { 'Content-Type': 'multipart/form-data' });
    }

    async importExternal(instanceId: string, collectionName: string, sourceType: string, sourceUrl: string, apiKey?: string, normalize: boolean = false, anonymize: boolean = false, etlPipeline?: string): Promise<any> {
        const data: any = { instance_id: instanceId, collection_name: collectionName, source_type: sourceType, source_url: sourceUrl, normalize, anonymize };
        if (apiKey) data.api_key = apiKey;
        if (etlPipeline) data.etl_pipeline = etlPipeline;
        return this.request('POST', '/external/import', data);
    }

    async getUsage(): Promise<any> {
        return this.request('GET', '/monitoring/usage');
    }

    async createRagPipeline(instanceId: string, collectionName: string, model: string, framework: string = 'langchain', maxTokens: number = 100, temperature: number = 0.7): Promise<any> {
        const data = { instance_id: instanceId, collection_name: collectionName, model, framework, max_tokens: maxTokens, temperature };
        return this.request('POST', '/rag/create', data);
    }

    async queryRagPipeline(pipelineId: string, query: string, maxTokens: number = 100, temperature: number = 0.7): Promise<any> {
        const data = { query, max_tokens: maxTokens, temperature };
        return this.request('POST', `/rag/${pipelineId}/query`, data);
    }

    async submitFeedback(userId: string, message: string): Promise<any> {
        const data = { user_id: userId, message };
        return this.request('POST', '/feedback', data);
    }

    async request(method: string, path: string, data?: any, headers?: any): Promise<any> {
        try {
            const config = { method, url: path, data };
            if (headers) config.headers = { ...this.client.defaults.headers, ...headers };
            const resp = await this.client.request(config);
            console.log(`Request ${method} ${path} succeeded`);
            return resp.data;
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                console.error(`Request failed: ${error.response.status} - ${error.response.data.detail}`);
                if (error.response.status === 401) throw new AuthenticationError();
                if (error.response.status === 403) throw new PermissionError();
                throw new VectorDBCloudError(`API error: ${error.response.status} - ${error.response.data.detail}`);
            }
            console.error(`Unexpected request error: ${error}`);
            throw error;
        }
    }
}

export default VectorDBCloudClient;
