```
vectordbcloud/
├── adapters/                    # 8 files
│   ├── __init__.py
│   ├── base.py
│   ├── pgvector.py
│   ├── chromadb.py
│   ├── qdrant.py
│   ├── milvus.py
│   ├── lancedb.py              # Updated: Uses FireDucks
│   ├── oceanbase.py
│   ├── weaviate.py
│   └── neo4j.py
├── ai_adapters/                 # 16 files
│   ├── __init__.py
│   ├── base.py
│   ├── deepseek.py
│   ├── claude.py
│   ├── qwen.py
│   ├── llama.py
│   ├── gpt4o.py
│   ├── grok.py
│   ├── mixtral.py
│   ├── perplexity.py
│   ├── groq.py
│   ├── openai_embed.py
│   ├── hf_embed.py
│   ├── gemini.py
│   ├── ollama.py
│   └── registry.py
├── agent_adapters/              # 14 files (Added native.py)
│   ├── __init__.py
│   ├── base.py
│   ├── langchain.py
│   ├── llamaindex.py
│   ├── jina.py
│   ├── langgraph.py
│   ├── swarm.py
│   ├── metagpt.py
│   ├── copilotkit.py
│   ├── langmem.py
│   ├── composio.py
│   ├── omniparser.py
│   ├── cloudflare.py
│   ├── agno.py
│   ├── mcp.py
│   ├── native.py              # New: Enhanced with FireDucks
│   └── registry.py           # Updated
├── api/                         # 63 files (Added compliance.py)
│   ├── __init__.py
│   ├── main.py               # Updated
│   ├── dependencies.py       # Updated
│   ├── endpoints/
│   │   ├── __init__.py
│   │   ├── instances.py
│   │   ├── collections.py
│   │   ├── search.py
│   │   ├── ai.py
│   │   ├── backup.py
│   │   ├── graph.py
│   │   ├── migration.py
│   │   ├── team.py
│   │   ├── files.py          # Updated: Uses FireDucks
│   │   ├── external.py
│   │   ├── monitoring.py
│   │   ├── ui.py
│   │   ├── agents.py         # Updated
│   │   ├── orchestration.py
│   │   ├── rag.py
│   │   ├── feedback.py
│   │   └── compliance.py     # New
│   ├── middleware/
│   │   ├── __init__.py
│   │   ├── rate_limit.py
│   │   └── throttling.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── instance.py
│   │   ├── collection.py
│   │   ├── search.py
│   │   ├── ai.py
│   │   ├── migration.py
│   │   ├── team.py
│   │   ├── files.py
│   │   ├── external.py
│   │   ├── etl.py
│   │   ├── agents.py
│   │   ├── orchestration.py
│   │   ├── rag.py
│   │   └── feedback.py
│   ├── monitoring/
│   │   ├── __init__.py
│   │   ├── langsmith.py
│   │   ├── cloudwatch.py
│   │   ├── umami.py
│   │   └── stripe.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── embedding.py
│   │   ├── cloud.py
│   │   ├── catalog.py
│   │   ├── graph.py
│   │   ├── migration.py
│   │   ├── team.py
│   │   ├── files.py         # Updated: Uses FireDucks
│   │   ├── external.py
│   │   ├── nlp.py
│   │   ├── ai.py
│   │   ├── security.py
│   │   ├── agents.py        # Updated
│   │   ├── orchestration.py
│   │   ├── rag.py
│   │   ├── cache.py
│   │   ├── auth.py
│   │   ├── compliance.py    # New
│   │   └── feedback.py
│   └── templates/
│       └── dashboard.html
├── cli/                         # 18 files
│   ├── __init__.py
│   ├── main.py
│   ├── instance.py
│   ├── collection.py
│   ├── search.py
│   ├── ai.py
│   ├── backup.py
│   ├── graph.py
│   ├── migration.py
│   ├── team.py
│   ├── files.py
│   ├── external.py
│   ├── etl.py              # Updated: Uses FireDucks
│   ├── agents.py
│   ├── orchestration.py
│   ├── rag.py
│   ├── feedback.py
│   └── util.py
├── config/                      # 2 files
│   ├── __init__.py
│   └── settings.py
├── orchestration/               # 3 files
│   ├── __init__.py
│   ├── workflows.py
│   └── activities.py
├── external_adapters/           # 7 files
│   ├── __init__.py
│   ├── base.py
│   ├── youtube.py
│   ├── salesforce.py
│   ├── sap.py
│   ├── s3.py
│   ├── http.py
│   └── registry.py
├── etl/                         # 7 files
│   ├── __init__.py
│   ├── base.py
│   ├── steps/
│   │   ├── __init__.py
│   │   ├── normalize.py
│   │   ├── anonymize.py
│   │   ├── extract.py       # Updated: Uses FireDucks
│   │   └── load.py
│   └── registry.py
├── utils/                       # 5 files
│   ├── __init__.py
│   ├── validation.py
│   ├── logging.py
│   ├── error_handler.py
│   ├── preprocessing.py    # Updated: Uses FireDucks
│   └── native.md           # New: Docs for native agent
├── cerbos/                      # 7 files
│   ├── __init__.py
│   ├── client.py
│   └── policies/
│       ├── instance.yaml
│       ├── collection.yaml
│       ├── graph.yaml
│       ├── team.yaml
│       └── tiers.yaml
│       └── compliance.yaml
├── tests/                       # 18 files
│   ├── __init__.py
│   ├── test_instances.py
│   ├── test_collections.py
│   ├── test_search.py
│   ├── test_ai.py
│   ├── test_migration.py
│   ├── test_team.py
│   ├── test_files.py
│   ├── test_external.py
│   ├── test_etl.py         # Updated: Tests FireDucks
│   ├── test_agents.py
│   ├── test_orchestration.py
│   ├── test_rag.py
│   ├── test_cache.py
│   ├── test_load.py
│   ├── test_auth.py
│   ├── test_feedback.py
│   ├── test_dr.py
│   └── test_security_scan.py
├── terraform/                   # 15 files
│   ├── main.tf
│   ├── cognito.tf
│   ├── api_gateway.tf
│   ├── variables.tf
│   ├── pgvector.tf
│   ├── chromadb.tf
│   ├── qdrant.tf
│   ├── milvus.tf
│   ├── lancedb.tf
│   ├── oceanbase.tf
│   ├── weaviate.tf
│   ├── neo4j.tf
│   ├── docker_registry.tf
│   ├── redis.tf
│   ├── edge.tf
│   └── cloudflare.tf
├── github/                      # 4 files
│   ├── app.yaml
│   ├── action.yml
│   └── workflows/
│       └── publish.yml
├── lambda/                      # 6 files
│   ├── fetch_image/
│   │   ├── main.py
│   │   └── requirements.txt
│   ├── update_images/
│   │   ├── main.py
│   │   └── requirements.txt
│   └── edge_inference/
│       ├── main.py
│       └── requirements.txt
├── edge/                        # 2 files
│   ├── worker.js
│   └── wrangler.toml
├── extensions/                  # 3 files
│   └── ckan/
│       ├── plugin.py
│       └── templates/
│           └── vectordb.html
├── sdk/                         # 8 files (Updated structure)
│   ├── vectordbcloud/
│   │   ├── __init__.py
│   │   ├── client.py
│   │   ├── exceptions.py
│   │   └── config.py
│   ├── vectordbcloud-agents/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   └── setup.py
│   ├── setup.py
│   ├── README.md
│   └── requirements.txt
├── sdk-js/                      # 4 files
│   ├── src/
│   │   └── index.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── README.md
├── sdk-go/                      # 3 files
│   ├── client.go
│   ├── go.mod
│   └── README.md
├── Dockerfile                   # 1 file
├── .env                         # 1 file
├── requirements.txt             # 1 file (Updated)
├── deployment.md                # 1 file
├── api_docs.md                  # 1 file
├── sdk_docs.md                  # 1 file
├── README.md                    # 1 file
├── sla.md                       # 1 file
├── tutorial.md                  # 1 file
└── CONTRIBUTING.md              # 1 file
```
