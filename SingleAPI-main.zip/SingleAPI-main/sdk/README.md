# VectorDBCloud Python SDK

## Installation
```bash
pip install vectordbcloud
```

## Usage
```python
from vectordbcloud import VectorDBCloudClient
import asyncio

async def main():
    client = VectorDBCloudClient("https://api.vectordbcloud.com", "your-token", "user1")
    instance = await client.deploy_instance("pgvector", "aws")
    print(await client.create_collection(instance["instance_id"], "my_collection"))
    await client.close()

asyncio.run(main())
```
