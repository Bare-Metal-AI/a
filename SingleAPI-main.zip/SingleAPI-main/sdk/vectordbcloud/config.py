import yaml
import os
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

def load_config(config_file: str) -> Dict[str, Any]:
    """Load configuration from a YAML file."""
    config_path = os.path.expanduser(config_file)
    try:
        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                config = yaml.safe_load(f) or {}
                logger.info(f"Loaded config from {config_path}")
                return config
        logger.debug(f"No config file found at {config_path}, using defaults")
        return {}
    except Exception as e:
        logger.error(f"Failed to load config from {config_path}: {e}")
        return {}
