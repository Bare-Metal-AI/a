import logging

logger = logging.getLogger(__name__)

class VectorDBCloudError(Exception):
    """Base exception for VectorDBCloud SDK errors."""
    def __init__(self, message: str):
        super().__init__(message)
        logger.error(f"VectorDBCloudError: {message}")

class AuthenticationError(VectorDBCloudError):
    """Exception for authentication failures."""
    def __init__(self, message: str = "Invalid credentials"):
        super().__init__(message)

class PermissionError(VectorDBCloudError):
    """Exception for permission denials."""
    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(message)
