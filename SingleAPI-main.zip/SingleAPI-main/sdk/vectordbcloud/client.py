import httpx
import logging
import os
import asyncio
from typing import Union, List, Dict, Any, Optional
from .exceptions import VectorDBCloudError, AuthenticationError, PermissionError
from .config import load_config

logger = logging.getLogger(__name__)

class VectorDBCloudClient:
    """Python SDK client for VectorDBCloud API."""

    def __init__(self, api_url: str, token: Optional[str] = None, principal: Optional[str] = None, config_file: str = "~/.vectordbcloud/config.yaml"):
        self.api_url = api_url.rstrip("/")
        config = load_config(config_file)
        self.token = token or config.get("token") or os.getenv("VECTORDBCLOUD_TOKEN")
        self.principal = principal or config.get("principal") or os.getenv("VECTORDBCLOUD_PRINCIPAL")
        if not self.token or not self.principal:
            logger.error("Token and principal are required for SDK initialization")
            raise AuthenticationError("Token and principal are required")
        self.headers = {"Authorization": f"Bearer {self.token}", "X-Principal": self.principal}
        self.client = httpx.AsyncClient(base_url=self.api_url, headers=self.headers)
        logger.info(f"VectorDBCloudClient initialized for {self.api_url}")

    async def deploy_instance(self, db_type: str, cloud_provider: str, cluster_size: int = 1, region: str = None) -> Dict[str, Any]:
        """Deploy a new instance."""
        data = {"db_type": db_type, "cloud_provider": cloud_provider, "cluster_size": cluster_size}
        if region:
            data["region"] = region
        return await self._request("POST", f"/instances/{db_type}", json=data)

    async def create_collection(self, instance_id: str, name: str) -> Dict[str, Any]:
        """Create a new collection."""
        data = {"name": name}
        return await self._request("POST", f"/collections/{instance_id}", json=data)

    async def upsert_data(self, instance_id: str, collection_name: str, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Upsert data into a collection."""
        return await self._request("PUT", f"/collections/{instance_id}/{collection_name}/upsert", json={"data": data})

    async def fulltext_search(self, instance_id: str, collection_name: str, query: str, top_k: int = 10, use_nlp: bool = False) -> Dict[str, Any]:
        """Perform a full-text search."""
        data = {"query": query, "top_k": top_k, "use_nlp": use_nlp}
        return await self._request("POST", f"/search/{instance_id}/{collection_name}/fulltext", json=data)

    async def generate(self, prompt: str, model: str, max_tokens: int = 100, temperature: float = 0.7) -> Dict[str, Any]:
        """Generate text using an AI model."""
        data = {"task": "generate", "generate": {"prompt": prompt, "model": model, "max_tokens": max_tokens, "temperature": temperature}}
        return await self._request("POST", "/ai/", json=data)

    async def embed(self, input: Union[str, List[str]], model: str) -> Dict[str, Any]:
        """Generate embeddings."""
        data = {"task": "embed", "embed": {"input": input, "model": model}}
        return await self._request("POST", "/ai/", json=data)

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, agent_type: str = "langchain", tools: List[str] = None) -> Dict[str, Any]:
        """Create an AI agent."""
        data = {"name": name, "instance_id": instance_id, "collection_name": collection_name, "model": model, "agent_type": agent_type}
        if tools:
            data["tools"] = tools
        return await self._request("POST", "/agents/create", json=data)

    async def query_agent(self, agent_id: str, query: str, max_tokens: int = 100, temperature: float = 0.7) -> Dict[str, Any]:
        """Query an AI agent."""
        data = {"agent_id": agent_id, "query": query, "max_tokens": max_tokens, "temperature": temperature}
        return await self._request("POST", "/agents/query", json=data)

    async def orchestrate_agents(self, orchestration_id: str, tasks: List[Dict[str, Union[str, List[str]]]]) -> Dict[str, Any]:
        """Orchestrate multiple AI agents."""
        data = {"orchestration_id": orchestration_id, "tasks": tasks}
        return await self._request("POST", "/orchestration/", json=data)

    async def upload_file(self, instance_id: str, collection_name: str, file_path: str, file_type: str, normalize: bool = False, anonymize: bool = False, etl_pipeline: str = None) -> Dict[str, Any]:
        """Upload a file for processing."""
        try:
            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f, "multipart/form-data")}
                params = {
                    "instance_id": instance_id,
                    "collection_name": collection_name,
                    "file_type": file_type,
                    "normalize": str(normalize).lower(),
                    "anonymize": str(anonymize).lower()
                }
                if etl_pipeline:
                    params["etl_pipeline"] = etl_pipeline
                resp = await self.client.post("/files/upload", files=files, params=params)
                self._handle_response(resp)
                result = resp.json()
                logger.info(f"Uploaded file {file_path} with response: {result}")
                return result
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            raise VectorDBCloudError(f"File upload failed: {e}")

    async def import_external(self, instance_id: str, collection_name: str, source_type: str, source_url: str, api_key: str = None, normalize: bool = False, anonymize: bool = False, etl_pipeline: str = None) -> Dict[str, Any]:
        """Import data from an external source."""
        data = {
            "instance_id": instance_id,
            "collection_name": collection_name,
            "source_type": source_type,
            "source_url": source_url,
            "normalize": normalize,
            "anonymize": anonymize
        }
        if api_key:
            data["api_key"] = api_key
        if etl_pipeline:
            data["etl_pipeline"] = etl_pipeline
        return await self._request("POST", "/external/import", json=data)

    async def get_usage(self) -> Dict[str, Any]:
        """Retrieve usage metrics."""
        return await self._request("GET", "/monitoring/usage")

    async def create_rag_pipeline(self, instance_id: str, collection_name: str, model: str, framework: str = "langchain", max_tokens: int = 100, temperature: float = 0.7) -> Dict[str, Any]:
        """Create a RAG pipeline."""
        data = {
            "instance_id": instance_id,
            "collection_name": collection_name,
            "model": model,
            "framework": framework,
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        return await self._request("POST", "/rag/create", json=data)

    async def query_rag_pipeline(self, pipeline_id: str, query: str, max_tokens: int = 100, temperature: float = 0.7) -> Dict[str, Any]:
        """Query a RAG pipeline."""
        data = {"query": query, "max_tokens": max_tokens, "temperature": temperature}
        return await self._request("POST", f"/rag/{pipeline_id}/query", json=data)

    async def submit_feedback(self, user_id: str, message: str) -> Dict[str, Any]:
        """Submit user feedback."""
        data = {"user_id": user_id, "message": message}
        return await self._request("POST", "/feedback", json=data)

    async def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        """Make an HTTP request to the API."""
        try:
            resp = await getattr(self.client, method.lower())(path, **kwargs)
            self._handle_response(resp)
            result = resp.json()
            logger.debug(f"API {method} request to {path} succeeded: {result}")
            return result
        except Exception as e:
            logger.error(f"API request failed: {e}")
            raise VectorDBCloudError(f"API request failed: {e}")

    def _handle_response(self, resp: httpx.Response):
        """Handle API response status codes."""
        if resp.status_code == 401:
            logger.error("Authentication error in API request")
            raise AuthenticationError("Invalid credentials")
        elif resp.status_code == 403:
            logger.error("Permission error in API request")
            raise PermissionError("Insufficient permissions")
        elif resp.status_code != 200:
            logger.error(f"API error: {resp.status_code} - {resp.text}")
            raise VectorDBCloudError(f"API error: {resp.status_code} - {resp.text}")

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
        logger.info("VectorDBCloudClient closed")
