# VectorDBCloud SDK Documentation

## Overview
SDKs provide programmatic access to `https://api.vectordbcloud.com`.

## Python SDK
- **Install**: `pip install vectordbcloud`
- **Source**: [GitHub](https://github.com/VectorDBCloud/vectordbcloud-python)
- **Usage**:
  ```python
  from vectordbcloud import VectorDBCloudClient
  import asyncio

  async def main():
      client = VectorDBCloudClient("https://api.vectordbcloud.com", "your-token", "user1")
      # Deploy instance
      instance = await client.deploy_instance("pgvector", "aws", 1, "us-east-1")
      print(instance)
      # Create agent
      agent_id = await client.create_agent("my_agent", instance["instance_id"], "coll", "gpt4o", "langchain")
      print(await client.query_agent(agent_id, "What’s AI?"))
      await client.close()

  asyncio.run(main())
  ```

## JavaScript/TypeScript SDK

- Install: `npm install vectordbcloud-js`
- Source: GitHub
- Usage:
```javascript
const { VectorDBCloudClient } = require('vectordbcloud-js');
const client = new VectorDBCloudClient('https://api.vectordbcloud.com', 'your-token', 'user1');
client.deployInstance('pgvector', 'aws', 1, 'us-east-1').then(instance => {
    client.createAgent('my_agent', instance.instance_id, 'coll', 'gpt4o', 'langchain').then(agent => {
        client.queryAgent(agent.agent_id, 'What’s AI?').then(console.log);
    });
});
```

## Go SDK

- Install: `go get github.com/your-org/vectordbcloud-go`
- Source: GitHub
- Usage:
```go
package main

import "github.com/your-org/vectordbcloud-go"

func main() {
    client := vectordbcloud.NewClient("https://api.vectordbcloud.com", "your-token", "user1")
    instance, _ := client.DeployInstance("pgvector", "aws", 1, "us-east-1")
    agentID, _ := client.CreateAgent("my_agent", instance.InstanceID, "coll", "gpt4o", "langchain", nil)
    response, _ := client.QueryAgent(agentID, "What’s AI?", 100, 0.7)
    fmt.Println(response)
}
```
