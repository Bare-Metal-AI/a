import unittest
import asyncio
from api.endpoints.external import import_external
from api.models.external import ExternalImportRequest, ExternalImportResponse
from fastapi import HTTPException

class TestExternal(unittest.TestCase):
    def test_import_external_success(self):
        """Test successful external data import."""
        async def run_test():
            request = ExternalImportRequest(
                instance_id="test_instance",
                collection_name="test_collection",
                source_type="youtube",
                source_url="https://youtube.com/watch?v=xyz",
                api_key="test_key"
            )
            result = await import_external(request, principal="user1", external_service=MockExternalService())
            self.assertIsInstance(result, ExternalImportResponse)
            self.assertEqual(result.records, 1)

        asyncio.run(run_test())

class MockExternalService:
    async def import_data(self, instance_id, collection_name, source_type, source_url, api_key):
        return 1

if __name__ == "__main__":
    unittest.main()
