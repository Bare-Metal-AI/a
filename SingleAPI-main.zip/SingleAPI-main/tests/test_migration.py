import unittest
import asyncio
from api.endpoints.migration import copy_data
from api.models.migration import MigrationRequest, MigrationResponse
from fastapi import HTTPException

class TestMigration(unittest.TestCase):
    def test_copy_data_success(self):
        """Test successful data migration."""
        async def run_test():
            request = MigrationRequest(
                source_instance_id="src_instance",
                source_collection="src_coll",
                target_instance_id="tgt_instance",
                target_collection="tgt_coll"
            )
            result = await copy_data(request, principal="user1", client=MockTemporalClient())
            self.assertIsInstance(result, MigrationResponse)
            self.assertIn("Migrated", result.message)

        asyncio.run(run_test())

class MockTemporalClient:
    async def start_workflow(self, workflow, params, id, task_queue):
        return f"Migrated from {params['source_instance_id']}/{params['source_collection']} to {params['target_instance_id']}/{params['target_collection']}"

if __name__ == "__main__":
    unittest.main()
