import unittest
from api.services.auth import AuthService

class TestAuth(unittest.TestCase):
    def test_generate_validate_token(self):
        """Test token generation and validation."""
        auth_service = AuthService()
        token = auth_service.generate_token("user1", "sme")
        payload = auth_service.validate_token(token)
        self.assertEqual(payload["user_id"], "user1")
        self.assertEqual(payload["role"], "sme")

if __name__ == "__main__":
    unittest.main()
