import unittest
import asyncio
from orchestration.workflows import DisasterRecoveryTestWorkflow, get_temporal_client

class TestDisasterRecovery(unittest.TestCase):
    def test_dr_workflow(self):
        """Test disaster recovery workflow."""
        async def run_test():
            client = await get_temporal_client()
            result = await client.execute_workflow(
                DisasterRecoveryTestWorkflow.run,
                {"instance_id": "pgvector-123"},
                id="dr-test-123",
                task_queue="backup-queue"
            )
            self.assertEqual(result["instance_id"], "pgvector-123")
            self.assertEqual(result["status"], "recovered")

        asyncio.run(run_test())

if __name__ == "__main__":
    unittest.main()
