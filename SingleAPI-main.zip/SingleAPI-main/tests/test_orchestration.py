import unittest
import asyncio
from api.endpoints.orchestration import orchestrate_agents
from api.models.orchestration import OrchestrationRequest, AgentTask, OrchestrationResponse
from fastapi import HTTPException

class TestOrchestration(unittest.TestCase):
    def test_orchestrate_agents_success(self):
        """Test successful agent orchestration."""
        async def run_test():
            request = OrchestrationRequest(
                orchestration_id="workflow1",
                tasks=[AgentTask(agent_id="agent1", task="Summarize")]
            )
            result = await orchestrate_agents(request, principal="user1", orchestration_service=MockOrchestrationService(), cache=MockCache())
            self.assertIsInstance(result, OrchestrationResponse)
            self.assertEqual(result.orchestration_id, "workflow1")

        asyncio.run(run_test())

class MockOrchestrationService:
    async def orchestrate_agents(self, request):
        return {"orchestration_id": request.orchestration_id, "results": {"agent1": "Summary"}, "total_tokens": 50, "total_cost_usd": 0.00025}

class MockCache:
    async def get(self, key, tenant_id):
        return None
    async def set(self, key, tenant_id, value, ttl):
        pass

if __name__ == "__main__":
    unittest.main()
