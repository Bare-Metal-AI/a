import unittest
import asyncio
from api.endpoints.files import upload_file
from api.models.files import FileUploadResponse
from fastapi import HTTPException

class TestFiles(unittest.TestCase):
    def test_upload_file_success(self):
        """Test successful file upload."""
        async def run_test():
            class MockUploadFile:
                async def read(self):
                    return b"test content"
                filename = "test.pdf"
            
            result = await upload_file(
                instance_id="test_instance",
                collection_name="test_collection",
                file_type="pdf",
                file=MockUploadFile(),
                normalize=False,
                anonymize=False,
                principal="user1",
                file_service=MockFileService()
            )
            self.assertIsInstance(result, FileUploadResponse)
            self.assertEqual(result.status, "uploaded")

        asyncio.run(run_test())

class MockFileService:
    async def process_file(self, instance_id, collection_name, file_type, file_content, normalize, anonymize, etl_pipeline):
        return "file-123"

if __name__ == "__main__":
    unittest.main()
