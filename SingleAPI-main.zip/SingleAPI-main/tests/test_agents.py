import unittest
import asyncio
from api.endpoints.agents import create_agent, query_agent
from api.models.agents import AgentCreateRequest, AgentQueryRequest, AgentResponse
from fastapi import HTTPException

class TestAgents(unittest.TestCase):
    def test_create_agent_success(self):
        """Test successful agent creation."""
        async def run_test():
            request = AgentCreateRequest(
                name="test_agent",
                instance_id="test_instance",
                collection_name="test_collection",
                model="gpt4o",
                agent_type="langchain"
            )
            result = await create_agent(request, principal="user1", agent_service=MockAgentService(), cache=MockCache())
            self.assertEqual(result["agent_id"], "langchain-test_agent-test_instance")

        asyncio.run(run_test())

    def test_query_agent_success(self):
        """Test successful agent query."""
        async def run_test():
            request = AgentQueryRequest(agent_id="langchain-test_agent-test_instance", query="What’s AI?")
            result = await query_agent(request, principal="user1", agent_service=MockAgentService(), cache=MockCache())
            self.assertIsInstance(result, AgentResponse)
            self.assertEqual(result.response, "AI is...")

        asyncio.run(run_test())

class MockAgentService:
    async def create_agent(self, name, instance_id, collection_name, model, agent_type, tools):
        return f"{agent_type}-{name}-{instance_id}"
    async def query_agent(self, agent_id, query, max_tokens, temperature):
        return "AI is...", 10, 0.0001

class MockCache:
    async def get(self, key, tenant_id):
        return None
    async def set(self, key, tenant_id, value, ttl):
        pass

if __name__ == "__main__":
    unittest.main()
