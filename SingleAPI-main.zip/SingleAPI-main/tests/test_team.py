import unittest
import asyncio
from api.endpoints.team import create_team
from api.models.team import TeamCreateRequest, TeamResponse
from fastapi import HTTPException

class TestTeam(unittest.TestCase):
    def test_create_team_success(self):
        """Test successful team creation."""
        async def run_test():
            request = TeamCreateRequest(team_name="TestTeam", members=["user1", "user2"])
            result = await create_team(request, principal="user1", team_service=MockTeamService())
            self.assertIsInstance(result, TeamResponse)
            self.assertTrue(result.team_id.startswith("team-"))

        asyncio.run(run_test())

class MockTeamService:
    async def create_team(self, team_name, members):
        return "team-123"

if __name__ == "__main__":
    unittest.main()
