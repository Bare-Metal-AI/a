import unittest
import asyncio
from api.endpoints.search import fulltext_search
from api.models.search import SearchRequest, SearchResponse
from fastapi import HTTPException

class TestSearch(unittest.TestCase):
    def test_fulltext_search_success(self):
        """Test successful full-text search."""
        async def run_test():
            request = SearchRequest(query="test", top_k=5, use_nlp=False)
            result = await fulltext_search("test_instance", "test_collection", request, principal="user1", adapter=MockAdapter(), cache=MockCache())
            self.assertIsInstance(result, SearchResponse)
            self.assertEqual(len(result.results), 1)

        asyncio.run(run_test())

class MockAdapter:
    async def search(self, instance_id, collection_name, query_vector, limit):
        return [{"id": "1", "vector": [0.1] * 1536, "metadata": {}, "similarity": 0.95}]

class MockCache:
    async def get(self, key, tenant_id):
        return None
    async def set(self, key, tenant_id, value, ttl):
        pass

if __name__ == "__main__":
    unittest.main()
