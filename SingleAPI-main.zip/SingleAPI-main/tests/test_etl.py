import unittest
import asyncio
from etl.steps.extract import ExtractStep
import os

class TestETL(unittest.TestCase):
    def setUp(self):
        self.extract_step = ExtractStep()

    def test_extract_csv(self):
        """Test CSV extraction with FireDucks."""
        async def run_test():
            with open("test.csv", "w") as f:
                f.write("col1,col2\n1,2")
            result = await self.extract_step.extract("test.csv", "csv")
            self.assertIn("content", result)
            self.assertIn("metadata", result)
            os.remove("test.csv")
        asyncio.run(run_test())

if __name__ == "__main__":
    unittest.main()
