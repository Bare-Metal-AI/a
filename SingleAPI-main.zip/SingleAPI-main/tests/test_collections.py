import unittest
import asyncio
from api.endpoints.collections import create_collection
from api.models.collection import CollectionCreateRequest
from fastapi import HTTPException

class TestCollections(unittest.TestCase):
    def test_create_collection_success(self):
        """Test successful collection creation."""
        async def run_test():
            request = CollectionCreateRequest(name="test_collection")
            result = await create_collection("test_instance", request, principal="user1", adapter=MockAdapter())
            self.assertEqual(result.status, "created")
            self.assertEqual(result.collection_name, "test_collection")

        asyncio.run(run_test())

class MockAdapter:
    async def create_collection(self, instance_id, collection_name):
        pass

if __name__ == "__main__":
    unittest.main()
