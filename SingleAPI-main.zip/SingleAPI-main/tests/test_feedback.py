import unittest
import asyncio
from api.endpoints.feedback import submit_feedback
from api.models.feedback import FeedbackRequest, FeedbackResponse
from fastapi import HTTPException

class TestFeedback(unittest.TestCase):
    def test_submit_feedback_success(self):
        """Test successful feedback submission."""
        async def run_test():
            request = FeedbackRequest(user_id="user1", message="Great service!")
            result = await submit_feedback(request, principal="user1", feedback_service=MockFeedbackService())
            self.assertIsInstance(result, FeedbackResponse)
            self.assertEqual(result.status, "success")

        asyncio.run(run_test())

class MockFeedbackService:
    async def submit_feedback(self, user_id, message):
        pass

if __name__ == "__main__":
    unittest.main()
