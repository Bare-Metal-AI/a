import unittest
import asyncio
from api.endpoints.instances import deploy_instance
from api.models.instance import InstanceCreateRequest
from fastapi import HTTPException

class TestInstances(unittest.TestCase):
    def test_deploy_instance_success(self):
        """Test successful instance deployment."""
        async def run_test():
            request = InstanceCreateRequest(db_type="pgvector", cloud_provider="aws", cluster_size=1, region="us-east-1")
            result = await deploy_instance("pgvector", request, principal="user1", cloud_service=MockCloudService())
            self.assertEqual(result.instance_id, "pgvector-123")
            self.assertEqual(result.status, "running")

        asyncio.run(run_test())

    def test_deploy_instance_mismatch(self):
        """Test DB type mismatch."""
        async def run_test():
            request = InstanceCreateRequest(db_type="chromadb", cloud_provider="aws")
            with self.assertRaises(HTTPException) as cm:
                await deploy_instance("pgvector", request, principal="user1", cloud_service=MockCloudService())
            self.assertEqual(cm.exception.status_code, 400)

        asyncio.run(run_test())

class MockCloudService:
    async def deploy_instance(self, config):
        return "pgvector-123"

if __name__ == "__main__":
    unittest.main()
