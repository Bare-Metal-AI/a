import requests
import logging
from urllib.parse import urljoin

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class SecurityScan:
    """Basic security scan for VectorDBCloud API."""

    def __init__(self, base_url: str = "https://api.vectordbcloud.com/v1"):
        self.base_url = base_url
        self.token = "your-cognito-jwt-token"  # Replace with valid token
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "X-Principal": "test-user"
        }

    def test_sql_injection(self):
        """Test for SQL injection vulnerabilities."""
        try:
            payload = "' OR '1'='1"
            response = requests.get(
                urljoin(self.base_url, f"/search/pgvector-123/test/fulltext?query={payload}"),
                headers=self.headers
            )
            if "error" not in response.text.lower():
                logger.warning("Potential SQL injection vulnerability detected")
            else:
                logger.info("SQL injection test passed")
        except Exception as e:
            logger.error(f"SQL injection test failed: {e}")

    def test_xss(self):
        """Test for XSS vulnerabilities."""
        try:
            payload = "<script>alert('xss')</script>"
            response = requests.post(
                urljoin(self.base_url, "/feedback"),
                headers=self.headers,
                json={"user_id": "test", "message": payload}
            )
            if payload in response.text:
                logger.warning("Potential XSS vulnerability detected")
            else:
                logger.info("XSS test passed")
        except Exception as e:
            logger.error(f"XSS test failed: {e}")

    def run(self):
        """Run all security tests."""
        logger.info("Starting security scan...")
        self.test_sql_injection()
        self.test_xss()
        logger.info("Security scan completed")

if __name__ == "__main__":
    scan = SecurityScan()
    scan.run()
