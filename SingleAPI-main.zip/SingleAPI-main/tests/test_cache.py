import unittest
import asyncio
from api.services.cache import CacheService

class TestCache(unittest.TestCase):
    def test_cache_set_get(self):
        """Test cache set and get operations."""
        async def run_test():
            cache = CacheService()
            await cache.connect()
            await cache.set("test_key", "user1", {"value": "test"}, ttl=10)
            result = await cache.get("test_key", "user1")
            self.assertEqual(result["value"], "test")

        asyncio.run(run_test())

if __name__ == "__main__":
    unittest.main()
