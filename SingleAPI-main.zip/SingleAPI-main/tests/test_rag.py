import unittest
import asyncio
from api.endpoints.rag import create_rag_pipeline, query_rag_pipeline
from api.models.rag import RAGPipelineRequest, RAGPipelineResponse, RAGQueryRequest, RAGQueryResponse
from fastapi import HTTPException

class TestRAG(unittest.TestCase):
    def test_create_rag_pipeline_success(self):
        """Test successful RAG pipeline creation."""
        async def run_test():
            request = RAGPipelineRequest(
                instance_id="test_instance",
                collection_name="test_collection",
                model="gpt4o",
                framework="langchain"
            )
            result = await create_rag_pipeline(request, principal="user1", rag_service=MockRAGService(), cache=MockCache())
            self.assertIsInstance(result, RAGPipelineResponse)
            self.assertEqual(result.pipeline_id, "rag-test_instance-test_collection")

        asyncio.run(run_test())

    def test_query_rag_pipeline_success(self):
        """Test successful RAG pipeline query."""
        async def run_test():
            request = RAGQueryRequest(query="What’s AI?")
            result = await query_rag_pipeline("rag-test_instance-test_collection", request, principal="user1", rag_service=MockRAGService(), cache=MockCache())
            self.assertIsInstance(result, RAGQueryResponse)
            self.assertEqual(result.response, "AI is...")

        asyncio.run(run_test())

class MockRAGService:
    async def create_rag_pipeline(self, request):
        return f"rag-{request.instance_id}-{request.collection_name}"
    async def query_rag_pipeline(self, pipeline_id, query, max_tokens, temperature):
        return "AI is...", 10, 0.0001

class MockCache:
    async def get(self, key, tenant_id):
        return None
    async def set(self, key, tenant_id, value, ttl):
        pass

if __name__ == "__main__":
    unittest.main()
