import unittest
import asyncio
from api.endpoints.ai import process_ai
from api.models.ai import AIRequest, AIResponse, GenerateRequest
from fastapi import HTTPException

class TestAI(unittest.TestCase):
    def test_generate_success(self):
        """Test successful text generation."""
        async def run_test():
            request = AIRequest(task="generate", generate=GenerateRequest(prompt="test", model="gpt4o", max_tokens=50, temperature=0.5))
            result = await process_ai(request, principal="user1", ai_service=MockAIService(), cache=MockCache())
            self.assertIsInstance(result, AIResponse)
            self.assertEqual(result.task, "generate")
            self.assertEqual(result.result, "Generated text")

        asyncio.run(run_test())

class MockAIService:
    async def generate(self, prompt, model, max_tokens, temperature):
        return "Generated text", 10
    async def estimate_cost(self, model, tokens):
        return 0.0001

class MockCache:
    async def get(self, key, tenant_id):
        return None
    async def set(self, key, tenant_id, value, ttl):
        pass

if __name__ == "__main__":
    unittest.main()
