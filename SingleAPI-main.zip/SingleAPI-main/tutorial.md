# VectorDBCloud Onboarding Tutorial

## Step 1: Authentication
1. Sign up via AWS Cognito (`aws cognito-idp sign-up --region us-east-1 ...`).
2. Get JWT token: `aws cognito-idp initiate-auth ...`.
3. Set up SDK:
   ```python
   from vectordbcloud import VectorDBCloudClient
   client = VectorDBCloudClient("https://api.vectordbcloud.com", "your-token", "user1")
   ```

## Step 2: Deploy Instance

```bash
vectordbcloud instance deploy pgvector aws --region us-east-1
```

## Step 3: Create Collection

```bash
vectordbcloud collection create pgvector-123 my_collection
```

## Step 4: Upload Data

```bash
vectordbcloud files upload pgvector-123 my_collection data.pdf pdf
```

## Step 5: Query Agent

```bash
vectordbcloud agents create my_agent pgvector-123 my_collection --model gpt4o --type langchain
vectordbcloud agents query langchain-my_agent-pgvector-123 "What’s in the data?"
```
