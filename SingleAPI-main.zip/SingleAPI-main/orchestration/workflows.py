from temporalio import workflow
from api.models.instance import InstanceCreateRequest
from api.models.collection import CollectionData
from api.models.orchestration import OrchestrationRequest
from temporalio.client import Client
from api.services.agents import AgentService
import logging
import asyncio

logger = logging.getLogger(__name__)

async def get_temporal_client() -> Client:
    """Connect to Temporal server."""
    try:
        client = await Client.connect(settings.temporal_host)
        logger.info("Connected to Temporal server")
        return client
    except Exception as e:
        logger.error(f"Failed to connect to Temporal: {e}")
        raise RuntimeError(f"Temporal connection failed: {e}")

@workflow.defn
class DeployWorkflow:
    """Workflow for deploying instances."""
    @workflow.run
    async def run(self, config: dict):
        try:
            instance_id = f"{config['db_type']}-{int(time.time())}"
            logger.info(f"Deploying instance {instance_id} via workflow")
            return {"instance_id": instance_id, "status": "running"}
        except Exception as e:
            logger.error(f"Deploy workflow failed: {e}")
            raise RuntimeError(f"Deploy workflow failed: {e}")

@workflow.defn
class BackupWorkflow:
    """Workflow for creating backups."""
    @workflow.run
    async def run(self, params: dict):
        try:
            instance_id = params["instance_id"]
            collection_name = params.get("collection_name")
            backup_id = f"backup-{instance_id}-{collection_name or 'all'}"
            logger.info(f"Creating backup {backup_id} via workflow")
            return backup_id
        except Exception as e:
            logger.error(f"Backup workflow failed: {e}")
            raise RuntimeError(f"Backup workflow failed: {e}")

@workflow.defn
class MigrationWorkflow:
    """Workflow for migrating data."""
    @workflow.run
    async def run(self, params: dict):
        try:
            source = f"{params['source_instance_id']}/{params['source_collection']}"
            target = f"{params['target_instance_id']}/{params['target_collection']}"
            logger.info(f"Migrating from {source} to {target} via workflow")
            return f"Migrated from {source} to {target}"
        except Exception as e:
            logger.error(f"Migration workflow failed: {e}")
            raise RuntimeError(f"Migration workflow failed: {e}")

@workflow.defn
class AgentOrchestrationWorkflow:
    """Workflow for orchestrating agents."""
    @workflow.run
    async def run(self, params: dict) -> dict:
        try:
            agent_service = AgentService()
            request = OrchestrationRequest(**params)
            results = {}
            total_tokens = 0
            total_cost = 0.0

            for task in request.tasks:
                output, tokens, cost = await agent_service.query_agent(task.agent_id, task.task, 100, 0.7)
                results[task.agent_id] = output
                total_tokens += tokens
                total_cost += cost

            logger.info(f"Orchestration {request.orchestration_id} completed: {total_tokens} tokens")
            return {
                "orchestration_id": request.orchestration_id,
                "results": results,
                "total_tokens": total_tokens,
                "total_cost_usd": total_cost
            }
        except Exception as e:
            logger.error(f"Agent orchestration workflow failed: {e}")
            raise RuntimeError(f"Agent orchestration failed: {e}")

@workflow.defn
class DisasterRecoveryTestWorkflow:
    """Workflow to test disaster recovery."""
    @workflow.run
    async def run(self, params: dict):
        try:
            instance_id = params["instance_id"]
            # Simulate failure and recovery
            logger.info(f"Starting DR test for {instance_id}")
            # Step 1: Simulate failure (e.g., stop primary service)
            # Step 2: Restore from backup
            backup_id = f"backup-{instance_id}-all"
            logger.info(f"Restoring from {backup_id} in secondary region")
            # Step 3: Verify service
            result = {"instance_id": instance_id, "status": "recovered"}
            logger.info(f"DR test completed for {instance_id}")
            return result
        except Exception as e:
            logger.error(f"DR test workflow failed: {e}")
            raise RuntimeError(f"DR test workflow failed: {e}")
