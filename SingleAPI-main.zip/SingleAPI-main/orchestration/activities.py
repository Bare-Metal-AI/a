from temporalio import activity
import logging

logger = logging.getLogger(__name__)

@activity.defn
async def deploy_activity(config: dict):
    """Activity for deploying an instance."""
    logger.info(f"Executing deploy activity for {config['db_type']}")
    return {"instance_id": f"{config['db_type']}-{int(time.time())}", "status": "running"}

@activity.defn
async def backup_activity(params: dict):
    """Activity for creating a backup."""
    logger.info(f"Executing backup activity for {params['instance_id']}")
    return f"backup-{params['instance_id']}-{params.get('collection_name', 'all')}"
