# VectorDBCloud Deployment Guide

## Prerequisites
- AWS CLI (`aws --version`)
- Terraform (`terraform -v`)
- Docker (`docker --version`)
- Python 3.9+ (`python --version`)

## Steps

1. **Clone Repository**
   ```bash
   git clone https://github.com/your-org/vectordbcloud.git
   cd vectordbcloud
   ```

2. **Install Dependencies**
  ```bash
pip install -r requirements.txt
  ```

3. **Configure Environment**
  ```bash
cp .env.example .env
# Edit .env with your credentials
  ```

4. **Build Docker Image**
  ```bash
docker build -t vectordb-api .
  ```

5. **Push to ECR**
  ```bash
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin your-account-id.dkr.ecr.us-east-1.amazonaws.com
docker tag vectordb-api:latest your-account-id.dkr.ecr.us-east-1.amazonaws.com/vectordb-api:latest
docker push your-account-id.dkr.ecr.us-east-1.amazonaws.com/vectordb-api:latest
  ```

6. **Deploy with Terraform**
  ```bash
cd terraform
terraform init
terraform apply -var-file=variables.tfvars
  ```

7. **Verify Deployment**
  ```bash
curl https://api.vectordbcloud.com/v1/
# Expected: {"message": "Welcome to VectorDBCloud API", "version": "1.0.0", "status": "running"}
  ```

## Compliance Notes
**HIPAA**: VectorDBCloud uses AWS services under a Business Associate Agreement (BAA). Ensure your AWS account has a signed BAA (see AWS Artifact). PHI actions are logged in 'compliance.py'.

   
