import typer
from api.services.cloud import CloudService
from adapters.pgvector import PgVectorAdapter
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="collection", help="Manage VectorDBCloud collections.")

@app.command()
def create(
    instance_id: str = typer.Argument(..., help="Instance ID"),
    name: str = typer.Argument(..., help="Collection name")
):
    """Create a new collection."""
    adapter = PgVectorAdapter()
    try:
        asyncio.run(adapter.create_collection(instance_id, name))
        typer.echo(f"Created collection: {name}")
        logger.info(f"CLI created collection {name} for {instance_id}")
    except Exception as e:
        logger.error(f"CLI collection creation failed: {e}")
        typer.echo(f"Error: {e}", err=True)
