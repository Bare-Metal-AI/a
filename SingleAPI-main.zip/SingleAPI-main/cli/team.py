import typer
from api.services.team import TeamService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="team", help="Manage teams in VectorDBCloud.")

@app.command()
def create(
    team_name: str = typer.Argument(..., help="Team name"),
    members: str = typer.Argument(..., help="Comma-separated list of member IDs")
):
    """Create a new team."""
    team_service = TeamService()
    try:
        member_list = members.split(",")
        team_id = asyncio.run(team_service.create_team(team_name, member_list))
        typer.echo(f"Created team: {team_id}")
        logger.info(f"CLI created team {team_id}")
    except Exception as e:
        logger.error(f"CLI team creation failed: {e}")
        typer.echo(f"Error: {e}", err=True)
