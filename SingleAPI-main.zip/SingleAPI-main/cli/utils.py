import httpx
import logging
import json

logger = logging.getLogger(__name__)

async def api_request(url: str, method: str, data: dict = None) -> dict:
    """Utility function to make API requests."""
    async with httpx.AsyncClient() as client:
        try:
            if method.upper() == "POST":
                response = await client.post(url, json=data)
            elif method.upper() == "GET":
                response = await client.get(url, params=data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            response.raise_for_status()
            logger.debug(f"API request to {url} succeeded")
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"API request failed: {e.response.text}")
            raise RuntimeError(f"API request failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected API request error: {e}")
            raise RuntimeError(f"API request error: {e}")
