import typer
from api.services.orchestration import OrchestrationService
from api.models.orchestration import AgentTask, OrchestrationRequest
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="orchestration", help="Manage agent orchestration in VectorDBCloud.")

@app.command()
def run(
    orchestration_id: str = typer.Argument(..., help="Orchestration ID"),
    tasks: str = typer.Argument(..., help="Comma-separated tasks (agent_id:task[:dependencies])")
):
    """Run an orchestration workflow."""
    orchestration_service = OrchestrationService()
    try:
        task_list = []
        for task_str in tasks.split(","):
            parts = task_str.split(":")
            agent_id, task = parts[0], parts[1]
            dependencies = parts[2].split("|") if len(parts) > 2 else []
            task_list.append(AgentTask(agent_id=agent_id, task=task, dependencies=dependencies))
        request = OrchestrationRequest(orchestration_id=orchestration_id, tasks=task_list)
        result = asyncio.run(orchestration_service.orchestrate_agents(request))
        typer.echo(f"Orchestration results: {result}")
        logger.info(f"CLI ran orchestration {orchestration_id}")
    except Exception as e:
        logger.error(f"CLI orchestration failed: {e}")
        typer.echo(f"Error: {e}", err=True)
