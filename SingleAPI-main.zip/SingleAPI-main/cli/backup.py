import typer
from orchestration.workflows import BackupWorkflow, get_temporal_client
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="backup", help="Manage backups in VectorDBCloud.")

@app.command()
def create(
    instance_id: str = typer.Argument(..., help="Instance ID"),
    collection_name: str = typer.Option(None, "--collection", help="Collection name (optional)")
):
    """Create a backup."""
    try:
        client = asyncio.run(get_temporal_client())
        workflow_id = f"backup-{instance_id}-{collection_name or 'all'}"
        result = asyncio.run(client.start_workflow(
            BackupWorkflow.run,
            {"instance_id": instance_id, "collection_name": collection_name},
            id=workflow_id,
            task_queue="backup-queue"
        ))
        typer.echo(f"Backup started: {result}")
        logger.info(f"CLI started backup {result}")
    except Exception as e:
        logger.error(f"CLI backup failed: {e}")
        typer.echo(f"Error: {e}", err=True)
