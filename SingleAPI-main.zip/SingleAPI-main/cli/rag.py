import typer
from api.services.rag import RAGService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="rag", help="Manage RAG pipelines in VectorDBCloud.")

@app.command()
def create(
    instance_id: str = typer.Argument(..., help="Instance ID"),
    collection_name: str = typer.Argument(..., help="Collection name"),
    model: str = typer.Option("gpt4o", "--model", help="AI model"),
    framework: str = typer.Option("langchain", "--framework", help="Framework (e.g., langchain)")
):
    """Create a RAG pipeline."""
    rag_service = RAGService()
    try:
        pipeline_id = asyncio.run(rag_service.create_rag_pipeline(RAGPipelineRequest(
            instance_id=instance_id,
            collection_name=collection_name,
            model=model,
            framework=framework
        )))
        typer.echo(f"Created RAG pipeline: {pipeline_id}")
        logger.info(f"CLI created RAG pipeline {pipeline_id}")
    except Exception as e:
        logger.error(f"CLI RAG creation failed: {e}")
        typer.echo(f"Error: {e}", err=True)

@app.command()
def query(
    pipeline_id: str = typer.Argument(..., help="Pipeline ID"),
    query: str = typer.Argument(..., help="Query text"),
    max_tokens: int = typer.Option(100, "--max-tokens", help="Max tokens"),
    temperature: float = typer.Option(0.7, "--temp", help="Temperature")
):
    """Query a RAG pipeline."""
    rag_service = RAGService()
    try:
        output, tokens, cost = asyncio.run(rag_service.query_rag_pipeline(pipeline_id, query, max_tokens, temperature))
        typer.echo(f"Response: {output}\nTokens: {tokens}\nCost: ${cost:.6f}")
        logger.info(f"CLI queried RAG pipeline {pipeline_id}: {tokens} tokens")
    except Exception as e:
        logger.error(f"CLI RAG query failed: {e}")
        typer.echo(f"Error: {e}", err=True)
