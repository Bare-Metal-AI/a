import typer
from api.services.graph import GraphService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="graph", help="Manage graph operations in VectorDBCloud.")

@app.command()
def create_node(
    node_id: str = typer.Argument(..., help="Node ID"),
    properties: str = typer.Argument(..., help="JSON string of properties (e.g., '{\"name\": \"Node1\"}')")
):
    """Create a graph node."""
    graph_service = GraphService()
    try:
        import json
        props = json.loads(properties)
        node_id = asyncio.run(graph_service.create_node(node_id, props))
        typer.echo(f"Created node: {node_id}")
        logger.info(f"CLI created node {node_id}")
    except Exception as e:
        logger.error(f"CLI node creation failed: {e}")
        typer.echo(f"Error: {e}", err=True)
