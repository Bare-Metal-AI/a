import typer
from etl.registry import registry as etl_registry
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="etl", help="Manage ETL pipelines in VectorDBCloud.")

@app.command()
def run(
    pipeline_name: str = typer.Argument(..., help="ETL pipeline name (e.g., normalize)"),
    data: str = typer.Argument(..., help="JSON string of data to process")
):
    """Run an ETL pipeline on provided data."""
    try:
        import json
        pipeline = etl_registry.get(pipeline_name)
        if not pipeline:
            raise ValueError(f"Unknown ETL pipeline: {pipeline_name}")
        processed_data = asyncio.run(pipeline.process(json.loads(data)))
        typer.echo(f"Processed data: {processed_data}")
        logger.info(f"CLI ran ETL pipeline {pipeline_name}")
    except Exception as e:
        logger.error(f"CLI ETL run failed: {e}")
        typer.echo(f"Error: {e}", err=True)
