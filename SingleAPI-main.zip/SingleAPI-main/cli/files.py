import typer
from api.services.files import FileService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="files", help="Manage file uploads in VectorDBCloud.")

@app.command()
def upload(
    instance_id: str = typer.Argument(..., help="Instance ID"),
    collection_name: str = typer.Argument(..., help="Collection name"),
    file_path: str = typer.Argument(..., help="Path to the file"),
    file_type: str = typer.Argument(..., help="File type (e.g., pdf, docx, xlsx)"),
    normalize: bool = typer.Option(False, "--normalize", help="Normalize text"),
    anonymize: bool = typer.Option(False, "--anonymize", help="Anonymize text")
):
    """Upload a file for processing."""
    file_service = FileService()
    try:
        with open(file_path, "rb") as f:
            file_content = f.read()
        file_id = asyncio.run(file_service.process_file(
            instance_id, collection_name, file_type, file_content, normalize, anonymize
        ))
        typer.echo(f"Uploaded file: {file_id}")
        logger.info(f"CLI uploaded file {file_id}")
    except Exception as e:
        logger.error(f"CLI file upload failed: {e}")
        typer.echo(f"Error: {e}", err=True)
