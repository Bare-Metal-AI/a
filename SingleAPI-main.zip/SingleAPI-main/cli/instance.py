import typer
from api.services.cloud import CloudService
from config.settings import settings
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="instance", help="Manage VectorDBCloud instances.")

@app.command()
def deploy(
    db_type: str = typer.Argument(..., help="Database type (e.g., pgvector)"),
    cloud_provider: str = typer.Argument(..., help="Cloud provider (e.g., aws)"),
    cluster_size: int = typer.Option(1, "--size", help="Number of nodes in the cluster"),
    region: str = typer.Option("us-east-1", "--region", help="Deployment region")
):
    """Deploy a new instance."""
    cloud_service = CloudService()
    try:
        instance_id = asyncio.run(cloud_service.deploy_instance({
            "db_type": db_type,
            "cloud_provider": cloud_provider,
            "cluster_size": cluster_size,
            "region": region
        }))
        typer.echo(f"Deployed instance: {instance_id}")
        logger.info(f"CLI deployed instance {instance_id}")
    except Exception as e:
        logger.error(f"CLI instance deployment failed: {e}")
        typer.echo(f"Error: {e}", err=True)
