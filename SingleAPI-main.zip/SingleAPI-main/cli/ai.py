import typer
from api.services.ai import AIService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="ai", help="Interact with AI models in VectorDBCloud.")

@app.command()
def generate(
    prompt: str = typer.Argument(..., help="Prompt for generation"),
    model: str = typer.Argument(..., help="Model name (e.g., gpt4o)"),
    max_tokens: int = typer.Option(100, "--max-tokens", help="Max tokens"),
    temperature: float = typer.Option(0.7, "--temp", help="Temperature")
):
    """Generate text using an AI model."""
    ai_service = AIService()
    try:
        output, tokens = asyncio.run(ai_service.generate(prompt, model, max_tokens, temperature))
        typer.echo(f"Generated text: {output} (Tokens: {tokens})")
        logger.info(f"CLI generated text with {model}: {tokens} tokens")
    except Exception as e:
        logger.error(f"CLI AI generation failed: {e}")
        typer.echo(f"Error: {e}", err=True)

@app.command()
def embed(
    input: str = typer.Argument(..., help="Text to embed"),
    model: str = typer.Argument(..., help="Embedding model name")
):
    """Generate embeddings for text."""
    ai_service = AIService()
    try:
        embeddings, tokens = asyncio.run(ai_service.embed(input, model))
        typer.echo(f"Embeddings: {embeddings[:10]}... (Tokens: {tokens})")
        logger.info(f"CLI generated embeddings with {model}: {tokens} tokens")
    except Exception as e:
        logger.error(f"CLI embedding failed: {e}")
        typer.echo(f"Error: {e}", err=True)
