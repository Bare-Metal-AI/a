import typer
from api.services.external import ExternalService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="external", help="Manage external data imports in VectorDBCloud.")

@app.command()
def import_data(
    instance_id: str = typer.Argument(..., help="Instance ID"),
    collection_name: str = typer.Argument(..., help="Collection name"),
    source_type: str = typer.Argument(..., help="Source type (e.g., youtube)"),
    source_url: str = typer.Argument(..., help="Source URL"),
    api_key: str = typer.Option(None, "--api-key", help="API key for the source")
):
    """Import data from an external source."""
    external_service = ExternalService()
    try:
        records = asyncio.run(external_service.import_data(instance_id, collection_name, source_type, source_url, api_key))
        typer.echo(f"Imported {records} records from {source_type}")
        logger.info(f"CLI imported {records} records from {source_type} into {collection_name}")
    except Exception as e:
        logger.error(f"CLI external import failed: {e}")
        typer.echo(f"Error: {e}", err=True)
