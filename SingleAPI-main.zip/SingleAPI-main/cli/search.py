import typer
from api.services.search import SearchService
from adapters.pgvector import PgVectorAdapter
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="search", help="Perform searches in VectorDBCloud.")

@app.command()
def fulltext(
    instance_id: str = typer.Argument(..., help="Instance ID"),
    collection_name: str = typer.Argument(..., help="Collection name"),
    query: str = typer.Argument(..., help="Search query"),
    top_k: int = typer.Option(10, "--top-k", help="Number of results"),
    use_nlp: bool = typer.Option(False, "--nlp", help="Use NLP processing")
):
    """Perform a full-text search."""
    adapter = PgVectorAdapter()
    search_service = SearchService()
    try:
        results = asyncio.run(search_service.fulltext_search(adapter, instance_id, collection_name, SearchRequest(query=query, top_k=top_k, use_nlp=use_nlp)))
        typer.echo(f"Search results: {results}")
        logger.info(f"CLI performed search in {collection_name}: {len(results)} results")
    except Exception as e:
        logger.error(f"CLI search failed: {e}")
        typer.echo(f"Error: {e}", err=True)
