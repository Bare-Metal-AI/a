import typer
from api.services.agents import AgentService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="agents", help="Manage AI agents in VectorDBCloud.")

@app.command()
def create(
    name: str = typer.Argument(..., help="Agent name"),
    instance_id: str = typer.Argument(..., help="Instance ID"),
    collection_name: str = typer.Argument(..., help="Collection name"),
    model: str = typer.Option("gpt4o", "--model", help="AI model"),
    agent_type: str = typer.Option("langchain", "--type", help="Agent type (e.g., langchain, mcp)"),
    tools: str = typer.Option(None, "--tools", help="Comma-separated list of tools")
):
    """Create a new AI agent."""
    agent_service = AgentService()
    try:
        tools_list = tools.split(",") if tools else None
        agent_id = asyncio.run(agent_service.create_agent(name, instance_id, collection_name, model, agent_type, tools_list))
        typer.echo(f"Created agent: {agent_id}")
        logger.info(f"CLI created agent {agent_id}")
    except Exception as e:
        logger.error(f"CLI agent creation failed: {e}")
        typer.echo(f"Error: {e}", err=True)

@app.command()
def query(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    query: str = typer.Argument(..., help="Query text"),
    max_tokens: int = typer.Option(100, "--max-tokens", help="Max tokens"),
    temperature: float = typer.Option(0.7, "--temp", help="Temperature")
):
    """Query an existing AI agent."""
    agent_service = AgentService()
    try:
        output, tokens, cost = asyncio.run(agent_service.query_agent(agent_id, query, max_tokens, temperature))
        typer.echo(f"Response: {output}\nTokens: {tokens}\nCost: ${cost:.6f}")
        logger.info(f"CLI queried agent {agent_id}: {tokens} tokens")
    except Exception as e:
        logger.error(f"CLI agent query failed: {e}")
        typer.echo(f"Error: {e}", err=True)
