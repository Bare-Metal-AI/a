import typer
from api.services.feedback import FeedbackService
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="feedback", help="Submit feedback to VectorDBCloud.")

@app.command()
def submit(
    user_id: str = typer.Argument(..., help="User ID"),
    message: str = typer.Argument(..., help="Feedback message")
):
    """Submit user feedback."""
    feedback_service = FeedbackService()
    try:
        asyncio.run(feedback_service.submit_feedback(user_id, message))
        typer.echo("Feedback submitted successfully")
        logger.info(f"CLI submitted feedback from {user_id}")
    except Exception as e:
        logger.error(f"CLI feedback submission failed: {e}")
        typer.echo(f"Error: {e}", err=True)
