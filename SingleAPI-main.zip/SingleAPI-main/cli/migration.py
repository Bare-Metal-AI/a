import typer
from orchestration.workflows import MigrationWorkflow, get_temporal_client
import logging
import asyncio

logger = logging.getLogger(__name__)

app = typer.Typer(name="migration", help="Manage migrations in VectorDBCloud.")

@app.command()
def copy(
    source_instance_id: str = typer.Argument(..., help="Source instance ID"),
    source_collection: str = typer.Argument(..., help="Source collection"),
    target_instance_id: str = typer.Argument(..., help="Target instance ID"),
    target_collection: str = typer.Argument(..., help="Target collection")
):
    """Copy data between collections or instances."""
    try:
        client = asyncio.run(get_temporal_client())
        workflow_id = f"migrate-{source_instance_id}-to-{target_instance_id}"
        result = asyncio.run(client.start_workflow(
            MigrationWorkflow.run,
            {
                "source_instance_id": source_instance_id,
                "source_collection": source_collection,
                "target_instance_id": target_instance_id,
                "target_collection": target_collection
            },
            id=workflow_id,
            task_queue="migration-queue"
        ))
        typer.echo(f"Migration started: {result}")
        logger.info(f"CLI started migration {workflow_id}")
    except Exception as e:
        logger.error(f"CLI migration failed: {e}")
        typer.echo(f"Error: {e}", err=True)
