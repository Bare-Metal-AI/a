import typer
from cli.instance import instance_app
from cli.collection import collection_app
from cli.search import search_app
from cli.ai import ai_app
from cli.backup import backup_app
from cli.graph import graph_app
from cli.migration import migration_app
from cli.team import team_app
from cli.files import files_app
from cli.external import external_app
from cli.etl import etl_app
from cli.agents import agents_app
from cli.orchestration import orchestration_app
from cli.rag import rag_app
from cli.feedback import feedback_app
from config.settings import settings
import logging

logger = logging.getLogger(__name__)
setup_logging(settings.log_level)

app = typer.Typer(help="VectorDBCloud CLI for managing vector databases, AI agents, and orchestration.")

app.add_typer(instance_app, name="instance", help="Manage instances.")
app.add_typer(collection_app, name="collection", help="Manage collections.")
app.add_typer(search_app, name="search", help="Search operations.")
app.add_typer(ai_app, name="ai", help="Generative AI and embedding generation.")
app.add_typer(backup_app, name="backup", help="Backup and restore.")
app.add_typer(graph_app, name="graph", help="Graph operations.")
app.add_typer(migration_app, name="migration", help="Data migration.")
app.add_typer(team_app, name="team", help="Team management.")
app.add_typer(files_app, name="files", help="File uploads.")
app.add_typer(external_app, name="external", help="External data imports.")
app.add_typer(etl_app, name="etl", help="ETL pipeline management.")
app.add_typer(agents_app, name="agents", help="AI agent management.")
app.add_typer(orchestration_app, name="orchestration", help="Multi-agent orchestration.")
app.add_typer(rag_app, name="rag", help="RAG pipeline management.")
app.add_typer(feedback_app, name="feedback", help="Submit feedback.")

if __name__ == "__main__":
    app()
