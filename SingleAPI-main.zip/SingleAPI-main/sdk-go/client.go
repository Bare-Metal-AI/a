```go
package vectordbcloud

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io"
    "log"
    "net/http"
    "os"
    "strings"
)

type VectorDBCloudClient struct {
    apiUrl    string
    token     string
    principal string
    client    *http.Client
}

type VectorDBCloudError struct {
    Message string
}

func (e *VectorDBCloudError) Error() string {
    return e.Message
}

type AuthenticationError struct {
    VectorDBCloudError
}

type PermissionError struct {
    VectorDBCloudError
}

func NewClient(apiUrl, token, principal string) *VectorDBCloudClient {
    if token == "" || principal == "" {
        log.Fatalf("Token and principal are required")
    }
    client := &VectorDBCloudClient{
        apiUrl:    strings.TrimRight(apiUrl, "/"),
        token:     token,
        principal: principal,
        client:    &http.Client{},
    }
    log.Printf("VectorDBCloudClient initialized for %s", apiUrl)
    return client
}

func (c *VectorDBCloudClient) request(method, path string, body interface{}) (map[string]interface{}, error) {
    url := fmt.Sprintf("%s%s", c.apiUrl, path)
    var reqBody io.Reader
    if body != nil {
        jsonBody, err := json.Marshal(body)
        if err != nil {
            log.Printf("Failed to marshal request body: %v", err)
            return nil, &VectorDBCloudError{Message: fmt.Sprintf("Marshal error: %v", err)}
        }
        reqBody = bytes.NewBuffer(jsonBody)
    }

    req, err := http.NewRequest(method, url, reqBody)
    if err != nil {
        log.Printf("Failed to create request: %v", err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("Request creation error: %v", err)}
    }

    req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", c.token))
    req.Header.Set("X-Principal", c.principal)
    if body != nil {
        req.Header.Set("Content-Type", "application/json")
    }

    resp, err := c.client.Do(req)
    if err != nil {
        log.Printf("Request failed: %v", err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("Request error: %v", err)}
    }
    defer resp.Body.Close()

    if resp.StatusCode == 401 {
        log.Printf("Authentication error: %v", resp.Status)
        return nil, &AuthenticationError{VectorDBCloudError{Message: "Invalid credentials"}}
    }
    if resp.StatusCode == 403 {
        log.Printf("Permission error: %v", resp.Status)
        return nil, &PermissionError{VectorDBCloudError{Message: "Insufficient permissions"}}
    }
    if resp.StatusCode != 200 {
        bodyBytes, _ := io.ReadAll(resp.Body)
        log.Printf("API error: %v - %s", resp.Status, string(bodyBytes))
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("API error: %v - %s", resp.Status, string(bodyBytes))}
    }

    var result map[string]interface{}
    if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
        log.Printf("Failed to decode response: %v", err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("Decode error: %v", err)}
    }
    log.Printf("Request %s %s succeeded", method, path)
    return result, nil
}

func (c *VectorDBCloudClient) DeployInstance(dbType, cloudProvider string, clusterSize int, region string) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "db_type": dbType,
        "cloud_provider": cloudProvider,
        "cluster_size": clusterSize,
    }
    if region != "" {
        data["region"] = region
    }
    return c.request("POST", fmt.Sprintf("/instances/%s", dbType), data)
}

func (c *VectorDBCloudClient) CreateCollection(instanceId, name string) (map[string]interface{}, error) {
    return c.request("POST", fmt.Sprintf("/collections/%s", instanceId), map[string]string{"name": name})
}

func (c *VectorDBCloudClient) UpsertData(instanceId, collectionName string, data []map[string]interface{}) (map[string]interface{}, error) {
    return c.request("PUT", fmt.Sprintf("/collections/%s/%s/upsert", instanceId, collectionName), map[string]interface{}{"data": data})
}

func (c *VectorDBCloudClient) FulltextSearch(instanceId, collectionName, query string, topK int, useNlp bool) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "query": query,
        "top_k": topK,
        "use_nlp": useNlp,
    }
    return c.request("POST", fmt.Sprintf("/search/%s/%s/fulltext", instanceId, collectionName), data)
}

func (c *VectorDBCloudClient) Generate(prompt, model string, maxTokens int, temperature float64) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "task": "generate",
        "generate": map[string]interface{}{
            "prompt": prompt,
            "model": model,
            "max_tokens": maxTokens,
            "temperature": temperature,
        },
    }
    return c.request("POST", "/ai/", data)
}

func (c *VectorDBCloudClient) Embed(input interface{}, model string) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "task": "embed",
        "embed": map[string]interface{}{
            "input": input,
            "model": model,
        },
    }
    return c.request("POST", "/ai/", data)
}

func (c *VectorDBCloudClient) CreateAgent(name, instanceId, collectionName, model, agentType string, tools []string) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "name": name,
        "instance_id": instanceId,
        "collection_name": collectionName,
        "model": model,
        "agent_type": agentType,
    }
    if tools != nil {
        data["tools"] = tools
    }
    return c.request("POST", "/agents/create", data)
}

func (c *VectorDBCloudClient) QueryAgent(agentId, query string, maxTokens int, temperature float64) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "agent_id": agentId,
        "query": query,
        "max_tokens": maxTokens,
        "temperature": temperature,
    }
    return c.request("POST", "/agents/query", data)
}

func (c *VectorDBCloudClient) OrchestrateAgents(orchestrationId string, tasks []map[string]interface{}) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "orchestration_id": orchestrationId,
        "tasks": tasks,
    }
    return c.request("POST", "/orchestration/", data)
}

func (c *VectorDBCloudClient) UploadFile(instanceId, collectionName, filePath, fileType string, normalize, anonymize bool, etlPipeline string) (map[string]interface{}, error) {
    fileContent, err := os.ReadFile(filePath)
    if err != nil {
        log.Printf("Failed to read file %s: %v", filePath, err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("File read error: %v", err)}
    }

    body := &bytes.Buffer{}
    writer := multipart.NewWriter(body)
    part, _ := writer.CreateFormFile("file", filePath)
    part.Write(fileContent)
    writer.WriteField("instance_id", instanceId)
    writer.WriteField("collection_name", collectionName)
    writer.WriteField("file_type", fileType)
    writer.WriteField("normalize", fmt.Sprintf("%t", normalize))
    writer.WriteField("anonymize", fmt.Sprintf("%t", anonymize))
    if etlPipeline != "" {
        writer.WriteField("etl_pipeline", etlPipeline)
    }
    writer.Close()

    req, err := http.NewRequest("POST", c.apiUrl+"/files/upload", body)
    if err != nil {
        log.Printf("Failed to create file upload request: %v", err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("Request creation error: %v", err)}
    }
    req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", c.token))
    req.Header.Set("X-Principal", c.principal)
    req.Header.Set("Content-Type", writer.FormDataContentType())

    resp, err := c.client.Do(req)
    if err != nil {
        log.Printf("File upload request failed: %v", err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("Request error: %v", err)}
    }
    defer resp.Body.Close()

    if resp.StatusCode != 200 {
        bodyBytes, _ := io.ReadAll(resp.Body)
        log.Printf("File upload error: %v - %s", resp.Status, string(bodyBytes))
        if resp.StatusCode == 401 {
            return nil, &AuthenticationError{VectorDBCloudError{Message: "Invalid credentials"}}
        }
        if resp.StatusCode == 403 {
            return nil, &PermissionError{VectorDBCloudError{Message: "Insufficient permissions"}}
        }
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("API error: %v - %s", resp.Status, string(bodyBytes))}
    }

    var result map[string]interface{}
    if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
        log.Printf("Failed to decode file upload response: %v", err)
        return nil, &VectorDBCloudError{Message: fmt.Sprintf("Decode error: %v", err)}
    }
    log.Printf("File uploaded successfully: %s", filePath)
    return result, nil
}

func (c *VectorDBCloudClient) ImportExternal(instanceId, collectionName, sourceType, sourceUrl, apiKey string, normalize, anonymize bool, etlPipeline string) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "instance_id": instanceId,
        "collection_name": collectionName,
        "source_type": sourceType,
        "source_url": sourceUrl,
        "normalize": normalize,
        "anonymize": anonymize,
    }
    if apiKey != "" {
        data["api_key"] = apiKey
    }
    if etlPipeline != "" {
        data["etl_pipeline"] = etlPipeline
    }
    return c.request("POST", "/external/import", data)
}

func (c *VectorDBCloudClient) GetUsage() (map[string]interface{}, error) {
    return c.request("GET", "/monitoring/usage", nil)
}

func (c *VectorDBCloudClient) CreateRagPipeline(instanceId, collectionName, model, framework string, maxTokens int, temperature float64) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "instance_id": instanceId,
        "collection_name": collectionName,
        "model": model,
        "framework": framework,
        "max_tokens": maxTokens,
        "temperature": temperature,
    }
    return c.request("POST", "/rag/create", data)
}

func (c *VectorDBCloudClient) QueryRagPipeline(pipelineId, query string, maxTokens int, temperature float64) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "query": query,
        "max_tokens": maxTokens,
        "temperature": temperature,
    }
    return c.request("POST", fmt.Sprintf("/rag/%s/query", pipelineId), data)
}

func (c *VectorDBCloudClient) SubmitFeedback(userId, message string) (map[string]interface{}, error) {
    data := map[string]interface{}{
        "user_id": userId,
        "message": message,
    }
    return c.request("POST", "/feedback", data)
}
