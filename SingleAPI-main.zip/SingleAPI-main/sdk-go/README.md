# VectorDBCloud Go SDK

## Installation
```bash
go get github.com/your-org/vectordbcloud-go
```

## Usage
```go
package main

import (
    "fmt"
    "github.com/your-org/vectordbcloud-go"
)

func main() {
    client := vectordbcloud.NewClient("https://api.vectordbcloud.com", "your-token", "user1")
    instance, err := client.DeployInstance("pgvector", "aws", 1, "us-east-1")
    if err != nil {
        fmt.Println("Error:", err)
        return
    }
    fmt.Println("Deployed instance:", instance["instance_id"])
}
```
