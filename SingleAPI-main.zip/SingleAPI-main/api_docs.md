```markdown
# VectorDBCloud API Documentation

## Overview
VectorDBCloud is a high-speed, edge-supported API for vector database management, AI integration, and orchestration. Deployed at `https://api.vectordbcloud.com`.

## Authentication
- **Header**: `Authorization: Bearer <cognito-jwt>`
- **Header**: `X-Principal: <user-id>`
- Obtain token via AWS Cognito (see `deployment.md`).

## Endpoints

### Instances
- **POST /instances/{db_type}**  
  **Description**: Deploy a vector DB instance.  
  **Request**: `{ "db_type": "pgvector", "cloud_provider": "aws", "cluster_size": 1, "region": "us-east-1" }`  
  **Response**: `{ "instance_id": "pgvector-123", "status": "running" }`  
  **Roles**: sme, enterprise, regulated

### Collections
- **POST /collections/{instance_id}**  
  **Description**: Create a collection.  
  **Request**: `{ "name": "my_collection" }`  
  **Response**: `{ "status": "created" }`

- **PUT /collections/{instance_id}/{collection_name}/upsert**  
  **Description**: Upsert data into a collection.  
  **Request**: `{ "data": [{"id": "1", "vector": [0.1, ...], "metadata": {"key": "value"}}] }`  
  **Response**: `{ "status": "success" }`

### Search
- **POST /search/{instance_id}/{collection_name}/fulltext**  
  **Description**: Full-text search with NLP option.  
  **Request**: `{ "query": "find AI reports", "top_k": 10, "use_nlp": true }`  
  **Response**: `{ "results": [...] }`

### AI
- **POST /ai/**  
  **Description**: Unified endpoint for generative AI and embeddings.  
  **Request (Generate)**: `{ "task": "generate", "generate": { "prompt": "Write a story", "model": "gpt4o", "max_tokens": 100, "temperature": 0.7 } }`  
  **Request (Embed)**: `{ "task": "embed", "embed": { "input": "Hello world", "model": "openai-ada-002" } }`  
  **Response**: `{ "task": "generate", "result": "Once upon a time...", "tokens": 50, "estimated_cost_usd": 0.00025 }`  
  **Models**: deepseek, claude-sonnet, qwen, llama, gpt4o, grok, mixtral, perplexity, groq-llama3-70b, groq-mixtral-8x7b, gemini, ollama (generate); openai-ada-002, hf-minilm (embed)  
  **Roles**: enterprise, regulated (generate); all (embed)

### Backup
- **POST /backup/{instance_id}**  
  **Description**: Create a backup.  
  **Response**: `{ "backup_id": "backup-pgvector-123" }`

### Graph
- **POST /graph/nodes**  
  **Description**: Create a graph node.  
  **Request**: `{ "node_id": "n1", "properties": {"name": "Node1"} }`  
  **Response**: `{ "status": "created" }`  
  **Roles**: enterprise, regulated

### Migration
- **POST /migration/copy**  
  **Description**: Copy data between collections/instances.  
  **Request**: `{ "source_instance_id": "pgvector-123", "source_collection": "src", "target_instance_id": "qdrant-456", "target_collection": "dst" }`  
  **Response**: `{ "message": "Migration completed" }`  
  **Roles**: regulated

### Team
- **POST /team/create**  
  **Description**: Create a team.  
  **Request**: `{ "team_name": "DevTeam", "members": ["user1", "user2"] }`  
  **Response**: `{ "team_id": "team-789" }`  
  **Roles**: enterprise, regulated

### Files
- **POST /files/upload**  
  **Description**: Upload files for processing.  
  **Query Params**: `instance_id`, `collection_name`, `file_type`, `normalize`, `anonymize`, `etl_pipeline`  
  **Request**: Multipart form-data with file  
  **Response**: `{ "status": "uploaded", "file_id": "file-123" }`

### External
- **POST /external/import**  
  **Description**: Import data from external sources.  
  **Request**: `{ "source_type": "youtube", "source_url": "https://youtube.com/watch?v=xyz", "api_key": "your-key" }`  
  **Response**: `{ "status": "imported", "records": 5 }`

### Monitoring
- **GET /monitoring/usage**  
  **Description**: Retrieve usage metrics with token/cost tracking.  
  **Response**: `{ "requests": 100, "tokens_used": 5000, "cost_usd": 0.25 }`

### UI
- **GET /ui/dashboard**  
  **Description**: Render the web dashboard.  
  **Response**: HTML dashboard page

### Agents
- **POST /agents/create**  
  **Description**: Create an AI agent.  
  **Request**: `{ "name": "my_agent", "instance_id": "pgvector-123", "collection_name": "coll", "model": "gpt4o", "agent_type": "langchain", "tools": ["search"] }`  
  **Response**: `{ "agent_id": "langchain-my_agent-pgvector-123" }`  
  **Roles**: enterprise, regulated

- **POST /agents/query**  
  **Description**: Query an AI agent.  
  **Request**: `{ "agent_id": "langchain-my_agent-pgvector-123", "query": "What’s AI?", "max_tokens": 100, "temperature": 0.7 }`  
  **Response**: `{ "agent_id": "...", "response": "AI is...", "tokens": 50, "estimated_cost_usd": 0.00025 }`

### Orchestration
- **POST /orchestration/**  
  **Description**: Orchestrate multiple AI agents.  
  **Request**: `{ "orchestration_id": "workflow1", "tasks": [{"agent_id": "agent1", "task": "Summarize"}] }`  
  **Response**: `{ "orchestration_id": "workflow1", "results": {"agent1": "Summary..."}, "total_tokens": 150, "total_cost_usd": 0.00075 }`  
  **Roles**: enterprise, regulated

### RAG
- **POST /rag/create**  
  **Description**: Create a RAG pipeline.  
  **Request**: `{ "instance_id": "pgvector-123", "collection_name": "coll", "model": "gpt4o", "framework": "langchain" }`  
  **Response**: `{ "pipeline_id": "rag-pgvector-123-coll", "status": "created" }`

- **POST /rag/{pipeline_id}/query**  
  **Description**: Query a RAG pipeline.  
  **Request**: `{ "query": "What’s AI?", "max_tokens": 100, "temperature": 0.7 }`  
  **Response**: `{ "pipeline_id": "...", "response": "AI is...", "tokens": 50, "estimated_cost_usd": 0.00025 }`

### Feedback
- **POST /feedback**  
  **Description**: Submit user feedback.  
  **Request**: `{ "user_id": "user1", "message": "Great service!" }`  
  **Response**: `{ "status": "success" }`

## Full Specification
- **Swagger UI**: `https://api.vectordbcloud.com/docs`
- **OpenAPI JSON**: `https://api.vectordbcloud.com/openapi.json`
