# Contributing to VectorDBCloud

## How to Contribute
1. Fork the repository: `git clone https://github.com/your-org/vectordbcloud.git`
2. Create a branch: `git checkout -b feature/your-feature`
3. Commit changes: `git commit -m "Add your feature"`
4. Push to branch: `git push origin feature/your-feature`
5. Open a pull request on GitHub.

## Guidelines
- Follow PEP 8 for Python code.
- Add unit tests in `tests/`.
- Update documentation (`api_docs.md`, `sdk_docs.md`) as needed.

## Optional ZenML Integration
For custom ML pipelines:
1. Install ZenML: `pip install zenml==0.55.0`
2. Define a pipeline:
   ```python
   from zenml.pipelines import pipeline
   @pipeline
   def custom_pipeline(data_step, embed_step):
       data = data_step()
       embed_step(data)
   ```
3. Integrate with VectorDBCloud:
```python
from vectordbcloud import VectorDBCloudClient
client = VectorDBCloudClient("https://api.vectordbcloud.com", "your-token", "user1")
```
- Core functionality is hosted; ZenML is optional for advanced use cases.

---

### `adapters/`

#### `adapters/__init__.py`
```python
from .base import VectorDBAdapter
from .pgvector import PgVectorAdapter
```
from .chromadb import ChromaDBAdapter

__all__ = ["VectorDBAdapter", "PgVectorAdapter", "ChromaDBAdapter"]
