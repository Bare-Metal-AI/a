import ckan.plugins as plugins
import ckan.plugins.toolkit as toolkit
import logging

logger = logging.getLogger(__name__)

class VectorDBCloudPlugin(plugins.SingletonPlugin):
    """CKAN plugin for VectorDBCloud integration."""
    plugins.implements(plugins.IConfigurer)
    plugins.implements(plugins.ITemplateHelpers)

    def update_config(self, config_):
        """Update CKAN configuration."""
        try:
            toolkit.add_template_directory(config_, "templates")
            logger.info("VectorDBCloud CKAN plugin configured")
        except Exception as e:
            logger.error(f"Failed to configure CKAN plugin: {e}")

    def get_helpers(self):
        """Register template helpers."""
        return {
            "vectordbcloud_info": lambda: "VectorDBCloud integration active"
        }
