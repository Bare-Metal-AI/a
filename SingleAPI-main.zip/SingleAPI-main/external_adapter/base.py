from abc import ABC, abstractmethod
from typing import List
import logging

logger = logging.getLogger(__name__)

class ExternalAdapter(ABC):
    """Base class for external data source adapters."""

    @abstractmethod
    async def fetch_data(self, source_url: str, api_key: str = None) -> List[CollectionData]:
        """Fetch data from an external source."""
