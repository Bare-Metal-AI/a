from .base import ExternalAdapter
from api.models.collection import CollectionData
import httpx
import logging
from typing import List

logger = logging.getLogger(__name__)

class HttpAdapter(ExternalAdapter):
    """Adapter for importing data from HTTP endpoints."""

    async def fetch_data(self, source_url: str, api_key: str = None) -> List[CollectionData]:
        """Fetch data from an HTTP endpoint."""
        try:
            headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
            async with httpx.AsyncClient() as client:
                response = await client.get(source_url, headers=headers)
                response.raise_for_status()
                content = response.text
                data = [CollectionData(
                    id=f"http-{source_url.split('/')[-1]}",
                    vector=[0.1] * 1536,  # Placeholder
                    metadata={"content": content, "source": "http", "url": source_url}
                )]
                logger.info(f"Fetched {len(data)} records from HTTP: {source_url}")
                return data
        except Exception as e:
            logger.error(f"HTTP fetch failed: {e}")
            raise RuntimeError(f"HTTP fetch failed: {e}")
