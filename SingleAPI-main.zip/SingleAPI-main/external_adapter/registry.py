from .base import ExternalAdapter
from .youtube import YouTubeAdapter
from typing import Dict
import logging

logger = logging.getLogger(__name__)

class ExternalAdapterRegistry:
    """Registry for external data source adapters."""

    def __init__(self):
        self.adapters: Dict[str, ExternalAdapter] = {
            "youtube": YouTubeAdapter(),
        }
        logger.info(f"Initialized external adapter registry with {len(self.adapters)} adapters")

    def get(self, source_type: str) -> ExternalAdapter:
        """Retrieve an adapter by source type."""
        adapter = self.adapters.get(source_type)
        if not adapter:
            logger.error(f"No adapter found for source type: {source_type}")
            raise ValueError(f"Unsupported source type: {source_type}")
        logger.debug(f"Retrieved adapter for source type: {source_type}")
        return adapter

registry = ExternalAdapterRegistry()
