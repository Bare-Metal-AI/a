from .base import ExternalAdapter
from .youtube import YouTubeAdapter

__all__ = ["ExternalAdapter", "YouTubeAdapter"]
