from .base import ExternalAdapter
from api.models.collection import CollectionData
import httpx
import logging
from typing import List

logger = logging.getLogger(__name__)

class SAPAdapter(ExternalAdapter):
    """Adapter for importing data from SAP (simplified OData)."""

    async def fetch_data(self, source_url: str, api_key: str = None) -> List[CollectionData]:
        """Fetch data from SAP OData endpoint."""
        try:
            headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
            async with httpx.AsyncClient() as client:
                response = await client.get(source_url, headers=headers)
                response.raise_for_status()
                data = response.json().get("value", [])
                records = [CollectionData(
                    id=f"sap-{idx}",
                    vector=[0.1] * 1536,  # Placeholder
                    metadata={
                        "source": "sap",
                        "record": record
                    }
                ) for idx, record in enumerate(data)]
                logger.info(f"Fetched {len(records)} records from SAP: {source_url}")
                return records
        except Exception as e:
            logger.error(f"SAP fetch failed: {e}")
            raise RuntimeError(f"SAP fetch failed: {e}")
