from .base import ExternalAdapter
from api.models.collection import CollectionData
from simple_salesforce import Salesforce
from config.settings import settings
import logging
from typing import List

logger = logging.getLogger(__name__)

class SalesforceAdapter(ExternalAdapter):
    """Adapter for importing data from Salesforce."""

    def __init__(self):
        self.sf = Salesforce(
            username=settings.salesforce_username,
            password=settings.salesforce_password,
            security_token=settings.salesforce_token
        )
        logger.info("Initialized Salesforce adapter")

    async def fetch_data(self, source_url: str, api_key: str = None) -> List[CollectionData]:
        """Fetch data from Salesforce (e.g., SOQL query via URL)."""
        try:
            # Assume source_url contains SOQL query (e.g., "SELECT Id, Name FROM Account LIMIT 10")
            query = source_url.split("query=")[1] if "query=" in source_url else "SELECT Id, Name FROM Account LIMIT 10"
            results = self.sf.query(query)["records"]
            data = [CollectionData(
                id=f"sf-{record['Id']}",
                vector=[0.1] * 1536,  # Placeholder
                metadata={
                    "source": "salesforce",
                    "record": record
                }
            ) for record in results]
            logger.info(f"Fetched {len(data)} records from Salesforce")
            return data
        except Exception as e:
            logger.error(f"Salesforce fetch failed: {e}")
            raise RuntimeError(f"Salesforce fetch failed: {e}")
