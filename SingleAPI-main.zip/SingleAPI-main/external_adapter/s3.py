from .base import ExternalAdapter
from api.models.collection import CollectionData
import boto3
from config.settings import settings
import logging
from typing import List

logger = logging.getLogger(__name__)

class S3Adapter(ExternalAdapter):
    """Adapter for importing data from AWS S3."""

    def __init__(self):
        self.client = boto3.client(
            "s3",
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key
        )
        logger.info("Initialized S3 adapter")

    async def fetch_data(self, source_url: str, api_key: str = None) -> List[CollectionData]:
        """Fetch data from an S3 bucket."""
        try:
            # Parse S3 URL (e.g., s3://bucket-name/key)
            if not source_url.startswith("s3://"):
                raise ValueError("Invalid S3 URL")
            bucket, key = source_url[5:].split("/", 1)
            resp = self.client.get_object(Bucket=bucket, Key=key)
            content = resp["Body"].read().decode("utf-8")
            data = [CollectionData(
                id=f"s3-{key}",
                vector=[0.1] * 1536,  # Placeholder
                metadata={"content": content, "source": "s3", "key": key}
            )]
            logger.info(f"Fetched {len(data)} records from S3: {source_url}")
            return data
        except Exception as e:
            logger.error(f"S3 fetch failed: {e}")
            raise RuntimeError(f"S3 fetch failed: {e}")
