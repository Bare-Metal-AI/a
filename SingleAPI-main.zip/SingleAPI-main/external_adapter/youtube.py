from .base import ExternalAdapter
from api.models.collection import CollectionData
import httpx
import logging
from typing import List

logger = logging.getLogger(__name__)

class YouTubeAdapter(ExternalAdapter):
    """Adapter for importing data from YouTube."""

    async def fetch_data(self, source_url: str, api_key: str = None) -> List[CollectionData]:
        """Fetch video metadata from YouTube."""
        if not api_key:
            logger.error("YouTube API key required")
            raise ValueError("API key is required for YouTube")

        try:
            video_id = source_url.split("v=")[1]
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "https://www.googleapis.com/youtube/v3/videos",
                    params={
                        "id": video_id,
                        "key": api_key,
                        "part": "snippet"
                    }
                )
                response.raise_for_status()
                data = response.json()
                items = data.get("items", [])
                if not items:
                    raise ValueError("No video found")

                video = items[0]["snippet"]
                return [CollectionData(
                    id=f"yt-{video_id}",
                    vector=[0.1] * 1536,  # Placeholder embedding
                    metadata={
                        "title": video["title"],
                        "description": video["description"],
                        "source": "youtube"
                    }
                )]
        except Exception as e:
            logger.error(f"YouTube fetch failed: {e}")
            raise RuntimeError(f"YouTube fetch failed: {e}")
