import logging
import fireducks.pandas as pd  # Updated
from .base import VectorDBAdapter
import lancedb

logger = logging.getLogger(__name__)

class LanceDBAdapter(VectorDBAdapter):
    """Adapter for LanceDB vector database with FireDucks."""

    def __init__(self, path: str = "./lancedb"):
        self.db = lancedb.connect(path)
        logger.info("Initialized LanceDB adapter")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection in LanceDB."""
        try:
            schema = {
                "id": str,
                "vector": lancedb.vector(1536),
                "metadata": dict
            }
            self.db.create_table(collection_name, schema=schema)
            logger.info(f"Created LanceDB collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create LanceDB collection {collection_name}: {e}")
            raise RuntimeError(f"LanceDB collection creation failed: {e}")

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a LanceDB collection."""
        try:
            table = self.db.open_table(collection_name)
            df = pd.DataFrame([data])  # FireDucks DataFrame
            table.add(df)
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into LanceDB collection {collection_name}: {e}")
            raise RuntimeError(f"LanceDB insert failed: {e}")

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in LanceDB with FireDucks."""
        try:
            table = self.db.open_table(collection_name)
            results = table.search(query_vector).limit(limit).to_pandas()  # FireDucks DataFrame
            logger.info(f"Search completed in LanceDB {collection_name} with {len(results)} results")
            return [{"id": row["id"], "vector": row["vector"].tolist(), "metadata": row["metadata"], "similarity": row["_distance"]} for _, row in results.iterrows()]
        except Exception as e:
            logger.error(f"Search failed in LanceDB {collection_name}: {e}")
            raise RuntimeError(f"LanceDB search failed: {e}")
