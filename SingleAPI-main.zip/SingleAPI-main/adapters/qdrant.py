import logging
from typing import List, Dict, Any
from .base import VectorDBAdapter
from qdrant_client import QdrantClient
from qdrant_client.http.models import Distance, VectorParams, PointStruct

logger = logging.getLogger(__name__)

class QdrantAdapter(VectorDBAdapter):
    """Adapter for Qdrant vector database."""

    def __init__(self, host: str = "localhost", port: int = 6333):
        self.client = QdrantClient(host=host, port=port)
        logger.info("Initialized Qdrant adapter")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection in Qdrant."""
        try:
            self.client.recreate_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(size=1536, distance=Distance.COSINE)
            )
            logger.info(f"Created Qdrant collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create Qdrant collection {collection_name}: {e}")
            raise RuntimeError(f"Qdrant collection creation failed: {e}")

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a Qdrant collection."""
        try:
            point = PointStruct(
                id=data["id"],
                vector=data["vector"],
                payload=data["metadata"]
            )
            self.client.upsert(
                collection_name=collection_name,
                points=[point]
            )
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into Qdrant collection {collection_name}: {e}")
            raise RuntimeError(f"Qdrant insert failed: {e}")

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in Qdrant."""
        try:
            results = self.client.search(
                collection_name=collection_name,
                query_vector=query_vector,
                limit=limit,
                with_payload=True
            )
            logger.info(f"Search completed in Qdrant {collection_name} with {len(results)} results")
            return [{"id": r.id, "vector": r.vector, "metadata": r.payload, "similarity": r.score} for r in results]
        except Exception as e:
            logger.error(f"Search failed in Qdrant {collection_name}: {e}")
            raise RuntimeError(f"Qdrant search failed: {e}")
