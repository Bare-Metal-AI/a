import logging
import asyncpg
from typing import List, Dict, Any
from .base import VectorDBAdapter
from config.settings import settings

logger = logging.getLogger(__name__)

class PgVectorAdapter(VectorDBAdapter):
    """Adapter for PostgreSQL with PGVector extension."""

    def __init__(self):
        self.dsn = settings.database_url

    async def connect(self) -> asyncpg.Connection:
        """Establish a database connection."""
        try:
            conn = await asyncpg.connect(self.dsn)
            # Enable PGVector extension
            await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
            logger.info("Connected to PostgreSQL with PGVector.")
            return conn
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            raise RuntimeError(f"Failed to connect to PostgreSQL: {e}")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection table."""
        conn = await self.connect()
        try:
            await conn.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {collection_name} (
                    id TEXT PRIMARY KEY,
                    vector VECTOR(1536),
                    metadata JSONB
                )
                """
            )
            await conn.execute(
                f"CREATE INDEX IF NOT EXISTS {collection_name}_metadata_idx "
                f"ON {collection_name} USING GIN (metadata jsonb_path_ops)"
            )
            logger.info(f"Created collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create collection {collection_name}: {e}")
            raise RuntimeError(f"Collection creation failed: {e}")
        finally:
            await conn.close()

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a collection."""
        conn = await self.connect()
        try:
            await conn.execute(
                f"""
                INSERT INTO {collection_name} (id, vector, metadata)
                VALUES ($1, $2, $3)
                ON CONFLICT (id) DO UPDATE SET vector = EXCLUDED.vector, metadata = EXCLUDED.metadata
                """,
                data["id"],
                data["vector"],
                data["metadata"]
            )
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into {collection_name}: {e}")
            raise RuntimeError(f"Insert failed: {e}")
        finally:
            await conn.close()

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors using cosine similarity."""
        conn = await self.connect()
        try:
            results = await conn.fetch(
                f"""
                SELECT id, vector, metadata,
                       (1 - (vector <=> $1::vector)) AS similarity
                FROM {collection_name}
                ORDER BY similarity DESC
                LIMIT $2
                """,
                query_vector,
                limit
            )
            logger.info(f"Search completed in {collection_name} with {len(results)} results")
            return [{"id": row["id"], "vector": row["vector"], "metadata": row["metadata"], "similarity": row["similarity"]} for row in results]
        except Exception as e:
            logger.error(f"Search failed in {collection_name}: {e}")
            raise RuntimeError(f"Search failed: {e}")
        finally:
            await conn.close()
