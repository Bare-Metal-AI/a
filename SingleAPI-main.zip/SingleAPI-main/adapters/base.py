from abc import ABC, abstractmethod
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class VectorDBAdapter(ABC):
    """Base class for vector database adapters."""

    @abstractmethod
    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection."""

    @abstractmethod
    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert data into a collection."""

    @abstractmethod
    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors."""
