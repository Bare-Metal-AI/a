import logging
from typing import List, Dict, Any
from .base import VectorDBAdapter
import chromadb
from chromadb.config import Settings

logger = logging.getLogger(__name__)

class ChromaDBAdapter(VectorDBAdapter):
    """Adapter for ChromaDB vector database."""

    def __init__(self):
        self.client = chromadb.Client(Settings(chroma_db_impl="duckdb+parquet", persist_directory="./chromadb"))

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection in ChromaDB."""
        try:
            self.client.create_collection(name=collection_name)
            logger.info(f"Created collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create collection {collection_name}: {e}")
            raise RuntimeError(f"Collection creation failed: {e}")

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a collection."""
        try:
            collection = self.client.get_collection(name=collection_name)
            collection.upsert(
                ids=[data["id"]],
                embeddings=[data["vector"]],
                metadatas=[data["metadata"]]
            )
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into {collection_name}: {e}")
            raise RuntimeError(f"Insert failed: {e}")

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in ChromaDB."""
        try:
            collection = self.client.get_collection(name=collection_name)
            results = collection.query(
                query_embeddings=[query_vector],
                n_results=limit
            )
            logger.info(f"Search completed in {collection_name} with {len(results['ids'][0])} results")
            return [
                {"id": id, "vector": emb, "metadata": meta, "similarity": dist}
                for id, emb, meta, dist in zip(
                    results["ids"][0],
                    results["embeddings"][0],
                    results["metadatas"][0],
                    results["distances"][0]
                )
            ]
        except Exception as e:
            logger.error(f"Search failed in {collection_name}: {e}")
            raise RuntimeError(f"Search failed: {e}")
