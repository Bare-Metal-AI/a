import logging
from typing import List, Dict, Any
from .base import VectorDBAdapter
import weaviate
import weaviate.classes as wvc

logger = logging.getLogger(__name__)

class WeaviateAdapter(VectorDBAdapter):
    """Adapter for Weaviate vector database."""

    def __init__(self, url: str = "http://localhost:8080"):
        self.client = weaviate.Client(url=url)
        logger.info("Initialized Weaviate adapter")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection (class) in Weaviate."""
        try:
            if not self.client.schema.exists(collection_name):
                self.client.schema.create_class({
                    "class": collection_name,
                    "vectorizer": "none",
                    "properties": [
                        {"name": "id", "dataType": ["string"]},
                        {"name": "metadata", "dataType": ["object"]}
                    ]
                })
            logger.info(f"Created Weaviate collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create Weaviate collection {collection_name}: {e}")
            raise RuntimeError(f"Weaviate collection creation failed: {e}")

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a Weaviate collection."""
        try:
            self.client.data_object.create(
                data_object={"id": data["id"], "metadata": data["metadata"]},
                class_name=collection_name,
                vector=data["vector"]
            )
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into Weaviate collection {collection_name}: {e}")
            raise RuntimeError(f"Weaviate insert failed: {e}")

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in Weaviate."""
        try:
            results = self.client.query.get(collection_name, ["id", "metadata"]).with_near_vector({"vector": query_vector}).with_limit(limit).do()
            logger.info(f"Search completed in Weaviate {collection_name} with {len(results['data']['Get'][collection_name])} results")
            return [{"id": r["id"], "vector": query_vector, "metadata": r["metadata"], "similarity": r.get("_additional", {}).get("distance", 1.0)} for r in results["data"]["Get"][collection_name]]
        except Exception as e:
            logger.error(f"Search failed in Weaviate {collection_name}: {e}")
            raise RuntimeError(f"Weaviate search failed: {e}")
