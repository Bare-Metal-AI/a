import logging
from typing import List, Dict, Any
from .base import VectorDBAdapter
import mysql.connector  # OceanBase uses MySQL-compatible protocol
import json

logger = logging.getLogger(__name__)

class OceanbaseAdapter(VectorDBAdapter):
    """Adapter for OceanBase vector database (simplified MySQL emulation)."""

    def __init__(self, host: str = "localhost", port: int = 2881, user: str = "root", password: str = "", database: str = "vectordb"):
        self.conn = mysql.connector.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database
        )
        logger.info("Initialized Oceanbase adapter")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection in Oceanbase."""
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {collection_name} (
                    id VARCHAR(100) PRIMARY KEY,
                    vector BLOB,
                    metadata JSON
                )
                """
            )
            cursor.execute(f"CREATE INDEX idx_{collection_name}_metadata ON {collection_name} (metadata)")
            self.conn.commit()
            logger.info(f"Created Oceanbase collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create Oceanbase collection {collection_name}: {e}")
            raise RuntimeError(f"Oceanbase collection creation failed: {e}")
        finally:
            cursor.close()

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in an Oceanbase collection."""
        try:
            cursor = self.conn.cursor()
            vector_blob = json.dumps(data["vector"]).encode()
            metadata_json = json.dumps(data["metadata"])
            cursor.execute(
                f"""
                INSERT INTO {collection_name} (id, vector, metadata)
                VALUES (%s, %s, %s)
                ON DUPLICATE KEY UPDATE vector=%s, metadata=%s
                """,
                (data["id"], vector_blob, metadata_json, vector_blob, metadata_json)
            )
            self.conn.commit()
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into Oceanbase collection {collection_name}: {e}")
            raise RuntimeError(f"Oceanbase insert failed: {e}")
        finally:
            cursor.close()

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in Oceanbase (simplified cosine similarity)."""
        try:
            cursor = self.conn.cursor()
            # Simplified: Oceanbase lacks native vector search; emulate with JSON
            cursor.execute(
                f"SELECT id, vector, metadata FROM {collection_name} LIMIT %s",
                (limit,)
            )
            rows = cursor.fetchall()
            results = []
            for row in rows:
                vector = json.loads(row[1].decode())
                similarity = sum(a * b for a, b in zip(query_vector, vector))  # Rough cosine
                results.append({"id": row[0], "vector": vector, "metadata": json.loads(row[2]), "similarity": similarity})
            results = sorted(results, key=lambda x: x["similarity"], reverse=True)[:limit]
            logger.info(f"Search completed in Oceanbase {collection_name} with {len(results)} results")
            return results
        except Exception as e:
            logger.error(f"Search failed in Oceanbase {collection_name}: {e}")
            raise RuntimeError(f"Oceanbase search failed: {e}")
        finally:
            cursor.close()
