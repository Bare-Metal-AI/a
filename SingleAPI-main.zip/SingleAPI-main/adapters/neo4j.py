import logging
from typing import List, Dict, Any
from .base import VectorDBAdapter
from neo4j import GraphDatabase
from config.settings import settings

logger = logging.getLogger(__name__)

class Neo4jAdapter(VectorDBAdapter):
    """Adapter for Neo4j as a vector database."""

    def __init__(self):
        self.driver = GraphDatabase.driver(settings.neo4j_uri, auth=(settings.neo4j_user, settings.neo4j_password))
        logger.info("Initialized Neo4j adapter")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection (node type) in Neo4j."""
        try:
            with self.driver.session() as session:
                session.run(
                    f"CREATE CONSTRAINT IF NOT EXISTS FOR (n:{collection_name}) REQUIRE n.id IS UNIQUE"
                )
            logger.info(f"Created Neo4j collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create Neo4j collection {collection_name}: {e}")
            raise RuntimeError(f"Neo4j collection creation failed: {e}")

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a Neo4j collection."""
        try:
            with self.driver.session() as session:
                session.run(
                    f"MERGE (n:{collection_name} {{id: $id}}) SET n.vector = $vector, n.metadata = $metadata",
                    id=data["id"],
                    vector=json.dumps(data["vector"]),
                    metadata=json.dumps(data["metadata"])
                )
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into Neo4j collection {collection_name}: {e}")
            raise RuntimeError(f"Neo4j insert failed: {e}")

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in Neo4j (simplified cosine similarity)."""
        try:
            with self.driver.session() as session:
                results = session.run(
                    f"MATCH (n:{collection_name}) RETURN n.id, n.vector, n.metadata LIMIT $limit",
                    limit=limit
                )
                output = []
                for record in results:
                    vector = json.loads(record["n.vector"])
                    similarity = sum(a * b for a, b in zip(query_vector, vector))  # Rough cosine
                    output.append({
                        "id": record["n.id"],
                        "vector": vector,
                        "metadata": json.loads(record["n.metadata"]),
                        "similarity": similarity
                    })
                output = sorted(output, key=lambda x: x["similarity"], reverse=True)[:limit]
                logger.info(f"Search completed in Neo4j {collection_name} with {len(output)} results")
                return output
        except Exception as e:
            logger.error(f"Search failed in Neo4j {collection_name}: {e}")
            raise RuntimeError(f"Neo4j search failed: {e}")
