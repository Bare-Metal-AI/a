import logging
from typing import List, Dict, Any
from .base import VectorDBAdapter
from pymilvus import connections, Collection, FieldSchema, CollectionSchema, DataType

logger = logging.getLogger(__name__)

class MilvusAdapter(VectorDBAdapter):
    """Adapter for Milvus vector database."""

    def __init__(self, host: str = "localhost", port: str = "19530"):
        connections.connect(host=host, port=port)
        logger.info("Initialized Milvus adapter")

    async def create_collection(self, instance_id: str, collection_name: str) -> None:
        """Create a new collection in Milvus."""
        try:
            fields = [
                FieldSchema(name="id", dtype=DataType.VARCHAR, is_primary=True, max_length=100),
                FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=1536),
                FieldSchema(name="metadata", dtype=DataType.JSON),
            ]
            schema = CollectionSchema(fields=fields, description=f"Collection for {instance_id}")
            collection = Collection(name=collection_name, schema=schema)
            collection.create_index("vector", {"index_type": "IVF_FLAT", "metric_type": "COSINE", "params": {"nlist": 1024}})
            logger.info(f"Created Milvus collection {collection_name} for instance {instance_id}")
        except Exception as e:
            logger.error(f"Failed to create Milvus collection {collection_name}: {e}")
            raise RuntimeError(f"Milvus collection creation failed: {e}")

    async def insert(self, instance_id: str, collection_name: str, data: Dict[str, Any]) -> None:
        """Insert or update data in a Milvus collection."""
        try:
            collection = Collection(collection_name)
            entities = [
                [data["id"]],
                [data["vector"]],
                [data["metadata"]]
            ]
            collection.insert(entities)
            logger.info(f"Inserted data with ID {data['id']} into {collection_name}")
        except Exception as e:
            logger.error(f"Failed to insert into Milvus collection {collection_name}: {e}")
            raise RuntimeError(f"Milvus insert failed: {e}")

    async def search(self, instance_id: str, collection_name: str, query_vector: List[float], limit: int) -> List[Dict[str, Any]]:
        """Search for nearest vectors in Milvus."""
        try:
            collection = Collection(collection_name)
            collection.load()
            results = collection.search(
                data=[query_vector],
                anns_field="vector",
                param={"metric_type": "COSINE", "params": {"nprobe": 10}},
                limit=limit,
                output_fields=["id", "metadata"]
            )
            logger.info(f"Search completed in Milvus {collection_name} with {len(results[0])} results")
            return [{"id": r.entity.get("id"), "vector": r.entity.get("vector"), "metadata": r.entity.get("metadata"), "similarity": r.distance} for r in results[0]]
        except Exception as e:
            logger.error(f"Search failed in Milvus {collection_name}: {e}")
            raise RuntimeError(f"Milvus search failed: {e}")
