from .base import AgentFrameworkAdapter
from zep_cloud.client import AsyncZep
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class ZepAdapter(AgentFrameworkAdapter):
    """Adapter for Zep memory service."""

    def __init__(self):
        self.client = AsyncZep(api_key=settings.zep_api_key or os.getenv("ZEP_API_KEY"))
        self.memory_store = {}
        logger.info("Initialized Zep adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        agent_id = f"zep-{name}-{instance_id}"
        session_id = f"{instance_id}-{collection_name}"
        self.memory_store[agent_id] = session_id
        logger.info(f"Created Zep agent {agent_id} with session {session_id}")
        return agent_id

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        session_id = self.memory_store.get(agent_id)
        if not session_id:
            raise ValueError(f"Agent {agent_id} not found")
        await self.client.memory.add(session_id, [{"role": "user", "content": query}])
        memory = await self.client.memory.get(session_id)
        output = memory.context  # Simplified; use LLM with context in production
        tokens = len(query.split()) + len(output.split())  # Approximate
        cost = tokens * 0.0001 / 1_000_000  # Rough estimate
        logger.info(f"Queried Zep agent {agent_id}: {tokens} tokens")
        return output, tokens, cost

    async def delete_agent(self, agent_id: str) -> None:
        session_id = self.memory_store.pop(agent_id, None)
        if session_id:
            logger.info(f"Deleted Zep agent {agent_id}")
        else:
            logger.warning(f"Agent {agent_id} not found")
