from .base import AgentFrameworkAdapter
from .langchain import LangChainAdapter
from .mcp import MCPAdapter
from typing import Dict
import logging

logger = logging.getLogger(__name__)

class AgentFrameworkRegistry:
    """Registry for agent framework adapters."""

    def __init__(self):
        self.adapters: Dict[str, AgentFrameworkAdapter] = {
            "langchain": LangChainAdapter(),
            "mcp": MCPAdapter(),
        }
        logger.info(f"Initialized agent framework registry with {len(self.adapters)} adapters")

    def get(self, framework_name: str) -> AgentFrameworkAdapter:
        """Retrieve an adapter by framework name."""
        adapter = self.adapters.get(framework_name)
        if not adapter:
            logger.error(f"No adapter found for framework: {framework_name}")
            raise ValueError(f"Unsupported framework: {framework_name}")
        logger.debug(f"Retrieved adapter for framework: {framework_name}")
        return adapter

registry = AgentFrameworkRegistry()
