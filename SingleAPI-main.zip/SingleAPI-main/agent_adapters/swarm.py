from .base import AgentFrameworkAdapter
from openai_swarm import Swarm, Agent as SwarmAgent
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class SwarmAdapter(AgentFrameworkAdapter):
    """Adapter for OpenAI Swarm framework."""

    def __init__(self):
        self.client = Swarm(api_key=settings.api_key_openai)
        self.memory_store = {}
        logger.info("Initialized Swarm adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a Swarm agent."""
        try:
            agent_id = f"swarm-{name}-{instance_id}"
            agent = SwarmAgent(
                name=name,
                model=model,
                instructions=f"Act as an agent for {collection_name}"
            )
            self.memory_store[agent_id] = agent
            logger.info(f"Created Swarm agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create Swarm agent: {e}")
            raise RuntimeError(f"Swarm agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a Swarm agent."""
        try:
            agent = self.memory_store.get(agent_id)
            if not agent:
                raise ValueError(f"Agent {agent_id} not found")
            response = await self.client.run(agent=agent, messages=[{"role": "user", "content": query}])
            output = response.messages[-1]["content"]
            tokens = response.usage["total_tokens"]
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried Swarm agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Swarm query failed: {e}")
            raise RuntimeError(f"Swarm query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a Swarm agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted Swarm agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete Swarm agent: {e}")
            raise RuntimeError(f"Swarm deletion failed: {e}")
