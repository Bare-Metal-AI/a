from .base import AgentFrameworkAdapter
from composio import AsyncComposio
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class ComposioAdapter(AgentFrameworkAdapter):
    """Adapter for Composio framework."""

    def __init__(self):
        self.client = AsyncComposio(api_key=settings.api_key_openai)
        self.memory_store = {}
        logger.info("Initialized Composio adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a Composio agent."""
        try:
            agent_id = f"composio-{name}-{instance_id}"
            agent = await self.client.create_agent(
                name=name,
                model=model,
                tools=tools or []
            )
            self.memory_store[agent_id] = agent
            logger.info(f"Created Composio agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create Composio agent: {e}")
            raise RuntimeError(f"Composio agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a Composio agent."""
        try:
            agent = self.memory_store.get(agent_id)
            if not agent:
                raise ValueError(f"Agent {agent_id} not found")
            response = await agent.execute(query=query, max_tokens=max_tokens)
            output = response["result"]
            tokens = response["tokens"]
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried Composio agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Composio query failed: {e}")
            raise RuntimeError(f"Composio query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a Composio agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted Composio agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete Composio agent: {e}")
            raise RuntimeError(f"Composio deletion failed: {e}")
