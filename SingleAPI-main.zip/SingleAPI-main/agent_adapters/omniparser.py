from .base import AgentFrameworkAdapter
from omniparser import Parser
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class OmniParserAdapter(AgentFrameworkAdapter):
    """Adapter for OmniParser framework."""

    def __init__(self):
        self.parser = Parser()
        self.memory_store = {}
        logger.info("Initialized OmniParser adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create an OmniParser agent."""
        try:
            agent_id = f"omniparser-{name}-{instance_id}"
            self.memory_store[agent_id] = {"collection": collection_name}
            logger.info(f"Created OmniParser agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create OmniParser agent: {e}")
            raise RuntimeError(f"OmniParser agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query an OmniParser agent (simplified parsing)."""
        try:
            if agent_id not in self.memory_store:
                raise ValueError(f"Agent {agent_id} not found")
            output = await self.parser.parse(query)  # Simplified
            tokens = len(query.split()) + len(str(output).split())
            cost = tokens * 0.01 / 1_000_000  # Rough estimate
            logger.info(f"Queried OmniParser agent {agent_id}: {tokens} tokens")
            return str(output), tokens, cost
        except Exception as e:
            logger.error(f"OmniParser query failed: {e}")
            raise RuntimeError(f"OmniParser query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete an OmniParser agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted OmniParser agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete OmniParser agent: {e}")
            raise RuntimeError(f"OmniParser deletion failed: {e}")
