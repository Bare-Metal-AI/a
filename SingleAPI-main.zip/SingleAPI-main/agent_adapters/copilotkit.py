from .base import AgentFrameworkAdapter
from copilotkit import CopilotKit
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class CopilotKitAdapter(AgentFrameworkAdapter):
    """Adapter for CopilotKit."""

    def __init__(self):
        self.client = CopilotKit(openai_api_key=settings.api_key_openai)
        self.memory_store = {}
        logger.info("Initialized CopilotKit adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a CopilotKit agent."""
        try:
            agent_id = f"copilotkit-{name}-{instance_id}"
            agent = self.client.create_agent(
                name=name,
                model=model,
                instructions=f"Manage data in {collection_name}"
            )
            self.memory_store[agent_id] = agent
            logger.info(f"Created CopilotKit agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create CopilotKit agent: {e}")
            raise RuntimeError(f"CopilotKit agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a CopilotKit agent."""
        try:
            agent = self.memory_store.get(agent_id)
            if not agent:
                raise ValueError(f"Agent {agent_id} not found")
            response = await agent.run(query=query, max_tokens=max_tokens, temperature=temperature)
            output = response["output"]
            tokens = response["tokens"]
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried CopilotKit agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"CopilotKit query failed: {e}")
            raise RuntimeError(f"CopilotKit query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a CopilotKit agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted CopilotKit agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete CopilotKit agent: {e}")
            raise RuntimeError(f"CopilotKit deletion failed: {e}")
