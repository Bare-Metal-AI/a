from .base import AgentFrameworkAdapter
from config.settings import settings
import httpx
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class MCPAdapter(AgentFrameworkAdapter):
    """Adapter for Model Context Protocol (MCP) servers."""

    def __init__(self):
        self.mcp_server_url = settings.get("MCP_SERVER_URL", "http://localhost:8080")
        self.client = httpx.AsyncClient()
        self.memory_store = {}
        logger.info(f"Initialized MCP adapter with server URL: {self.mcp_server_url}")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create an agent on an MCP server."""
        try:
            agent_id = f"mcp-{name}-{instance_id}"
            resp = await self.client.post(
                f"{self.mcp_server_url}/agents",
                json={
                    "name": name,
                    "vector_store": {"type": instance_id.split("-")[0], "instance_id": instance_id, "collection": collection_name},
                    "model": model,
                    "tools": tools or []
                },
                timeout=10.0
            )
            resp.raise_for_status()
            mcp_agent_id = resp.json()["agent_id"]
            self.memory_store[agent_id] = mcp_agent_id
            logger.info(f"Created MCP agent {agent_id} with MCP ID {mcp_agent_id}")
            return agent_id
        except httpx.HTTPStatusError as e:
            logger.error(f"MCP agent creation failed: {e.response.text}")
            raise RuntimeError(f"MCP agent creation failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error in MCP agent creation: {e}")
            raise RuntimeError(f"MCP agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query an MCP agent."""
        try:
            mcp_agent_id = self.memory_store.get(agent_id)
            if not mcp_agent_id:
                raise ValueError(f"Agent {agent_id} not found")
            resp = await self.client.post(
                f"{self.mcp_server_url}/agents/{mcp_agent_id}/query",
                json={"query": query, "max_tokens": max_tokens, "temperature": temperature},
                timeout=10.0
            )
            resp.raise_for_status()
            data = resp.json()
            output = data["response"]
            tokens = data.get("tokens", len(query.split()) + len(output.split()))
            cost = tokens * 0.0001 / 1_000_000  # Rough estimate
            logger.info(f"Queried MCP agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except httpx.HTTPStatusError as e:
            logger.error(f"MCP query failed: {e.response.text}")
            raise RuntimeError(f"MCP query failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error in MCP query: {e}")
            raise RuntimeError(f"MCP query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete an MCP agent."""
        try:
            mcp_agent_id = self.memory_store.get(agent_id)
            if mcp_agent_id:
                resp = await self.client.delete(
                    f"{self.mcp_server_url}/agents/{mcp_agent_id}",
                    timeout=10.0
                )
                resp.raise_for_status()
                del self.memory_store[agent_id]
                logger.info(f"Deleted MCP agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except httpx.HTTPStatusError as e:
            logger.error(f"MCP deletion failed: {e.response.text}")
            raise RuntimeError(f"MCP deletion failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error in MCP deletion: {e}")
            raise RuntimeError(f"MCP deletion failed: {e}")
