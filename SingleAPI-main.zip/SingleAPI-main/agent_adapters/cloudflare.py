from .base import AgentFrameworkAdapter
from cloudflare import Cloudflare
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class CloudflareAdapter(AgentFrameworkAdapter):
    """Adapter for Cloudflare AI Workers."""

    def __init__(self):
        self.client = Cloudflare(api_token=settings.cloudflare_api_token)
        self.memory_store = {}
        logger.info("Initialized Cloudflare adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a Cloudflare agent (simplified Worker)."""
        try:
            agent_id = f"cloudflare-{name}-{instance_id}"
            self.memory_store[agent_id] = {"model": model, "collection": collection_name}
            logger.info(f"Created Cloudflare agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create Cloudflare agent: {e}")
            raise RuntimeError(f"Cloudflare agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a Cloudflare agent (simplified)."""
        try:
            if agent_id not in self.memory_store:
                raise ValueError(f"Agent {agent_id} not found")
            model = self.memory_store[agent_id]["model"]
            response = await self.client.workers.ai.run(
                model=model,
                input={"prompt": query, "max_tokens": max_tokens, "temperature": temperature},
                account_id=settings.cloudflare_account_id
            )
            output = response["result"]
            tokens = response.get("usage", {}).get("total_tokens", len(query.split()) + len(output.split()))
            cost = tokens * 0.01 / 1_000_000  # Rough estimate
            logger.info(f"Queried Cloudflare agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Cloudflare query failed: {e}")
            raise RuntimeError(f"Cloudflare query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a Cloudflare agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted Cloudflare agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete Cloudflare agent: {e}")
            raise RuntimeError(f"Cloudflare deletion failed: {e}")
