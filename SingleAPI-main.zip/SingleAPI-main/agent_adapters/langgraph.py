from .base import AgentFrameworkAdapter
from langgraph.graph import Graph
from langchain.chat_models import ChatOpenAI
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class LangGraphAdapter(AgentFrameworkAdapter):
    """Adapter for LangGraph framework."""

    def __init__(self):
        self.memory_store = {}
        logger.info("Initialized LangGraph adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a LangGraph agent."""
        try:
            agent_id = f"langgraph-{name}-{instance_id}"
            llm = ChatOpenAI(model_name=model, api_key=settings.api_key_openai)
            # Simplified graph: query -> respond
            graph = Graph()
            graph.add_node("query", lambda state: {"query": state["input"]})
            graph.add_node("respond", lambda state: {"output": llm.invoke(state["query"]).content})
            graph.add_edge("query", "respond")
            graph.set_entry_point("query")
            graph.set_finish_point("respond")
            self.memory_store[agent_id] = graph.compile()
            logger.info(f"Created LangGraph agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create LangGraph agent: {e}")
            raise RuntimeError(f"LangGraph agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a LangGraph agent."""
        try:
            graph = self.memory_store.get(agent_id)
            if not graph:
                raise ValueError(f"Agent {agent_id} not found")
            result = await graph.arun({"input": query})
            output = result["output"]
            tokens = len(query.split()) + len(output.split())
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried LangGraph agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"LangGraph query failed: {e}")
            raise RuntimeError(f"LangGraph query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a LangGraph agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted LangGraph agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete LangGraph agent: {e}")
            raise RuntimeError(f"LangGraph deletion failed: {e}")
