from .base import AgentFrameworkAdapter
from jina import Client
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class JinaAdapter(AgentFrameworkAdapter):
    """Adapter for Jina framework."""

    def __init__(self, host: str = "localhost", port: int = 12345):
        self.client = Client(host=f"grpc://{host}:{port}")
        self.memory_store = {}
        logger.info("Initialized Jina adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a Jina agent (simplified)."""
        try:
            agent_id = f"jina-{name}-{instance_id}"
            self.memory_store[agent_id] = {"collection": collection_name}
            logger.info(f"Created Jina agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create Jina agent: {e}")
            raise RuntimeError(f"Jina agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a Jina agent (simplified)."""
        try:
            if agent_id not in self.memory_store:
                raise ValueError(f"Agent {agent_id} not found")
            # Simplified: assumes Jina flow is running externally
            response = await self.client.post("/search", {"text": query})
            output = response.texts[0].text
            tokens = len(query.split()) + len(output.split())
            cost = tokens * 0.01 / 1_000_000  # Rough estimate
            logger.info(f"Queried Jina agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Jina query failed: {e}")
            raise RuntimeError(f"Jina query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a Jina agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted Jina agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete Jina agent: {e}")
            raise RuntimeError(f"Jina deletion failed: {e}")
