from abc import ABC, abstractmethod
from typing import Tuple
import logging

logger = logging.getLogger(__name__)

class AgentFrameworkAdapter(ABC):
    """Base class for AI agent framework adapters."""

    @abstractmethod
    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: list) -> str:
        """Create an agent and return its ID."""

    @abstractmethod
    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query an agent and return response, tokens, cost."""

    @abstractmethod
    async def delete_agent(self, agent_id: str) -> None:
        """Delete an agent."""
