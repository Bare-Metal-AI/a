from .base import AgentFrameworkAdapter
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.memory import ConversationBufferMemory
from adapters.pgvector import PgVectorAdapter
from ai_adapters.registry import registry as ai_registry
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class LangChainAdapter(AgentFrameworkAdapter):
    """Adapter for LangChain framework."""

    def __init__(self):
        self.adapters = { "pgvector": PgVectorAdapter() }
        self.ai_adapters = ai_registry
        self.memory_store = {}

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a LangChain agent with memory and retriever."""
        try:
            agent_id = f"langchain-{name}-{instance_id}"
            db_adapter = self.adapters.get("pgvector")  # Simplified for this example
            llm = ChatOpenAI(model_name=model, api_key=settings.api_key_openai)
            memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
            # Mock vector store retriever (assume adapter provides this)
            retriever = await self._get_retriever(db_adapter, instance_id, collection_name)
            chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=retriever, memory=memory)
            self.memory_store[agent_id] = chain
            logger.info(f"Created LangChain agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create LangChain agent: {e}")
            raise RuntimeError(f"Agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query the LangChain agent."""
        try:
            chain = self.memory_store.get(agent_id)
            if not chain:
                raise ValueError(f"Agent {agent_id} not found")
            response = await chain.acall({"query": query})
            output = response["result"]
            tokens = len(query.split()) + len(output.split())  # Approximate
            cost = await self.ai_adapters.get("gpt4o").estimate_cost(tokens)
            logger.info(f"Queried agent {agent_id}: {output[:50]}... ({tokens} tokens)")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Agent query failed: {e}")
            raise RuntimeError(f"Query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete the LangChain agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found for deletion")
        except Exception as e:
            logger.error(f"Failed to delete agent {agent_id}: {e}")
            raise RuntimeError(f"Deletion failed: {e}")

    async def _get_retriever(self, adapter, instance_id: str, collection_name: str):
        """Mock retriever setup (simplified)."""
        # In a real scenario, this would integrate with the adapter's vector store
        from langchain.vectorstores import Chroma  # Placeholder for compatibility
        return Chroma(collection_name=collection_name).as_retriever()
