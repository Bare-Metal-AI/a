from .base import AgentFrameworkAdapter
from llama_index import VectorStoreIndex, ServiceContext
from llama_index.llms import OpenAI
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class LlamaIndexAdapter(AgentFrameworkAdapter):
    """Adapter for LlamaIndex framework."""

    def __init__(self):
        self.memory_store = {}
        logger.info("Initialized LlamaIndex adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a LlamaIndex agent."""
        try:
            agent_id = f"llamaindex-{name}-{instance_id}"
            llm = OpenAI(model=model, api_key=settings.api_key_openai)
            service_context = ServiceContext.from_defaults(llm=llm)
            # Mock vector store (simplified)
            index = VectorStoreIndex.from_documents([], service_context=service_context)
            self.memory_store[agent_id] = index.as_query_engine()
            logger.info(f"Created LlamaIndex agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create LlamaIndex agent: {e}")
            raise RuntimeError(f"LlamaIndex agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a LlamaIndex agent."""
        try:
            query_engine = self.memory_store.get(agent_id)
            if not query_engine:
                raise ValueError(f"Agent {agent_id} not found")
            response = await query_engine.aquery(query)
            output = str(response)
            tokens = len(query.split()) + len(output.split())  # Approximate
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried LlamaIndex agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"LlamaIndex query failed: {e}")
            raise RuntimeError(f"LlamaIndex query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a LlamaIndex agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted LlamaIndex agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete LlamaIndex agent: {e}")
            raise RuntimeError(f"LlamaIndex deletion failed: {e}")
