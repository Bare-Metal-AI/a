from .base import AgentFrameworkAdapter
from httpx import AsyncClient
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class LangbaseAdapter(AgentFrameworkAdapter):
    """Adapter for Langbase framework."""

    def __init__(self, api_key: str = "your-langbase-api-key"):
        self.client = AsyncClient(base_url="https://api.langbase.com")
        self.api_key = api_key
        self.memory_store = {}
        logger.info("Initialized Langbase adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a Langbase agent."""
        try:
            agent_id = f"langbase-{name}-{instance_id}"
            resp = await self.client.post(
                "/agents",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"name": name, "model": model}
            )
            resp.raise_for_status()
            self.memory_store[agent_id] = {"langbase_id": resp.json()["id"], "collection": collection_name}
            logger.info(f"Created Langbase agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create Langbase agent: {e}")
            raise RuntimeError(f"Langbase agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a Langbase agent."""
        try:
            agent_data = self.memory_store.get(agent_id)
            if not agent_data:
                raise ValueError(f"Agent {agent_id} not found")
            resp = await self.client.post(
                f"/agents/{agent_data['langbase_id']}/query",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"query": query, "max_tokens": max_tokens, "temperature": temperature}
            )
            resp.raise_for_status()
            data = resp.json()
            output = data["response"]
            tokens = data.get("tokens", len(query.split()) + len(output.split()))
            cost = tokens * 0.01 / 1_000_000  # Rough estimate
            logger.info(f"Queried Langbase agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Langbase query failed: {e}")
            raise RuntimeError(f"Langbase query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a Langbase agent."""
        try:
            agent_data = self.memory_store.get(agent_id)
            if agent_data:
                resp = await self.client.delete(
                    f"/agents/{agent_data['langbase_id']}",
                    headers={"Authorization": f"Bearer {self.api_key}"}
                )
                resp.raise_for_status()
                del self.memory_store[agent_id]
                logger.info(f"Deleted Langbase agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete Langbase agent: {e}")
            raise RuntimeError(f"Langbase deletion failed: {e}")
