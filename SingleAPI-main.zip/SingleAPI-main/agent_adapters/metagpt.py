from .base import AgentFrameworkAdapter
from metagpt.agent import Agent as MetaGPTAgent
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class MetaGPTAdapter(AgentFrameworkAdapter):
    """Adapter for MetaGPT framework."""

    def __init__(self):
        self.memory_store = {}
        logger.info("Initialized MetaGPT adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a MetaGPT agent."""
        try:
            agent_id = f"metagpt-{name}-{instance_id}"
            agent = MetaGPTAgent(
                name=name,
                llm={"model": model, "api_key": settings.api_key_openai}
            )
            self.memory_store[agent_id] = agent
            logger.info(f"Created MetaGPT agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create MetaGPT agent: {e}")
            raise RuntimeError(f"MetaGPT agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a MetaGPT agent."""
        try:
            agent = self.memory_store.get(agent_id)
            if not agent:
                raise ValueError(f"Agent {agent_id} not found")
            output = await agent.run(query)
            tokens = len(query.split()) + len(output.split())  # Approximate
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried MetaGPT agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"MetaGPT query failed: {e}")
            raise RuntimeError(f"MetaGPT query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a MetaGPT agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted MetaGPT agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete MetaGPT agent: {e}")
            raise RuntimeError(f"MetaGPT deletion failed: {e}")
