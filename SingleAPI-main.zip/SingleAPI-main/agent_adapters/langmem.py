from .base import AgentFrameworkAdapter
from langmem import AsyncMemoryClient
from config.settings import settings
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

class LangMemAdapter(AgentFrameworkAdapter):
    """Adapter for LangMem framework."""

    def __init__(self):
        self.client = AsyncMemoryClient(api_key=settings.api_key_openai)
        self.memory_store = {}
        logger.info("Initialized LangMem adapter")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a LangMem agent."""
        try:
            agent_id = f"langmem-{name}-{instance_id}"
            memory = await self.client.create_memory(collection_name)
            self.memory_store[agent_id] = memory
            logger.info(f"Created LangMem agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create LangMem agent: {e}")
            raise RuntimeError(f"LangMem agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a LangMem agent."""
        try:
            memory = self.memory_store.get(agent_id)
            if not memory:
                raise ValueError(f"Agent {agent_id} not found")
            await memory.add_message({"role": "user", "content": query})
            response = await memory.get_context()
            output = response["summary"]
            tokens = len(query.split()) + len(output.split())
            cost = tokens * 0.005 / 1_000_000  # Rough estimate
            logger.info(f"Queried LangMem agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"LangMem query failed: {e}")
            raise RuntimeError(f"LangMem query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        """Delete a LangMem agent."""
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                logger.info(f"Deleted LangMem agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete LangMem agent: {e}")
            raise RuntimeError(f"LangMem deletion failed: {e}")
