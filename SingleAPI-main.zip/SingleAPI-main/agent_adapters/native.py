from .base import AgentFrameworkAdapter
from api.services.security import SecurityService
from api.services.cache import CacheService
from ai_adapters.registry import registry as ai_registry
from adapters.registry import registry as db_registry
from adapters.neo4j import Neo4jAdapter
import logging
import httpx
import json
import fireducks.pandas as pd
from typing import Tuple, List, Dict, Any, Callable

logger = logging.getLogger(__name__)

class Tool:
    """Tool definition for native agents."""
    def __init__(self, name: str, func: Callable[[str], str], description: str):
        self.name = name
        self.func = func
        self.description = description

class NativeAgentAdapter(AgentFrameworkAdapter):
    """Enhanced native agent adapter with FireDucks and graph memory."""

    def __init__(self, security: SecurityService, cache: CacheService):
        self.security = security
        self.cache = cache
        self.memory_store: Dict[str, List[Dict[str, str]]] = {}
        self.graph_store = Neo4jAdapter()
        self.tools: Dict[str, Tool] = {
            "search": Tool("search", self._search_tool, "Search the vector database"),
            "analyze": Tool("analyze", self._analyze_tool, "Analyze tabular data"),
            "email": Tool("email", self._email_tool, "Send an email"),
            "csv_summary": Tool("csv_summary", self._csv_summary_tool, "Summarize CSV data"),
            "calendar": Tool("calendar", self._calendar_tool, "Check calendar events"),
        }
        logger.info("Initialized Native agent adapter with enhanced tools")

    async def _search_tool(self, query: str) -> str:
        """Search tool with hybrid retrieval."""
        try:
            adapter = db_registry.get("pgvector")
            vector_results = await adapter.search(self.instance_id, self.collection_name, [0.1] * 1536, 5)
            fulltext_results = await adapter.search_fulltext(self.instance_id, self.collection_name, query, 5)
            df = pd.DataFrame(vector_results + fulltext_results)  # FireDucks
            df = df.drop_duplicates(subset=["id"])  # Fast deduplication
            return df["metadata"].to_json()
        except Exception as e:
            logger.error(f"Search tool failed: {e}")
            return "Search failed"

    async def _analyze_tool(self, data: str) -> str:
        try:
            df = pd.read_json(data)
            summary = df.describe().to_json()
            return summary
        except Exception as e:
            logger.error(f"Analyze tool failed: {e}")
            return "Analysis failed"

    async def _email_tool(self, message: str) -> str:
        try:
            return "Email sent: " + message  # Simulated
        except Exception as e:
            logger.error(f"Email tool failed: {e}")
            return "Email failed"

    async def _csv_summary_tool(self, csv_data: str) -> str:
        try:
            df = pd.read_csv(pd.compat.StringIO(csv_data))  # FireDucks
            return df.describe().to_json()
        except Exception as e:
            logger.error(f"CSV summary tool failed: {e}")
            return "CSV summary failed"

    async def _calendar_tool(self, date: str) -> str:
        try:
            return f"Events on {date}: Meeting at 10am"  # Simulated
        except Exception as e:
            logger.error(f"Calendar tool failed: {e}")
            return "Calendar check failed"

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, tools: List[str]) -> str:
        """Create a native agent with enhanced features."""
        try:
            agent_id = f"native-{name}-{instance_id}"
            self.instance_id = instance_id
            self.collection_name = collection_name
            self.memory_store[agent_id] = [{"role": "system", "content": f"You are an AI assistant for {collection_name}. Tools: {', '.join(tools or [])}"}]
            if tools:
                for tool in tools:
                    if tool not in self.tools:
                        raise ValueError(f"Unsupported tool: {tool}")
            await self.cache.set(f"memory:{agent_id}", agent_id, self.memory_store[agent_id], ttl=None)
            await self.graph_store.insert(agent_id, {"id": agent_id, "metadata": {"created": "2025-03-03"}})
            logger.info(f"Created Native agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Failed to create Native agent: {e}")
            raise RuntimeError(f"Native agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query a native agent with enhanced features."""
        try:
            if agent_id not in self.memory_store:
                cached_memory = await self.cache.get(f"memory:{agent_id}", "system")
                self.memory_store[agent_id] = cached_memory or []
                if not self.memory_store[agent_id]:
                    raise ValueError(f"Agent {agent_id} not found")
            
            self.memory_store[agent_id].append({"role": "user", "content": query})
            graph_context = await self.graph_store.search(agent_id, self.instance_id, [0.1] * 1536, 3)  # Graph memory
            graph_text = "\n".join([r["metadata"].get("content", "") for r in graph_context])
            
            adapter = db_registry.get("pgvector")
            search_results = await adapter.search(self.instance_id, self.collection_name, [0.1] * 1536, 3)
            df = pd.DataFrame(search_results)
            context = "\n".join(df["metadata"].apply(lambda x: x.get("content", "")))
            full_prompt = f"{graph_text}\n{context}\nMemory: {json.dumps(self.memory_store[agent_id])}\nQuery: {query}\nRespond in JSON with 'output' or 'tool_call'."

            ai_adapter = ai_registry.get(model)
            output, tokens = await ai_adapter.generate(full_prompt, max_tokens, temperature)
            cost = await ai_adapter.estimate_cost(tokens)
            
            try:
                response_json = json.loads(output)
                if "tool_call" in response_json:
                    tool_name = response_json["tool_call"]["name"]
                    tool_input = response_json["tool_call"]["input"]
                    if tool_name in self.tools:
                        tool_output = await self.tools[tool_name].func(tool_input)
                        self.memory_store[agent_id].append({"role": "tool", "content": f"{tool_name}: {tool_output}"})
                        full_prompt += f"\nTool Result: {tool_output}"
                        output, tokens_add = await ai_adapter.generate(full_prompt, max_tokens, temperature)
                        tokens += tokens_add
                        cost += await ai_adapter.estimate_cost(tokens_add)
                else:
                    output = response_json["output"]
            except json.JSONDecodeError:
                pass

            if "mcp://" in model:
                async with httpx.AsyncClient() as client:
                    mcp_response = await client.post(model, json={"query": full_prompt, "max_tokens": max_tokens})
                    output = mcp_response.json()["response"]
                    tokens = mcp_response.json().get("tokens", tokens)
                    cost = 0.0001 * tokens

            self.memory_store[agent_id].append({"role": "assistant", "content": output})
            await self.cache.set(f"memory:{agent_id}", "system", self.memory_store[agent_id], ttl=None)
            await self.graph_store.insert(agent_id, {"id": f"{agent_id}-{tokens}", "metadata": {"response": output}})
            
            final_output = self.security.encrypt(output) if settings.hipaa_enabled else output
            logger.info(f"Queried Native agent {agent_id}: {tokens} tokens")
            return final_output, tokens, cost
        except Exception as e:
            logger.error(f"Native query failed: {e}")
            raise RuntimeError(f"Native query failed: {e}")

    async def delete_agent(self, agent_id: str) -> None:
        try:
            if agent_id in self.memory_store:
                del self.memory_store[agent_id]
                await self.cache.delete(f"memory:{agent_id}", "system")
                logger.info(f"Deleted Native agent {agent_id}")
            else:
                logger.warning(f"Agent {agent_id} not found")
        except Exception as e:
            logger.error(f"Failed to delete Native agent: {e}")
            raise RuntimeError(f"Native deletion failed: {e}")
