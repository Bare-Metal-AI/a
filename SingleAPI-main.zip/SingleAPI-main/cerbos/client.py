from cerbos import CerbosClient as CerbosSDKClient
from config.settings import settings
import logging

logger = logging.getLogger(__name__)

class CerbosClient:
    """Wrapper for Cerbos SDK client."""

    def __init__(self):
        self.client = CerbosSDKClient(host=settings.cerbos_host)
        logger.info("Cerbos client initialized")

    def is_allowed(self, principal: dict, resource: dict, action: str) -> bool:
        """Check if an action is allowed for a principal on a resource."""
        try:
            result = self.client.is_allowed(principal=principal, resource=resource, action=action)
            logger.debug(f"Cerbos check: {principal['id']} on {resource['kind']}:{action} -> {result}")
            return result
        except Exception as e:
            logger.error(f"Cerbos check failed: {e}")
            raise RuntimeError(f"Cerbos check failed: {e}")
