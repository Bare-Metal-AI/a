from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request, Response
import time
import logging

logger = logging.getLogger(__name__)

class ThrottleMiddleware(BaseHTTPMiddleware):
    """Middleware to throttle requests based on time."""

    def __init__(self, app, max_requests: int = 100, window: int = 60):
        super().__init__(app)
        self.max_requests = max_requests
        self.window = window
        self.request_counts = {}

    async def dispatch(self, request: Request, call_next) -> Response:
        """Throttle requests based on client IP."""
        client_ip = request.client.host
        current_time = time.time()
        
        if client_ip not in self.request_counts:
            self.request_counts[client_ip] = {"count": 0, "start": current_time}
        
        client_data = self.request_counts[client_ip]
        if current_time - client_data["start"] > self.window:
            client_data["count"] = 0
            client_data["start"] = current_time

        if client_data["count"] >= self.max_requests:
            logger.warning(f"Throttling request from {client_ip}: exceeded {self.max_requests} requests")
            return Response(content="Too Many Requests", status_code=429)
        
        client_data["count"] += 1
        response = await call_next(request)
        return response
