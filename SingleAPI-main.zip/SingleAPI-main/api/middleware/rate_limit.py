from slowapi import Limiter
from slowapi.util import get_remote_address
from fastapi import Request
import logging

logger = logging.getLogger(__name__)

def get_principal_key(request: Request):
    """Key function for rate limiting based on principal."""
    principal = request.headers.get("X-Principal", get_remote_address(request))
    return principal

limiter = Limiter(key_func=get_principal_key)  # Mitigation 8: User-based

def setup_rate_limit(app):
    """Configure rate limiting for the API."""
    app.state.limiter = limiter
    logger.info("Rate limiting configured with slowapi, user-based")
