from fastapi import APIRouter, Depends, HTTPException
from api.models.external import ExternalImportRequest, ExternalImportResponse
from api.dependencies import check_rbac, audit_log, get_external_service
from api.services.external import ExternalService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/external", tags=["external"])
external_service = ExternalService()

@router.post("/import", response_model=ExternalImportResponse, description="Import data from an external source")
async def import_external(
    request: ExternalImportRequest,
    principal: str = Depends(check_rbac(resource="external", action="create")),
    _ = Depends(audit_log(resource="external", action="create")),
    external_service: ExternalService = Depends(get_external_service)
):
    """Import data from an external source into a collection."""
    try:
        records = await external_service.import_data(
            request.instance_id, request.collection_name, request.source_type, request.source_url, request.api_key
        )
        logger.info(f"Imported {records} records from {request.source_type} by {principal}")
        return ExternalImportResponse(status="imported", records=records)
    except Exception as e:
        logger.error(f"External import failed: {e}")
        raise HTTPException(status_code=500, detail=f"External import failed: {str(e)}")
