from fastapi import APIRouter, Depends, HTTPException
from api.models.collection import CollectionCreateRequest, CollectionResponse
from api.dependencies import check_rbac, audit_log, get_db_adapter
from typing import Dict
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/collections", tags=["collections"])

@router.post("/{instance_id}", response_model=CollectionResponse, description="Create a new collection")
async def create_collection(
    instance_id: str,
    request: CollectionCreateRequest,
    principal: str = Depends(check_rbac(resource="collection", action="create")),
    _ = Depends(audit_log(resource="collection", action="create")),
    adapter: VectorDBAdapter = Depends(get_db_adapter)
):
    """Create a new collection in the specified instance."""
    try:
        await adapter.create_collection(instance_id, request.name)
        logger.info(f"Created collection {request.name} for instance {instance_id} by {principal}")
        return CollectionResponse(status="created", collection_name=request.name)
    except Exception as e:
        logger.error(f"Failed to create collection {request.name}: {e}")
        raise HTTPException(status_code=500, detail=f"Collection creation failed: {str(e)}")

@router.put("/{instance_id}/{collection_name}/upsert", response_model=CollectionResponse, description="Upsert data into a collection")
async def upsert_collection(
    instance_id: str,
    collection_name: str,
    data: Dict[str, Any],
    principal: str = Depends(check_rbac(resource="collection", action="update")),
    _ = Depends(audit_log(resource="collection", action="update")),
    adapter: VectorDBAdapter = Depends(get_db_adapter)
):
    """Upsert data into an existing collection."""
    try:
        await adapter.insert(instance_id, collection_name, data)
        logger.info(f"Upserted data into {collection_name} for instance {instance_id} by {principal}")
        return CollectionResponse(status="success", collection_name=collection_name)
    except Exception as e:
        logger.error(f"Failed to upsert data into {collection_name}: {e}")
        raise HTTPException(status_code=500, detail=f"Upsert failed: {str(e)}")
