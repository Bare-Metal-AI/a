from fastapi import APIRouter, Depends, HTTPException
from api.models.migration import MigrationRequest, MigrationResponse
from api.dependencies import check_rbac, audit_log, get_temporal_client
from orchestration.workflows import MigrationWorkflow
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/migration", tags=["migration"])

@router.post("/copy", response_model=MigrationResponse, description="Copy data between collections or instances")
async def copy_data(
    request: MigrationRequest,
    principal: str = Depends(check_rbac(resource="migration", action="create")),
    _ = Depends(audit_log(resource="migration", action="create")),
    client = Depends(get_temporal_client)
):
    """Initiate a data migration using Temporal."""
    try:
        workflow_id = f"migrate-{request.source_instance_id}-to-{request.target_instance_id}"
        result = await client.start_workflow(
            MigrationWorkflow.run,
            request.dict(),
            id=workflow_id,
            task_queue="migration-queue"
        )
        logger.info(f"Migration {workflow_id} started by {principal}: {result}")
        return MigrationResponse(message=result)
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        raise HTTPException(status_code=500, detail=f"Migration failed: {str(e)}")
