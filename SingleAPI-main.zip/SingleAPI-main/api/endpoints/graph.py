from fastapi import APIRouter, Depends, HTTPException
from api.models.graph import GraphNodeRequest, GraphNodeResponse
from api.dependencies import check_rbac, audit_log, get_graph_service
from api.services.graph import GraphService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/graph", tags=["graph"])
graph_service = GraphService()

@router.post("/nodes", response_model=GraphNodeResponse, description="Create a graph node in Neo4j")
async def create_node(
    request: GraphNodeRequest,
    principal: str = Depends(check_rbac(resource="graph", action="create")),
    _ = Depends(audit_log(resource="graph", action="create")),
    graph_service: GraphService = Depends(get_graph_service)
):
    """Create a new node in the graph database."""
    try:
        node_id = await graph_service.create_node(request.node_id, request.properties)
        logger.info(f"Created graph node {node_id} by {principal}")
        return GraphNodeResponse(status="created", node_id=node_id)
    except Exception as e:
        logger.error(f"Graph node creation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Graph node creation failed: {str(e)}")
