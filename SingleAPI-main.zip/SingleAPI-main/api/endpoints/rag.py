from fastapi import APIRouter, Depends, HTTPException
from api.models.rag import RAGPipelineRequest, RAGPipelineResponse, RAGQueryRequest, RAGQueryResponse
from api.dependencies import check_rbac, audit_log, get_rag_service, get_cache_service
from api.services.rag import RAGService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/rag", tags=["rag"])
rag_service = RAGService()

@router.post("/create", response_model=RAGPipelineResponse, description="Create a RAG pipeline")
async def create_rag_pipeline(
    request: RAGPipelineRequest,
    principal: str = Depends(check_rbac(resource="rag", action="create")),
    _ = Depends(audit_log(resource="rag", action="create")),
    rag_service: RAGService = Depends(get_rag_service),
    cache: CacheService = Depends(get_cache_service)
):
    """Create a new RAG pipeline."""
    try:
        pipeline_id = await rag_service.create_rag_pipeline(request)
        await cache.set(f"rag:{pipeline_id}", principal, {"status": "created"}, ttl=3600)
        logger.info(f"Created RAG pipeline {pipeline_id} by {principal}")
        return RAGPipelineResponse(pipeline_id=pipeline_id, status="created")
    except Exception as e:
        logger.error(f"RAG pipeline creation failed: {e}")
        raise HTTPException(status_code=500, detail=f"RAG pipeline creation failed: {str(e)}")

@router.post("/{pipeline_id}/query", response_model=RAGQueryResponse, description="Query a RAG pipeline")
async def query_rag_pipeline(
    pipeline_id: str,
    request: RAGQueryRequest,
    principal: str = Depends(check_rbac(resource="rag", action="query")),
    _ = Depends(audit_log(resource="rag", action="query")),
    rag_service: RAGService = Depends(get_rag_service),
    cache: CacheService = Depends(get_cache_service)
):
    """Query an existing RAG pipeline."""
    cache_key = f"rag_query:{pipeline_id}:{request.query}"
    try:
        cached_result = await cache.get(cache_key, principal)
        if cached_result:
            logger.debug(f"Cache hit for RAG query {cache_key}")
            return RAGQueryResponse(**cached_result)

        output, tokens, cost = await rag_service.query_rag_pipeline(
            pipeline_id, request.query, request.max_tokens, request.temperature
        )
        response = RAGQueryResponse(pipeline_id=pipeline_id, response=output, tokens=tokens, estimated_cost_usd=cost)
        await cache.set(cache_key, principal, response.dict(), ttl=300)
        logger.info(f"Queried RAG pipeline {pipeline_id} by {principal}: {tokens} tokens")
        return response
    except ValueError as e:
        logger.error(f"RAG query failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"RAG query error: {e}")
        raise HTTPException(status_code=500, detail=f"RAG query failed: {str(e)}")
