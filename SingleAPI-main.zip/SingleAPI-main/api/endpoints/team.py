from fastapi import APIRouter, Depends, HTTPException
from api.models.team import TeamCreateRequest, TeamResponse
from api.dependencies import check_rbac, audit_log, get_team_service
from api.services.team import TeamService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/team", tags=["team"])
team_service = TeamService()

@router.post("/create", response_model=TeamResponse, description="Create a new team")
async def create_team(
    request: TeamCreateRequest,
    principal: str = Depends(check_rbac(resource="team", action="create")),
    _ = Depends(audit_log(resource="team", action="create")),
    team_service: TeamService = Depends(get_team_service)
):
    """Create a new team with specified members."""
    try:
        team_id = await team_service.create_team(request.team_name, request.members)
        logger.info(f"Created team {team_id} by {principal}")
        return TeamResponse(team_id=team_id)
    except Exception as e:
        logger.error(f"Team creation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Team creation failed: {str(e)}")
