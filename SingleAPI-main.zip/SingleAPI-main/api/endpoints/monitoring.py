from fastapi import APIRouter, Depends, HTTPException
from api.models.monitoring import UsageResponse
from api.dependencies import check_rbac, audit_log, get_monitoring_service
from api.services.monitoring import MonitoringService
from api.monitoring.stripe import StripeMeter
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/monitoring", tags=["monitoring"])  # Mitigation 5: Versioned

@router.get("/usage", response_model=UsageResponse, description="Retrieve usage metrics")
async def get_usage(
    principal: str = Depends(check_rbac(resource="monitoring", action="read")),
    _ = Depends(audit_log(resource="monitoring", action="read")),
    monitoring_service: MonitoringService = Depends(get_monitoring_service)
):
    """Retrieve usage metrics including requests, tokens, and costs."""
    try:
        usage = await monitoring_service.get_usage(principal)
        logger.info(f"Retrieved usage metrics for {principal}")
        return UsageResponse(**usage)
    except Exception as e:
        logger.error(f"Failed to retrieve usage metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Usage retrieval failed: {str(e)}")

@router.get("/forecast/{days}", description="Forecast cost for next N days")
async def forecast_cost(
    days: int,
    principal: str = Depends(check_rbac(resource="monitoring", action="read")),
    _ = Depends(audit_log(resource="monitoring", action="forecast")),
    stripe_meter: StripeMeter = Depends(lambda: StripeMeter())
):
    """Forecast cost based on current usage."""
    try:
        forecast = await stripe_meter.forecast_cost(principal, days)
        logger.info(f"Cost forecast for {principal} over {days} days: ${forecast['forecasted_cost']:.2f}")
        return forecast
    except Exception as e:
        logger.error(f"Cost forecast failed: {e}")
        raise HTTPException(status_code=500, detail=f"Cost forecast failed: {str(e)}")
