from fastapi import APIRouter, Depends, HTTPException
from api.models.ai import AIRequest, AIResponse
from api.dependencies import check_rbac, audit_log, get_cache_service
from api.services.ai import AIService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ai", tags=["ai"])
ai_service = AIService()

@router.post("/", response_model=AIResponse, description="Unified endpoint for generative AI and embeddings")
async def process_ai(
    request: AIRequest,
    principal: str = Depends(check_rbac(resource="ai", action="create")),
    _ = Depends(audit_log(resource="ai", action="create")),
    cache: CacheService = Depends(get_cache_service)
):
    """Process AI tasks (generation or embedding) with caching."""
    cache_key = f"ai:{request.task}:{principal}:{hash(str(request))}"
    try:
        cached_result = await cache.get(cache_key, principal)
        if cached_result:
            logger.debug(f"Cache hit for AI request {cache_key}")
            return AIResponse(**cached_result)

        if request.task == "generate":
            result, tokens = await ai_service.generate(
                request.generate.prompt,
                request.generate.model,
                request.generate.max_tokens,
                request.generate.temperature
            )
            cost = await ai_service.estimate_cost(request.generate.model, tokens)
            response = AIResponse(task="generate", result=result, tokens=tokens, estimated_cost_usd=cost)
        elif request.task == "embed":
            embeddings, tokens = await ai_service.embed(request.embed.input, request.embed.model)
            cost = await ai_service.estimate_cost(request.embed.model, tokens)
            response = AIResponse(task="embed", result=embeddings, tokens=tokens, estimated_cost_usd=cost)
        else:
            logger.error(f"Invalid AI task: {request.task}")
            raise HTTPException(status_code=400, detail="Invalid task type")

        await cache.set(cache_key, principal, response.dict(), ttl=300)
        logger.info(f"Processed AI task {request.task} for {principal}: {tokens} tokens")
        return response
    except ValueError as e:
        logger.error(f"AI processing failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"AI processing error: {e}")
        raise HTTPException(status_code=500, detail=f"AI processing failed: {str(e)}")
