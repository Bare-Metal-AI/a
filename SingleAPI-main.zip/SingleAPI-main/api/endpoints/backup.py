from fastapi import APIRouter, Depends, HTTPException
from api.models.backup import BackupRequest, BackupResponse
from api.dependencies import check_rbac, audit_log, get_db_adapter, get_temporal_client
from orchestration.workflows import BackupWorkflow
import logging
from temporalio.client import Client

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/backup", tags=["backup"])

@router.post("/{instance_id}", response_model=BackupResponse, description="Create a backup of a collection or instance")
async def create_backup(
    instance_id: str,
    request: BackupRequest,
    principal: str = Depends(check_rbac(resource="backup", action="create")),
    _ = Depends(audit_log(resource="backup", action="create")),
    adapter: VectorDBAdapter = Depends(get_db_adapter),
    client: Client = Depends(get_temporal_client)
):
    """Initiate a backup process using Temporal."""
    try:
        workflow_id = f"backup-{instance_id}-{request.collection_name or 'all'}"
        result = await client.start_workflow(
            BackupWorkflow.run,
            {"instance_id": instance_id, "collection_name": request.collection_name},
            id=workflow_id,
            task_queue="backup-queue",
            # Compliance: Schedule recurring backups
            schedule=client.schedule.create(
                interval={"every": settings.backup_frequency_hours * 3600},  # Convert hours to seconds
                workflow_id=workflow_id
            )
        )
        backup_id = result
        logger.info(f"Backup {backup_id} started and scheduled for {instance_id} by {principal}")
        return BackupResponse(backup_id=backup_id)
    except Exception as e:
        logger.error(f"Backup creation failed for {instance_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Backup failed: {str(e)}")
