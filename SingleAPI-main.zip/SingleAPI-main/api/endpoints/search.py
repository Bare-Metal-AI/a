from fastapi import APIRouter, Depends, HTTPException
from api.models.search import SearchRequest, SearchResponse
from api.dependencies import check_rbac, audit_log, get_search_service
from api.services.search import SearchService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/search", tags=["search"])

@router.post("/fulltext", response_model=SearchResponse, description="Full-text search")
async def fulltext_search(
    request: SearchRequest,
    principal: str = Depends(check_rbac(resource="search", action="read")),
    _ = Depends(audit_log(resource="search", action="read")),
    search_service: SearchService = Depends(get_search_service)
):
    """Perform a full-text search."""
    try:
        results = await search_service.search(request.instance_id, request.collection_name, request.query, request.limit)
        logger.info(f"Full-text search by {principal}: {len(results)} results")
        return SearchResponse(results=results)
    except Exception as e:
        logger.error(f"Full-text search failed: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")
