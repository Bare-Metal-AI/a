from fastapi import APIRouter, Depends, HTTPException
from api.dependencies import check_rbac, audit_log, get_compliance_service
from api.services.compliance import ComplianceService
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/compliance", tags=["compliance"])  # Mitigation 5: Versioned

@router.post("/retention/{instance_id}/{collection_name}", description="Enforce data retention")
async def enforce_retention(
    instance_id: str,
    collection_name: str,
    principal: str = Depends(check_rbac(resource="compliance", action="manage")),
    _ = Depends(audit_log(resource="compliance", action="retention")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Enforce data retention policy."""
    try:
        await compliance_service.enforce_retention(instance_id, collection_name)
        logger.info(f"Retention enforced by {principal} for {collection_name} in {instance_id}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Retention enforcement failed: {e}")
        raise HTTPException(status_code=500, detail=f"Retention enforcement failed: {str(e)}")

@router.post("/consent/{user_id}", description="Record user consent")
async def record_consent(
    user_id: str,
    consent: bool,
    principal: str = Depends(check_rbac(resource="compliance", action="manage")),
    _ = Depends(audit_log(resource="compliance", action="consent")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Record user consent for GDPR."""
    try:
        await compliance_service.record_consent(user_id, consent)
        logger.info(f"Consent recorded by {principal} for {user_id}: {consent}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Consent recording failed: {e}")
        raise HTTPException(status_code=500, detail=f"Consent recording failed: {str(e)}")

@router.post("/erase/{user_id}", description="Erase user data")
async def erase_user_data(
    user_id: str,
    principal: str = Depends(check_rbac(resource="compliance", action="manage")),
    _ = Depends(audit_log(resource="compliance", action="erase")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Erase user data for GDPR/CCPA right to erasure."""
    try:
        await compliance_service.erase_user_data(user_id)
        logger.info(f"Data erased by {principal} for {user_id}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Data erasure failed: {e}")
        raise HTTPException(status_code=500, detail=f"Data erasure failed: {str(e)}")

@router.post("/incident", description="Report a security incident")
async def report_incident(
    incident: Dict[str, Any],
    principal: str = Depends(check_rbac(resource="compliance", action="report")),
    _ = Depends(audit_log(resource="compliance", action="incident")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Report a security incident."""
    try:
        await compliance_service.report_incident(incident)
        logger.info(f"Incident reported by {principal}: {incident['type']}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Incident reporting failed: {e}")
        raise HTTPException(status_code=500, detail=f"Incident reporting failed: {str(e)}")

@router.post("/risk", description="Log a risk for ISO 27001")
async def log_risk(
    risk: Dict[str, Any],
    principal: str = Depends(check_rbac(resource="compliance", action="manage")),
    _ = Depends(audit_log(resource="compliance", action="risk")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Log a risk for ISO 27001 compliance."""
    try:
        await compliance_service.log_risk(risk)
        logger.info(f"Risk logged by {principal}: {risk.get('type')}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Risk logging failed: {e}")
        raise HTTPException(status_code=500, detail=f"Risk logging failed: {str(e)}")

@router.post("/phi/{user_id}", description="Log PHI action for HIPAA")
async def log_phi_action(
    user_id: str,
    action: str,
    data_type: str,
    principal: str = Depends(check_rbac(resource="compliance", action="manage")),
    _ = Depends(audit_log(resource="compliance", action="phi")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Log PHI handling action for HIPAA compliance."""
    try:
        await compliance_service.log_phi_action(user_id, action, data_type)
        logger.info(f"PHI action logged by {principal} for {user_id}: {action}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"PHI action logging failed: {e}")
        raise HTTPException(status_code=500, detail=f"PHI action logging failed: {str(e)}")

@router.get("/export/{user_id}", description="Export user data for GDPR/CCPA")
async def export_user_data(
    user_id: str,
    principal: str = Depends(check_rbac(resource="compliance", action="manage")),
    _ = Depends(audit_log(resource="compliance", action="export")),
    compliance_service: ComplianceService = Depends(get_compliance_service)
):
    """Export user data for GDPR/CCPA data portability."""
    try:
        data = await compliance_service.export_user_data(user_id)
        logger.info(f"Data exported by {principal} for {user_id}")
        return data
    except Exception as e:
        logger.error(f"Data export failed: {e}")
        raise HTTPException(status_code=500, detail=f"Data export failed: {str(e)}")
