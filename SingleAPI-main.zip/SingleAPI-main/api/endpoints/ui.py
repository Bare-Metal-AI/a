from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from api.dependencies import check_rbac, audit_log
from api.templates import templates
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/ui", tags=["ui"])

@router.get("/dashboard", response_model=HTMLResponse, description="Render the dashboard")
async def dashboard(
    request: Request,
    principal: str = Depends(check_rbac(resource="ui", action="read")),
    _ = Depends(audit_log(resource="ui", action="read"))
):
    """Render the real-time dashboard."""
    try:
        metrics = {"latency": 8.5, "qps": 1200, "active_agents": 15}  # Simulated
        logger.info(f"Dashboard rendered for {principal}")
        return templates.TemplateResponse("dashboard.html", {"request": request, "metrics": metrics})
    except Exception as e:
        logger.error(f"Dashboard rendering failed: {e}")
        raise HTTPException(status_code=500, detail=f"Dashboard failed: {str(e)}")
