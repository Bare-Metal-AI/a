from fastapi import APIRouter, Depends, HTTPException
from api.models.instance import InstanceCreateRequest, InstanceResponse
from api.dependencies import check_rbac, audit_log, get_cloud_service
from api.services.cloud import CloudService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/instances", tags=["instances"])

@router.post("/{db_type}", response_model=InstanceResponse, description="Deploy a vector DB instance")
async def deploy_instance(
    db_type: str,
    request: InstanceCreateRequest,
    principal: str = Depends(check_rbac(resource="instance", action="create")),
    _ = Depends(audit_log(resource="instance", action="create")),
    cloud_service: CloudService = Depends(get_cloud_service)
):
    """Deploy a new vector database instance."""
    if db_type != request.db_type:
        logger.error(f"DB type mismatch: {db_type} vs {request.db_type}")
        raise HTTPException(status_code=400, detail="DB type mismatch in path and body")
    
    try:
        instance_id = await cloud_service.deploy_instance(request.dict())
        logger.info(f"Deployed instance {instance_id} for {principal}")
        return InstanceResponse(instance_id=instance_id, status="running")
    except Exception as e:
        logger.error(f"Failed to deploy instance: {e}")
        raise HTTPException(status_code=500, detail=f"Instance deployment failed: {str(e)}")
