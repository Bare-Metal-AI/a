from fastapi import APIRouter, Depends, HTTPException
from api.models.agents import AgentCreateRequest, AgentQueryRequest, AgentResponse
from api.dependencies import check_rbac, audit_log, get_agents_service, get_cache_service
from api.services.agents import AgentService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/agents", tags=["agents"])
agent_service = AgentService()

@router.post("/create", response_model=dict, description="Create an AI agent")
async def create_agent(
    request: AgentCreateRequest,
    principal: str = Depends(check_rbac(resource="agents", action="create")),
    _ = Depends(audit_log(resource="agents", action="create")),
    agent_service: AgentService = Depends(get_agents_service),
    cache: CacheService = Depends(get_cache_service)
):
    """Create a new AI agent with specified framework."""
    try:
        agent_id = await agent_service.create_agent(
            request.name, request.instance_id, request.collection_name, request.model, request.agent_type, request.tools
        )
        await cache.set(f"agent:{agent_id}", principal, {"status": "active"}, ttl=3600)
        logger.info(f"Created agent {agent_id} for {principal}")
        return {"agent_id": agent_id}
    except ValueError as e:
        logger.error(f"Agent creation failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Agent creation error: {e}")
        raise HTTPException(status_code=500, detail=f"Agent creation failed: {str(e)}")

@router.post("/query", response_model=AgentResponse, description="Query an AI agent")
async def query_agent(
    request: AgentQueryRequest,
    principal: str = Depends(check_rbac(resource="agents", action="query")),
    _ = Depends(audit_log(resource="agents", action="query")),
    agent_service: AgentService = Depends(get_agents_service),
    cache: CacheService = Depends(get_cache_service)
):
    """Query an existing AI agent."""
    cache_key = f"agent_query:{request.agent_id}:{request.query}"
    try:
        cached_result = await cache.get(cache_key, principal)
        if cached_result:
            logger.debug(f"Cache hit for agent query {cache_key}")
            return AgentResponse(**cached_result)

        output, tokens, cost = await agent_service.query_agent(
            request.agent_id, request.query, request.max_tokens, request.temperature
        )
        response = AgentResponse(agent_id=request.agent_id, response=output, tokens=tokens, estimated_cost_usd=cost)
        await cache.set(cache_key, principal, response.dict(), ttl=300)
        logger.info(f"Queried agent {request.agent_id} by {principal}: {tokens} tokens")
        return response
    except ValueError as e:
        logger.error(f"Agent query failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Agent query error: {e}")
        raise HTTPException(status_code=500, detail=f"Agent query failed: {str(e)}")
