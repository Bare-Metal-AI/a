from fastapi import APIRouter, Depends, HTTPException
from api.models.feedback import FeedbackRequest, FeedbackResponse
from api.dependencies import check_rbac, audit_log, get_feedback_service
from api.services.feedback import FeedbackService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/feedback", tags=["feedback"])
feedback_service = FeedbackService()

@router.post("/", response_model=FeedbackResponse, description="Submit user feedback")
async def submit_feedback(
    request: FeedbackRequest,
    principal: str = Depends(check_rbac(resource="feedback", action="create")),
    _ = Depends(audit_log(resource="feedback", action="create")),
    feedback_service: FeedbackService = Depends(get_feedback_service)
):
    """Submit feedback from a user."""
    try:
        await feedback_service.submit_feedback(request.user_id, request.message)
        logger.info(f"Feedback submitted by {request.user_id}: {request.message[:50]}...")
        return FeedbackResponse(status="success")
    except Exception as e:
        logger.error(f"Feedback submission failed: {e}")
        raise HTTPException(status_code=500, detail=f"Feedback submission failed: {str(e)}")
