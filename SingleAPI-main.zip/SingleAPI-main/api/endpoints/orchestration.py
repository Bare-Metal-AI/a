from fastapi import APIRouter, Depends, HTTPException
from api.models.orchestration import OrchestrationRequest, OrchestrationResponse
from api.dependencies import check_rbac, audit_log, get_orchestration_service, get_cache_service
from api.services.orchestration import OrchestrationService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/orchestration", tags=["orchestration"])
orchestration_service = OrchestrationService()

@router.post("/", response_model=OrchestrationResponse, description="Orchestrate multiple AI agents")
async def orchestrate_agents(
    request: OrchestrationRequest,
    principal: str = Depends(check_rbac(resource="orchestration", action="create")),
    _ = Depends(audit_log(resource="orchestration", action="create")),
    orchestration_service: OrchestrationService = Depends(get_orchestration_service),
    cache: CacheService = Depends(get_cache_service)
):
    """Run an orchestration workflow for multiple agents."""
    cache_key = f"orch:{request.orchestration_id}"
    try:
        cached_result = await cache.get(cache_key, principal)
        if cached_result:
            logger.debug(f"Cache hit for orchestration {cache_key}")
            return OrchestrationResponse(**cached_result)

        response = await orchestration_service.orchestrate_agents(request)
        await cache.set(cache_key, principal, response.dict(), ttl=3600)
        logger.info(f"Orchestrated workflow {request.orchestration_id} by {principal}: {response.total_tokens} tokens")
        return response
    except Exception as e:
        logger.error(f"Orchestration failed: {e}")
        raise HTTPException(status_code=500, detail=f"Orchestration failed: {str(e)}")
