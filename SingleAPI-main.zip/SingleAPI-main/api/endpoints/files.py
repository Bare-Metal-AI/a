from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from api.models.files import FileUploadResponse
from api.dependencies import check_rbac, audit_log, get_file_service
from api.services.files import FileService
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/files", tags=["files"])

@router.post("/upload", response_model=FileUploadResponse, description="Upload a file for processing")
async def upload_file(
    instance_id: str,
    collection_name: str,
    file: UploadFile = File(...),
    file_type: str = "pdf",
    normalize: bool = False,
    anonymize: bool = False,
    principal: str = Depends(check_rbac(resource="files", action="upload")),
    _ = Depends(audit_log(resource="files", action="upload")),
    file_service: FileService = Depends(get_file_service)
):
    """Upload a file and process it with FireDucks."""
    try:
        file_path = f"/tmp/{file.filename}"
        with open(file_path, "wb") as f:
            f.write(await file.read())
        response = await file_service.upload_file(instance_id, collection_name, file_path, file_type, normalize, anonymize)
        logger.info(f"File {response.file_id} uploaded by {principal}")
        return response
    except Exception as e:
        logger.error(f"File upload endpoint failed: {e}")
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")
