from cerbos.client import CerbosClient
from fastapi import Depends, HTTPException, Request, Header
from config.settings import settings
from adapters.base import VectorDBAdapter
from orchestration.workflows import get_temporal_client
from api.services.cache import CacheService
from api.services.agents import AgentService
from api.services.auth import AuthService
from api.services.compliance import ComplianceService
from api.services.security import SecurityService
import jwt
import logging
import boto3
import json

logger = logging.getLogger(__name__)

class ServiceContainer:
    """Container for shared services."""
    cerbos = CerbosClient(host=settings.cerbos_host)
    cache = CacheService()
    auth = AuthService()
    s3 = boto3.client("s3")
    security = SecurityService()
    compliance = ComplianceService(cache, security)

services = ServiceContainer()

async def check_rbac(
    principal: str = Header(..., alias="X-Principal"),
    resource: str = "",
    action: str = "",
    authorization: str = Header(..., alias="Authorization"),
    request: Request = None
):
    """Check RBAC permissions using Cerbos with compliance checks."""
    try:
        token = authorization.replace("Bearer ", "")
        decoded = jwt.decode(token, options={"verify_signature": False})  # Production: Verify with Cognito JWKS
        role = decoded.get("custom:role", "sme")
        if settings.hipaa_enabled and role not in ["enterprise", "regulated"]:
            raise HTTPException(status_code=403, detail="HIPAA requires enterprise or regulated role")
    except Exception as e:
        logger.error(f"Token decoding failed: {e}")
        raise HTTPException(status_code=401, detail="Invalid token")
    
    is_allowed = services.cerbos.is_allowed(
        principal={"id": principal, "roles": [role]},
        resource={"kind": resource, "id": "default"},
        action=action
    )
    if not is_allowed:
        logger.warning(f"Permission denied for {principal} on {resource}:{action}")
        raise HTTPException(status_code=403, detail=f"Permission denied for {role} on {resource}:{action}")
    logger.debug(f"Permission granted for {principal} on {resource}:{action}")
    return principal

async def audit_log(request: Request, principal: str, resource: str, action: str):
    """Log audit events to file and S3 for immutability."""
    try:
        log_entry = {
            "method": request.method,
            "url": str(request.url),
            "principal": principal,
            "resource": resource,
            "action": action,
            "timestamp": time.ctime(),
            "client_ip": request.client.host,
            "user_agent": request.headers.get("User-Agent", "unknown"),
            "compliance_standard": "SOC2/ISO27001" + ("_HIPAA" if settings.hipaa_enabled else "")
        }
        log_str = json.dumps(log_entry)
        with open("audit.log", "a") as f:
            f.write(log_str + "\n")
        s3_key = f"audit_logs/{time.strftime('%Y-%m-%d')}/{int(time.time())}.json"
        services.s3.put_object(
            Bucket="vectordbcloud-audit-logs",
            Key=s3_key,
            Body=log_str,
            ServerSideEncryption="AES256"
        )
        logger.debug(f"Audit log written for {principal} on {resource}:{action} to S3: {s3_key}")
    except Exception as e:
        logger.error(f"Failed to write audit log: {e}")

def get_db_adapter(db_type: str = "pgvector") -> VectorDBAdapter:
    """Provide a database adapter instance."""
    from adapters.pgvector import PgVectorAdapter
    from adapters.chromadb import ChromaDBAdapter
    adapters = {
        "pgvector": PgVectorAdapter(),
        "chromadb": ChromaDBAdapter(),
    }
    adapter = adapters.get(db_type)
    if not adapter:
        logger.error(f"No adapter found for db_type: {db_type}")
        raise ValueError(f"Unsupported database type: {db_type}")
    return adapter

async def get_cache_service() -> CacheService:
    """Provide a cache service instance."""
    if not services.cache.redis:
        await services.cache.connect()
    return services.cache

async def get_temporal_client():
    """Provide a Temporal client instance."""
    try:
        client = await get_temporal_client()
        logger.debug("Temporal client retrieved")
        return client
    except Exception as e:
        logger.error(f"Failed to connect to Temporal: {e}")
        raise RuntimeError(f"Temporal connection failed: {e}")

async def get_auth_service() -> AuthService:
    """Provide an authentication service instance."""
    return services.auth

async def get_agents_service() -> AgentService:
    """Provide an agents service instance."""
    return AgentService()

async def get_compliance_service() -> ComplianceService:
    """Provide a compliance service instance."""
    return services.compliance
