import boto3
import logging
from config.settings import settings
from typing import Dict, Any
import asyncio

logger = logging.getLogger(__name__)

class CloudWatchMonitor:
    """Monitor metrics using AWS CloudWatch."""

    def __init__(self):
        self.client = boto3.client(
            "cloudwatch",
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key
        )
        logger.info("CloudWatch monitor initialized")

    async def log_metric(self, namespace: str, metric_name: str, value: float):
        """Log a metric to CloudWatch."""
        try:
            await asyncio.to_thread(
                self.client.put_metric_data,
                Namespace=f"VectorDBCloud/{namespace}",
                MetricData=[
                    {
                        "MetricName": metric_name,
                        "Value": value,
                        "Unit": "Count" if metric_name == "Requests" else "Seconds"
                    }
                ]
            )
            logger.debug(f"Logged metric {metric_name}={value} to CloudWatch")
        except Exception as e:
            logger.error(f"Failed to log to CloudWatch: {e}")
