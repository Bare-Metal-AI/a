import logging
from langsmith import Client
from config.settings import settings
from typing import Dict, Any
import asyncio

logger = logging.getLogger(__name__)

class LangSmithMonitor:
    """Monitor requests and responses using LangSmith."""

    def __init__(self):
        self.client = Client(api_key=settings.langsmith_api_key)
        logger.info("LangSmith monitor initialized")

    async def log_request(self, request_params: Dict[str, Any], response: Dict[str, Any], endpoint: str):
        """Log request and response data to LangSmith."""
        try:
            run_id = self.client.create_run(
                name=f"request_{endpoint}",
                run_type="api",
                inputs=request_params
            )
            self.client.update_run(run_id, outputs=response, end_time=asyncio.get_event_loop().time())
            logger.debug(f"Logged request to LangSmith for {endpoint}")
        except Exception as e:
            logger.error(f"Failed to log to LangSmith: {e}")
