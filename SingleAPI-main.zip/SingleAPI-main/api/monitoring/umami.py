import httpx
import logging
from config.settings import settings
from typing import Dict, Any
import asyncio

logger = logging.getLogger(__name__)

class UmamiMonitor:
    """Monitor events using Umami analytics."""

    def __init__(self):
        self.client = httpx.AsyncClient(base_url=settings.umami_url)
        logger.info("Umami monitor initialized")

    async def log_event(self, event_type: str, ip_address: str):
        """Log an event to Umami."""
        try:
            await self.client.post(
                "/api/send",
                json={
                    "website": settings.umami_website_id,
                    "type": "event",
                    "event": event_type,
                    "ip": ip_address
                }
            )
            logger.debug(f"Logged event {event_type} to Umami")
        except Exception as e:
            logger.error(f"Failed to log to Umami: {e}")
