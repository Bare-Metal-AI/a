import stripe
import httpx
import logging
from config.settings import settings
from typing import Dict, Any
import asyncio

logger = logging.getLogger(__name__)

class StripeMeter:
    """Monitor usage and bill via Stripe with enhanced alerts."""

    def __init__(self):
        stripe.api_key = settings.stripe_api_key
        self.meter_id = settings.stripe_meter_id
        self.total_cost = 0.0
        self.request_count = 0
        self.latency_sum = 0.0
        logger.info("Stripe meter initialized")

    async def record_usage(self, customer_id: str, endpoint: str, latency: float):
        """Record usage event with latency/QPS alerts."""
        try:
            event = await asyncio.to_thread(
                stripe.Event.create,
                type="meter.event",
                data={
                    "meter_id": self.meter_id,
                    "customer_id": customer_id,
                    "event_name": f"{endpoint}_request",
                    "value": 1
                }
            )
            cost_increment = 0.0001
            self.total_cost += cost_increment
            self.request_count += 1
            self.latency_sum += latency
            avg_latency = self.latency_sum / self.request_count

            if self.total_cost > 100.0:
                await self._send_cost_alert(customer_id, self.total_cost)
                self.total_cost = 0.0
            if avg_latency > 0.050:  # 50ms threshold
                await self._send_latency_alert(customer_id, avg_latency)
            if self.request_count % 1000 == 0:  # QPS proxy
                await self._send_qps_alert(customer_id, self.request_count / 60)  # Last minute
            logger.debug(f"Recorded usage for {customer_id} on {endpoint}, latency={latency:.3f}")
        except Exception as e:
            logger.error(f"Failed to record usage in Stripe: {e}")

    async def _send_cost_alert(self, customer_id: str, total_cost: float):
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://api.email-service.com/send",
                    json={
                        "to": settings.breach_alert_email,
                        "subject": f"Cost Alert for {customer_id}",
                        "body": f"Total cost exceeded $100: ${total_cost:.2f}"
                    }
                )
            logger.info(f"Sent cost alert for {customer_id}: ${total_cost:.2f}")
        except Exception as e:
            logger.error(f"Failed to send cost alert: {e}")

    async def _send_latency_alert(self, customer_id: str, avg_latency: float):
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://api.email-service.com/send",
                    json={
                        "to": settings.breach_alert_email,
                        "subject": f"Latency Alert for {customer_id}",
                        "body": f"Average latency exceeded 50ms: {avg_latency:.3f}s"
                    }
                )
            logger.info(f"Sent latency alert for {customer_id}: {avg_latency:.3f}s")
        except Exception as e:
            logger.error(f"Failed to send latency alert: {e}")

    async def _send_qps_alert(self, customer_id: str, qps: float):
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://api.email-service.com/send",
                    json={
                        "to": settings.breach_alert_email,
                        "subject": f"QPS Alert for {customer_id}",
                        "body": f"Queries per second: {qps:.1f}"
                    }
                )
            logger.info(f"Sent QPS alert for {customer_id}: {qps:.1f}")
        except Exception as e:
            logger.error(f"Failed to send QPS alert: {e}")

    async def forecast_cost(self, customer_id: str, days: int) -> Dict[str, float]:
        try:
            if self.request_count == 0:
                return {"forecasted_cost": 0.0, "days": days}
            avg_cost_per_day = self.total_cost / (time.time() / 86400)
            forecast = avg_cost_per_day * days
            logger.info(f"Cost forecast for {customer_id}: ${forecast:.2f} over {days} days")
            return {"forecasted_cost": forecast, "days": days}
        except Exception as e:
            logger.error(f"Cost forecasting failed: {e}")
            raise RuntimeError(f"Cost forecasting failed: {e}")
