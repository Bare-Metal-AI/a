from fastapi import FastAPI, Request, WebSocket, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.openapi.utils import get_openapi
from api.endpoints import instances, collections, search, ai, backup, graph, migration, team, files, external, monitoring, ui, agents, orchestration, rag, feedback, compliance  # Updated
from api.middleware.rate_limit import setup_rate_limit
from api.middleware.throttling import ThrottleMiddleware
from api.monitoring.langsmith import LangSmithMonitor
from api.monitoring.cloudwatch import CloudWatchMonitor
from api.monitoring.umami import UmamiMonitor
from api.monitoring.stripe import StripeMeter
from api.dependencies import get_auth_token, get_cache_service, get_agents_service, get_compliance_service
from api.services.compliance import ComplianceService
from api.services.security import SecurityService
from utils.error_handler import custom_exception_handler
from config.settings import settings
from utils.logging import setup_logging
import logging
import time
import json

logger = logging.getLogger(__name__)
setup_logging(settings.log_level)

app = FastAPI(
    title="VectorDBCloud API",
    description="A high-speed, low-latency, edge-supported AI ecosystem for vector database management and agent orchestration.",
    version="1.0.0",
    openapi_tags=[
        {"name": "instances", "description": "Manage vector DB instances"},
        {"name": "collections", "description": "CRUD operations on collections"},
        {"name": "search", "description": "Search operations with NLP"},
        {"name": "ai", "description": "Generative AI and embedding generation"},
        {"name": "backup", "description": "Backup and restore"},
        {"name": "graph", "description": "Graph operations with Neo4j"},
        {"name": "migration", "description": "Data migration"},
        {"name": "team", "description": "Team and workspace management"},
        {"name": "files", "description": "File uploads with preprocessing"},
        {"name": "external", "description": "External data source imports"},
        {"name": "monitoring", "description": "Usage and cost monitoring"},
        {"name": "ui", "description": "Web UI dashboard"},
        {"name": "agents", "description": "AI agent creation and querying"},
        {"name": "orchestration", "description": "Multi-agent orchestration"},
        {"name": "rag", "description": "RAG pipeline generation"},
        {"name": "feedback", "description": "User feedback submission"},
        {"name": "compliance", "description": "Compliance and privacy operations"}  # Updated
    ],
    security=[{"CognitoJWT": []}]
)

# Middleware setup
app.add_middleware(ThrottleMiddleware)
setup_rate_limit(app)
app.add_exception_handler(Exception, custom_exception_handler)

# Monitoring services
langsmith_monitor = LangSmithMonitor()
cloudwatch_monitor = CloudWatchMonitor()
umami_monitor = UmamiMonitor()
stripe_meter = StripeMeter()

# Compliance service
cache_service = CacheService()
security_service = SecurityService()
compliance_service = ComplianceService(cache_service, security_service)

# Templates
templates = Jinja2Templates(directory="api/templates")

# Include routers with version prefix (Mitigation 5)
app.include_router(instances.router, prefix="/v1")
app.include_router(collections.router, prefix="/v1")
app.include_router(search.router, prefix="/v1")
app.include_router(ai.router, prefix="/v1")
app.include_router(backup.router, prefix="/v1")
app.include_router(graph.router, prefix="/v1")
app.include_router(migration.router, prefix="/v1")
app.include_router(team.router, prefix="/v1")
app.include_router(files.router, prefix="/v1")
app.include_router(external.router, prefix="/v1")
app.include_router(monitoring.router, prefix="/v1")
app.include_router(ui.router, prefix="/v1")
app.include_router(agents.router, prefix="/v1")
app.include_router(orchestration.router, prefix="/v1")
app.include_router(rag.router, prefix="/v1")
app.include_router(feedback.router, prefix="/v1")
app.include_router(compliance.router, prefix="/v1")  # Updated

@app.on_event("startup")
async def startup_event():
    """Initialize resources on startup."""
    logger.info("VectorDBCloud API starting up...")
    await cache_service.connect()

@app.on_event("shutdown")
async def shutdown_event():
    """Clean up resources on shutdown."""
    logger.info("VectorDBCloud API shutting down...")

@app.middleware("http")
async def monitor_request(request: Request, call_next):
    """Monitor all HTTP requests for performance and usage with compliance."""
    start_time = time.time()
    endpoint = request.url.path.split("/")[2] if len(request.url.path.split("/")) > 2 else "root"  # Updated for /v1
    customer_id = request.headers.get("X-Customer-ID", "anonymous")
    
    response = await call_next(request)
    latency = time.time() - start_time
    
    try:
        response_body = response.body.decode() if isinstance(response.body, bytes) else str(response.body)
        await langsmith_monitor.log_request(dict(request.query_params), json.loads(response_body), endpoint)
        await cloudwatch_monitor.log_metric(endpoint, "Latency", latency)
        await cloudwatch_monitor.log_metric(endpoint, "Requests", 1)
        await umami_monitor.log_event(endpoint, request.client.host)
        await stripe_meter.record_usage(customer_id, endpoint)
        response.headers["X-Latency"] = str(latency)
        response.headers["X-Service"] = "vectordbcloud-core"
        if latency > 5:
            await compliance_service.report_incident({
                "type": "high_latency",
                "endpoint": endpoint,
                "latency": latency,
                "severity": "medium"
            })
    except Exception as e:
        logger.error(f"Monitoring failed: {e}")
        await compliance_service.report_incident({
            "type": "monitoring_failure",
            "error": str(e),
            "severity": "high"
        })
    
    return response

@app.get("/v1/", description="API root endpoint")  # Mitigation 5: Versioned
async def root():
    """Health check for the API."""
    return {"message": "Welcome to VectorDBCloud API", "version": "1.0.0", "status": "running"}

@app.websocket("/v1/ws/agents/{agent_id}")  # Mitigation 5: Versioned
async def websocket_agent(websocket: WebSocket, agent_id: str, token: str = Depends(get_auth_token), cache: CacheService = Depends(get_cache_service), agents_service: AgentService = Depends(get_agents_service)):
    """Real-time agent querying via WebSocket."""
    await websocket.accept()
    logger.info(f"WebSocket connection opened for agent {agent_id}")
    try:
        while True:
            data = await websocket.receive_text()
            try:
                cached_result = await cache.get(f"ws:{agent_id}:{data}", token)
                if cached_result:
                    await websocket.send_text(json.dumps(cached_result))
                    continue
                
                output, tokens, cost = await agents_service.query_agent(agent_id, data, 100, 0.7)
                response = {"response": output, "tokens": tokens, "cost_usd": cost}
                await cache.set(f"ws:{agent_id}:{data}", token, response, ttl=300)
                await websocket.send_text(json.dumps(response))
                logger.debug(f"Sent response to WebSocket for {agent_id}: {output[:50]}...")
            except Exception as e:
                await websocket.send_text(f"Error: {str(e)}")
                logger.error(f"WebSocket query failed for {agent_id}: {e}")
    except Exception as e:
        logger.error(f"WebSocket connection error: {e}")
        await compliance_service.report_incident({
            "type": "websocket_failure",
            "agent_id": agent_id,
            "error": str(e),
            "severity": "medium"
        })
    finally:
        await websocket.close()
        logger.info(f"WebSocket connection closed for {agent_id}")

def custom_openapi():
    """Customize OpenAPI schema."""
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="VectorDBCloud API",
        version="1.0.0",
        description="An end-to-end AI ecosystem with low-latency, edge support via Cloudflare and AWS, and high-speed agent orchestration",
        routes=app.routes,
    )
    openapi_schema["components"]["securitySchemes"] = {
        "CognitoJWT": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Cognito JWT token required for authentication"
        }
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
