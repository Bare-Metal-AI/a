from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class FeedbackRequest(BaseModel):
    user_id: str
    message: str

class FeedbackResponse(BaseModel):
    status: str
