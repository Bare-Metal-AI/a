from pydantic import BaseModel
from typing import Dict
import logging

logger = logging.getLogger(__name__)

class GraphNodeRequest(BaseModel):
    node_id: str
    properties: Dict[str, str]

class GraphNodeResponse(BaseModel):
    status: str
    node_id: str
