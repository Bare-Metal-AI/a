from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class FileUploadResponse(BaseModel):
    status: str
    file_id: str
