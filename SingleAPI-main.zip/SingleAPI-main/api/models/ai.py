from pydantic import BaseModel
from typing import List, Union
import logging

logger = logging.getLogger(__name__)

class GenerateRequest(BaseModel):
    prompt: str
    model: str
    max_tokens: int = 100
    temperature: float = 0.7

class EmbedRequest(BaseModel):
    input: Union[str, List[str]]
    model: str

class AIRequest(BaseModel):
    task: str
    generate: GenerateRequest = None
    embed: EmbedRequest = None

    class Config:
        extra = "forbid"

class AIResponse(BaseModel):
    task: str
    result: Union[str, List[float], List[List[float]]]
    tokens: int
    estimated_cost_usd: float
