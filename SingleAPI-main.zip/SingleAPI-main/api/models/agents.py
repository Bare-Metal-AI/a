from pydantic import BaseModel
from typing import List
import logging

logger = logging.getLogger(__name__)

class AgentCreateRequest(BaseModel):
    name: str
    instance_id: str
    collection_name: str
    model: str
    agent_type: str = "langchain"
    tools: List[str] = None

class AgentQueryRequest(BaseModel):
    agent_id: str
    query: str
    max_tokens: int = 100
    temperature: float = 0.7

class AgentResponse(BaseModel):
    agent_id: str
    response: str
    tokens: int
    estimated_cost_usd: float
