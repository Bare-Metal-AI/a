from pydantic import BaseModel
from typing import List, Dict
import logging

logger = logging.getLogger(__name__)

class AgentTask(BaseModel):
    agent_id: str
    task: str
    dependencies: List[str] = []

class OrchestrationRequest(BaseModel):
    orchestration_id: str
    tasks: List[AgentTask]

class OrchestrationResponse(BaseModel):
    orchestration_id: str
    results: Dict[str, str]
    total_tokens: int
    total_cost_usd: float
