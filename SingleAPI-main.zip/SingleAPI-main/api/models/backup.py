from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class BackupRequest(BaseModel):
    collection_name: str = None

class BackupResponse(BaseModel):
    backup_id: str
