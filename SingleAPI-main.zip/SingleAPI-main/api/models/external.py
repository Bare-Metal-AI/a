from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class ExternalImportRequest(BaseModel):
    instance_id: str
    collection_name: str
    source_type: str
    source_url: str
    api_key: str = None

class ExternalImportResponse(BaseModel):
    status: str
    records: int
