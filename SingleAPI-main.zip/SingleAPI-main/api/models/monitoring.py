from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class UsageResponse(BaseModel):
    requests: int
    tokens_used: int
    cost_usd: float
