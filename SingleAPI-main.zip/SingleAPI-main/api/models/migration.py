from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class MigrationRequest(BaseModel):
    source_instance_id: str
    source_collection: str
    target_instance_id: str
    target_collection: str

class MigrationResponse(BaseModel):
    message: str
