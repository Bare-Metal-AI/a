from pydantic import BaseModel
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class CollectionCreateRequest(BaseModel):
    name: str

class CollectionData(BaseModel):
    id: str
    vector: List[float]
    metadata: Dict[str, Any]

class UpsertRequest(BaseModel):
    data: List[CollectionData]

class CollectionResponse(BaseModel):
    status: str
    collection_name: str
