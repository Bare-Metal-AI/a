from pydantic import BaseModel
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class SearchRequest(BaseModel):
    query: str
    top_k: int = 10
    use_nlp: bool = False

class SearchResponse(BaseModel):
    results: List[Dict[str, Any]]
