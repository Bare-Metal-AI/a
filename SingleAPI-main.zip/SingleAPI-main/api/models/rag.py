from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class RAGPipelineRequest(BaseModel):
    instance_id: str
    collection_name: str
    model: str
    framework: str = "langchain"
    max_tokens: int = 100
    temperature: float = 0.7

class RAGPipelineResponse(BaseModel):
    pipeline_id: str
    status: str

class RAGQueryRequest(BaseModel):
    query: str
    max_tokens: int = 100
    temperature: float = 0.7

class RAGQueryResponse(BaseModel):
    pipeline_id: str
    response: str
    tokens: int
    estimated_cost_usd: float
