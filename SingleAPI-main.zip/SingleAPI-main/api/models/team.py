from pydantic import BaseModel
from typing import List
import logging

logger = logging.getLogger(__name__)

class TeamCreateRequest(BaseModel):
    team_name: str
    members: List[str]

class TeamResponse(BaseModel):
    team_id: str
