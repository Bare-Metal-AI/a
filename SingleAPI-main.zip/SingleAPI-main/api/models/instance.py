from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

class InstanceCreateRequest(BaseModel):
    db_type: str
    cloud_provider: str
    cluster_size: int = 1
    region: str = "us-east-1"

    def __post_init__(self):
        logger.debug(f"InstanceCreateRequest initialized: {self.dict()}")

class InstanceResponse(BaseModel):
    instance_id: str
    status: str
