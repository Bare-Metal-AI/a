import aioredis
from config.settings import settings
import logging
from typing import Dict, Any
import json
import asyncio

logger = logging.getLogger(__name__)

class CacheService:
    """Service for caching data in Redis with failover."""

    def __init__(self):
        self.redis = None
        self.backup_redis = None  # Mitigation 5: Add backup Redis

    async def connect(self):
        """Connect to primary and backup Redis."""
        try:
            self.redis = await aioredis.create_redis_pool(
                f"redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}",
                password=settings.REDIS_PASSWORD
            )
            # Mitigation 5: Connect to backup Redis (assumes secondary host in env)
            backup_host = settings.get("REDIS_BACKUP_HOST", "localhost")
            self.backup_redis = await aioredis.create_redis_pool(
                f"redis://{backup_host}:{settings.REDIS_PORT}",
                password=settings.REDIS_PASSWORD
            )
            logger.info("Connected to primary and backup Redis cache")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise RuntimeError(f"Redis connection failed: {e}")

    async def get(self, key: str, tenant_id: str) -> Dict[str, Any]:
        """Retrieve data from cache with failover."""
        tenant_key = f"{tenant_id}:{key}"
        try:
            cached = await self.redis.get(tenant_key)
            if cached:
                return json.loads(cached.decode())
            # Mitigation 5: Try backup if primary fails
            cached = await self.backup_redis.get(tenant_key)
            if cached:
                logger.warning(f"Primary Redis failed, retrieved from backup: {tenant_key}")
                return json.loads(cached.decode())
            logger.debug(f"Cache miss for {tenant_key}")
            return None
        except Exception as e:
            logger.error(f"Cache get failed for {tenant_key}: {e}")
            return None

    async def set(self, key: str, tenant_id: str, value: Dict[str, Any], ttl: int = 3600):
        """Store data in cache with failover."""
        tenant_key = f"{tenant_id}:{key}"
        try:
            await self.redis.set(tenant_key, json.dumps(value), expire=ttl)
            await self.backup_redis.set(tenant_key, json.dumps(value), expire=ttl)  # Mirror to backup
            logger.debug(f"Cache set for {tenant_key} with TTL {ttl}")
        except Exception as e:
            logger.error(f"Cache set failed for {tenant_key}: {e}")

    async def delete(self, key: str, tenant_id: str):
        """Delete data from cache with failover."""
        tenant_key = f"{tenant_id}:{key}"
        try:
            await self.redis.delete(tenant_key)
            await self.backup_redis.delete(tenant_key)  # Sync deletion
            logger.debug(f"Cache deleted for {tenant_key}")
        except Exception as e:
            logger.error(f"Cache delete failed for {tenant_key}: {e}")
