import logging
from api.dependencies import get_cache_service
from agent_adapters.registry import registry as agent_registry
from typing import Tuple, List

logger = logging.getLogger(__name__)

class AgentService:
    """Service for managing AI agents."""

    def __init__(self, cache_service=None):
        self.cache_service = cache_service or get_cache_service()
        logger.info("Initialized AgentService")

    async def create_agent(self, name: str, instance_id: str, collection_name: str, model: str, agent_type: str, tools: List[str]) -> str:
        """Create an AI agent."""
        try:
            adapter = agent_registry.get(agent_type)
            agent_id = await adapter.create_agent(name, instance_id, collection_name, model, tools)
            logger.info(f"AgentService created agent {agent_id}")
            return agent_id
        except Exception as e:
            logger.error(f"Agent creation failed: {e}")
            raise RuntimeError(f"Agent creation failed: {e}")

    async def query_agent(self, agent_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query an AI agent."""
        try:
            adapter_type = agent_id.split("-")[0]
            adapter = agent_registry.get(adapter_type)
            output, tokens, cost = await adapter.query_agent(agent_id, query, max_tokens, temperature)
            logger.info(f"AgentService queried agent {agent_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"Agent query failed: {e}")
            raise RuntimeError(f"Agent query failed: {e}")
