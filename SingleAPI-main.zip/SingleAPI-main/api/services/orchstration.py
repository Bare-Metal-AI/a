from orchestration.workflows import AgentOrchestrationWorkflow, get_temporal_client
from api.models.orchestration import OrchestrationRequest
import logging

logger = logging.getLogger(__name__)

class OrchestrationService:
    """Service for orchestrating multiple AI agents."""

    async def orchestrate_agents(self, request: OrchestrationRequest) -> dict:
        """Run an orchestration workflow using Temporal."""
        try:
            client = await get_temporal_client()
            result = await client.start_workflow(
                AgentOrchestrationWorkflow.run,
                request.dict(),
                id=f"orchestrate-{request.orchestration_id}",
                task_queue="orchestration-queue"
            )
            logger.info(f"Orchestration {request.orchestration_id} completed: {result}")
            return result
        except Exception as e:
            logger.error(f"Orchestration failed: {e}")
            raise RuntimeError(f"Orchestration failed: {e}")
