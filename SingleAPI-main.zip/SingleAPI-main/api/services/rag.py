from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
from api.services.embedding import EmbeddingService
from adapters.base import VectorDBAdapter
import logging
from typing import Tuple

logger = logging.getLogger(__name__)

class RAGService:
    """Service for managing RAG pipelines."""

    def __init__(self):
        self.pipelines = {}
        self.embedding_service = EmbeddingService()

    async def create_rag_pipeline(self, request: RAGPipelineRequest) -> str:
        """Create a new RAG pipeline."""
        try:
            pipeline_id = f"rag-{request.instance_id}-{request.collection_name}"
            adapter = get_db_adapter("pgvector")  # Simplified
            llm = ChatOpenAI(model_name=request.model, api_key=settings.api_key_openai)
            # Mock retriever setup (simplified)
            embeddings, _ = await self.embedding_service.generate_embedding("dummy", "openai-ada-002")
            chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=adapter.as_retriever())
            self.pipelines[pipeline_id] = chain
            logger.info(f"Created RAG pipeline {pipeline_id}")
            return pipeline_id
        except Exception as e:
            logger.error(f"RAG pipeline creation failed: {e}")
            raise RuntimeError(f"RAG pipeline creation failed: {e}")

    async def query_rag_pipeline(self, pipeline_id: str, query: str, max_tokens: int, temperature: float) -> Tuple[str, int, float]:
        """Query an existing RAG pipeline."""
        try:
            chain = self.pipelines.get(pipeline_id)
            if not chain:
                raise ValueError(f"RAG pipeline {pipeline_id} not found")
            response = await chain.acall({"query": query})
            output = response["result"]
            tokens = len(query.split()) + len(output.split())  # Approximate
            cost = await self.embedding_service.estimate_cost("gpt4o", tokens)
            logger.info(f"Queried RAG pipeline {pipeline_id}: {tokens} tokens")
            return output, tokens, cost
        except Exception as e:
            logger.error(f"RAG query failed: {e}")
            raise RuntimeError(f"RAG query failed: {e}")
