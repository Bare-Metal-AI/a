import spacy
import logging
from typing import List

logger = logging.getLogger(__name__)

class NLPService:
    """Service for natural language processing."""

    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
        logger.info("NLP service initialized with spaCy")

    async def process_text(self, text: str) -> List[str]:
        """Extract entities from text using spaCy."""
        try:
            doc = self.nlp(text)
            entities = [ent.text for ent in doc.ents]
            logger.debug(f"Processed text with NLP: {len(entities)} entities found")
            return entities
        except Exception as e:
            logger.error(f"NLP processing failed: {e}")
            raise RuntimeError(f"NLP processing failed: {e}")
