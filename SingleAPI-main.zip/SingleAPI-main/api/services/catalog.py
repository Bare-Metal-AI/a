import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class CatalogService:
    """Service for managing instance and collection metadata."""

    def __init__(self):
        self.instances: Dict[str, Dict[str, Any]] = {}

    async def register_instance(self, instance_id: str, metadata: Dict[str, Any]) -> None:
        """Register a new instance in the catalog."""
        try:
            self.instances[instance_id] = metadata
            logger.info(f"Registered instance {instance_id} in catalog")
        except Exception as e:
            logger.error(f"Failed to register instance {instance_id}: {e}")
            raise RuntimeError(f"Catalog registration failed: {e}")

    async def list_instances(self) -> List[Dict[str, Any]]:
        """List all registered instances."""
        try:
            return list(self.instances.values())
        except Exception as e:
            logger.error(f"Failed to list instances: {e}")
            raise RuntimeError(f"Catalog listing failed: {e}")
