from adapters.base import VectorDBAdapter
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)

class MigrationService:
    """Service for migrating data between collections or instances."""

    def __init__(self):
        self.source_adapter = None
        self.target_adapter = None

    async def copy_data(self, source_instance_id: str, source_collection: str, target_instance_id: str, target_collection: str) -> str:
        """Copy data from source to target."""
        try:
            self.source_adapter = get_db_adapter("pgvector")  # Simplified
            self.target_adapter = get_db_adapter("pgvector")
            # Fetch data from source
            data = await self.source_adapter.search(source_instance_id, source_collection, [0.1] * 1536, limit=1000)
            # Insert into target
            for item in data:
                await self.target_adapter.insert(target_instance_id, target_collection, {
                    "id": item["id"],
                    "vector": item["vector"],
                    "metadata": item["metadata"]
                })
            logger.info(f"Copied {len(data)} records from {source_collection} to {target_collection}")
            return f"Migrated {len(data)} records"
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            raise RuntimeError(f"Migration failed: {e}")
