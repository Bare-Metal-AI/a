from external_adapters.registry import registry as external_registry
from adapters.base import VectorDBAdapter
from api.models.collection import CollectionData, UpsertRequest
import logging
from typing import List

logger = logging.getLogger(__name__)

class ExternalService:
    """Service for importing data from external sources."""

    def __init__(self):
        self.external_adapters = external_registry

    async def import_data(self, instance_id: str, collection_name: str, source_type: str, source_url: str, api_key: str = None) -> int:
        """Import data from an external source."""
        adapter = get_db_adapter("pgvector")  # Simplified
        try:
            external_adapter = self.external_adapters.get(source_type)
            data = await external_adapter.fetch_data(source_url, api_key)
            if not data:
                raise ValueError(f"No data fetched from {source_type}")

            await adapter.upsert(instance_id, collection_name, UpsertRequest(data=data))
            logger.info(f"Imported {len(data)} records from {source_type} into {collection_name}")
            return len(data)
        except Exception as e:
            logger.error(f"External data import failed: {e}")
            raise RuntimeError(f"External import failed: {e}")
