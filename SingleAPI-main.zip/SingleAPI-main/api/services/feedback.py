import logging
import uuid

logger = logging.getLogger(__name__)

class FeedbackService:
    """Service for handling user feedback."""

    def __init__(self):
        self.feedback_store = {}  # In-memory store; replace with DB in production

    async def submit_feedback(self, user_id: str, message: str) -> None:
        """Store user feedback."""
        try:
            feedback_id = f"feedback-{uuid.uuid4()}"
            self.feedback_store[feedback_id] = {"user_id": user_id, "message": message, "timestamp": time.ctime()}
            logger.info(f"Stored feedback {feedback_id} from {user_id}")
        except Exception as e:
            logger.error(f"Feedback submission failed: {e}")
            raise RuntimeError(f"Feedback submission failed: {e}")
