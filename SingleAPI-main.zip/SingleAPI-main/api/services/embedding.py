from ai_adapters.registry import registry as ai_registry
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

class EmbeddingService:
    """Service for generating embeddings."""

    def __init__(self):
        self.ai_adapters = ai_registry

    async def generate_embedding(self, content: str | List[str], model: str) -> Tuple[List[float] | List[List[float]], int]:
        """Generate embeddings for content using the specified model."""
        try:
            adapter = self.ai_adapters.get(model)
            embeddings, tokens = await adapter.embed(content)
            logger.info(f"Generated embeddings with {model}: {tokens} tokens")
            return embeddings, tokens
        except Exception as e:
            logger.error(f"Embedding generation failed with {model}: {e}")
            raise RuntimeError(f"Embedding generation failed: {e}")

    async def estimate_cost(self, model: str, tokens: int) -> float:
        """Estimate cost for embedding generation."""
        try:
            adapter = self.ai_adapters.get(model)
            cost = await adapter.estimate_cost(tokens)
            return cost
        except Exception as e:
            logger.error(f"Cost estimation failed for {model}: {e}")
            raise RuntimeError(f"Cost estimation failed: {e}")
