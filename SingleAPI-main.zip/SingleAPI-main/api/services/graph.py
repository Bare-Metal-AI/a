from neo4j import AsyncGraphDatabase
from config.settings import settings
import logging
from typing import Dict

logger = logging.getLogger(__name__)

class GraphService:
    """Service for managing graph operations with Neo4j."""

    def __init__(self):
        self.driver = AsyncGraphDatabase.driver(
            settings.neo4j_uri,
            auth=(settings.neo4j_user, settings.neo4j_password)
        )

    async def create_node(self, node_id: str, properties: Dict[str, str]) -> str:
        """Create a node in Neo4j."""
        async with self.driver.session() as session:
            try:
                await session.run(
                    "CREATE (n:Node {id: $id, properties: $props})",
                    id=node_id,
                    props=properties
                )
                logger.info(f"Created node {node_id} in Neo4j")
                return node_id
            except Exception as e:
                logger.error(f"Failed to create node {node_id}: {e}")
                raise RuntimeError(f"Node creation failed: {e}")

    async def close(self):
        """Close the Neo4j driver."""
        await self.driver.close()
        logger.info("Neo4j driver closed")
