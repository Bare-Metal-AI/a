import logging
import fireducks.pandas as pd  # Updated
from api.models.files import FileUploadResponse
from api.services.security import SecurityService
from utils.preprocessing import PreprocessingService
from typing import Dict, Any
import PyPDF2
import docx
import openpyxl
from pydub import AudioSegment
import os

logger = logging.getLogger(__name__)

class FileService:
    """Service for handling file uploads with FireDucks."""

    def __init__(self, security: SecurityService, preprocessing: PreprocessingService):
        self.security = security
        self.preprocessing = preprocessing
        logger.info("Initialized FileService")

    async def extract_text(self, file_path: str, file_type: str) -> str:
        """Extract text from uploaded files."""
        try:
            if file_type == "pdf":
                with open(file_path, "rb") as f:
                    pdf = PyPDF2.PdfReader(f)
                    text = "".join(page.extract_text() for page in pdf.pages)
            elif file_type == "docx":
                doc = docx.Document(file_path)
                text = "\n".join(para.text for para in doc.paragraphs)
            elif file_type == "xlsx":
                wb = openpyxl.load_workbook(file_path)
                sheet = wb.active
                data = [[cell.value for cell in row] for row in sheet.rows]
                df = pd.DataFrame(data)  # FireDucks DataFrame
                text = df.to_string()
            elif file_type in ["mp3", "wav"]:
                audio = AudioSegment.from_file(file_path)
                text = f"Audio file: {file_type}, duration: {len(audio) / 1000} seconds"
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            logger.debug(f"Extracted text from {file_path}: {text[:50]}...")
            return text
        except Exception as e:
            logger.error(f"Text extraction failed for {file_path}: {e}")
            raise RuntimeError(f"Text extraction failed: {e}")

    async def upload_file(self, instance_id: str, collection_name: str, file_path: str, file_type: str, normalize: bool, anonymize: bool) -> FileUploadResponse:
        """Upload and process a file."""
        try:
            text = await self.extract_text(file_path, file_type)
            processed_text = self.preprocessing.process_text(text, normalize=normalize, anonymize=anonymize)
            encrypted_text = self.security.encrypt(processed_text) if file_type in ["pdf", "docx"] else processed_text
            file_id = f"file-{instance_id}-{collection_name}-{os.path.basename(file_path)}"
            logger.info(f"Uploaded file {file_id} for {collection_name} in {instance_id}")
            return FileUploadResponse(file_id=file_id, status="uploaded", metadata={"size": os.path.getsize(file_path)})
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            raise RuntimeError(f"File upload failed: {e}")
