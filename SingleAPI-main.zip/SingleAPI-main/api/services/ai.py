import logging
from ai_adapters.registry import registry as ai_registry
from typing import Tuple, List
import ollama

logger = logging.getLogger(__name__)

class AIService:
    """Service for AI operations with local model support."""

    def __init__(self):
        logger.info("Initialized AIService")

    async def generate(self, prompt: str, model: str, max_tokens: int, temperature: float) -> Tuple[str, int]:
        """Generate text with local or remote models."""
        try:
            if model.startswith("local:"):
                local_model = model.split(":")[1]
                response = ollama.generate(model=local_model, prompt=prompt, options={"max_tokens": max_tokens, "temperature": temperature})
                output = response["response"]
                tokens = response.get("total_tokens", len(prompt.split()) + len(output.split()))
            else:
                adapter = ai_registry.get(model)
                output, tokens = await adapter.generate(prompt, max_tokens, temperature)
            logger.info(f"Generated text with {model}: {tokens} tokens")
            return output, tokens
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            raise RuntimeError(f"Generation failed: {e}")
