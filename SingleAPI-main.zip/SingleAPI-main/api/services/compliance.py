import logging
import asyncio
import httpx
from config.settings import settings
from api.services.cache import CacheService
from api.services.security import SecurityService
from typing import Dict, Any
import boto3
import json
import time

logger = logging.getLogger(__name__)

class ComplianceService:
    """Service for compliance-related operations."""

    def __init__(self, cache: CacheService, security: SecurityService):
        self.cache = cache
        self.security = security
        self.s3 = boto3.client("s3")
        logger.info("Compliance service initialized")

    async def enforce_retention(self, instance_id: str, collection_name: str):
        """Delete data older than retention period (GDPR/CCPA)."""
        try:
            cutoff_time = int(time.time()) - (settings.data_retention_days * 86400)
            adapter = get_db_adapter("pgvector")  # Example
            await adapter.delete_older_than(instance_id, collection_name, cutoff_time)
            logger.info(f"Enforced retention for {collection_name} in {instance_id}")
        except Exception as e:
            logger.error(f"Retention enforcement failed: {e}")
            raise RuntimeError(f"Retention enforcement failed: {e}")

    async def record_consent(self, user_id: str, consent: bool):
        """Record user consent for GDPR."""
        try:
            if settings.gdpr_consent_required and not consent:
                raise ValueError("Consent required under GDPR")
            await self.cache.set(f"consent:{user_id}", user_id, {"consent": consent}, ttl=settings.data_retention_days * 86400)
            logger.info(f"Recorded consent for {user_id}: {consent}")
        except Exception as e:
            logger.error(f"Consent recording failed: {e}")
            raise RuntimeError(f"Consent recording failed: {e}")

    async def erase_user_data(self, user_id: str):
        """Erase user data for right to erasure (GDPR/CCPA)."""
        try:
            await self.cache.delete(f"consent:{user_id}", user_id)
            erasure_log = {"user_id": user_id, "timestamp": time.ctime(), "action": "erasure"}
            self.s3.put_object(
                Bucket="vectordbcloud-audit-logs",
                Key=f"erasure_logs/{user_id}_{int(time.time())}.json",
                Body=json.dumps(erasure_log),
                ServerSideEncryption="AES256"
            )
            logger.info(f"Erased data for {user_id}")
        except Exception as e:
            logger.error(f"Data erasure failed: {e}")
            raise RuntimeError(f"Data erasure failed: {e}")

    async def report_incident(self, incident: Dict[str, Any]):
        """Log and notify about security incidents."""
        try:
            incident_log = {
                "timestamp": time.ctime(),
                "details": incident,
                "severity": incident.get("severity", "low")
            }
            s3_key = f"incident_logs/{int(time.time())}.json"
            self.s3.put_object(
                Bucket="vectordbcloud-audit-logs",
                Key=s3_key,
                Body=json.dumps(incident_log),
                ServerSideEncryption="AES256"
            )
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://api.email-service.com/send",
                    json={
                        "to": settings.breach_alert_email,
                        "subject": f"Security Incident: {incident['type']}",
                        "body": f"Incident reported: {json.dumps(incident_log)}"
                    }
                )
            logger.info(f"Reported incident: {s3_key}")
        except Exception as e:
            logger.error(f"Incident reporting failed: {e}")
            raise RuntimeError(f"Incident reporting failed: {e}")

    async def log_risk(self, risk: Dict[str, Any]):
        """Log risks for ISO 27001 risk assessment."""
        try:
            risk_log = {
                "timestamp": time.ctime(),
                "risk": risk,
                "assessed_by": risk.get("assessor", "system")
            }
            s3_key = f"risk_logs/{int(time.time())}.json"
            self.s3.put_object(
                Bucket="vectordbcloud-audit-logs",
                Key=s3_key,
                Body=json.dumps(risk_log),
                ServerSideEncryption="AES256"
            )
            logger.info(f"Logged risk: {s3_key}")
        except Exception as e:
            logger.error(f"Risk logging failed: {e}")
            raise RuntimeError(f"Risk logging failed: {e}")

    async def log_phi_action(self, user_id: str, action: str, data_type: str):
        """Log PHI handling for HIPAA compliance."""
        if not settings.hipaa_enabled:
            return
        try:
            phi_log = {
                "timestamp": time.ctime(),
                "user_id": user_id,
                "action": action,
                "data_type": data_type,
                "encrypted": True
            }
            s3_key = f"phi_logs/{user_id}_{int(time.time())}.json"
            encrypted_log = self.security.encrypt(json.dumps(phi_log))
            self.s3.put_object(
                Bucket="vectordbcloud-audit-logs",
                Key=s3_key,
                Body=encrypted_log,
                ServerSideEncryption="AES256"
            )
            logger.info(f"Logged PHI action for {user_id}: {action}")
        except Exception as e:
            logger.error(f"PHI logging failed: {e}")
            raise RuntimeError(f"PHI logging failed: {e}")

    async def export_user_data(self, user_id: str) -> Dict[str, Any]:
        """Export user data for GDPR/CCPA portability."""
        try:
            consent = await self.cache.get(f"consent:{user_id}", user_id) or {"consent": False}
            # Simplified: Assume data stored in cache or S3
            user_data = {
                "user_id": user_id,
                "consent": consent["consent"],
                "timestamp": time.ctime()
            }
            logger.info(f"Exported data for {user_id}")
            return user_data
        except Exception as e:
            logger.error(f"Data export failed: {e}")
            raise RuntimeError(f"Data export failed: {e}")
