import jwt
from config.settings import settings
import logging
from typing import Dict

logger = logging.getLogger(__name__)

class AuthService:
    """Service for user authentication."""

    def __init__(self):
        self.secret_key = settings.encryption_key  # Simplified for example
        logger.info("Auth service initialized")

    def generate_token(self, user_id: str, role: str = "sme") -> str:
        """Generate a JWT token for a user."""
        try:
            payload = {
                "sub": user_id,
                "role": role,
                "exp": time.time() + 3600  # 1 hour expiry
            }
            token = jwt.encode(payload, self.secret_key, algorithm="HS256")
            logger.info(f"Generated token for user {user_id}")
            return token
        except Exception as e:
            logger.error(f"Token generation failed: {e}")
            raise RuntimeError(f"Token generation failed: {e}")

    def validate_token(self, token: str) -> Dict[str, str]:
        """Validate a JWT token."""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=["HS256"])
            logger.debug(f"Validated token for user {payload['sub']}")
            return {"user_id": payload["sub"], "role": payload["role"]}
        except jwt.ExpiredSignatureError:
            logger.error("Token has expired")
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError:
            logger.error("Invalid token")
            raise ValueError("Invalid token")
        except Exception as e:
            logger.error(f"Token validation failed: {e}")
            raise RuntimeError(f"Token validation failed: {e}")
