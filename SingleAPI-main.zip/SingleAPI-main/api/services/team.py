import logging
from typing import List
import uuid

logger = logging.getLogger(__name__)

class TeamService:
    """Service for managing teams and memberships."""

    def __init__(self):
        self.teams = {}

    async def create_team(self, team_name: str, members: List[str]) -> str:
        """Create a new team with members."""
        try:
            team_id = f"team-{uuid.uuid4()}"
            self.teams[team_id] = {"name": team_name, "members": members}
            logger.info(f"Created team {team_id} with {len(members)} members")
            return team_id
        except Exception as e:
            logger.error(f"Team creation failed: {e}")
            raise RuntimeError(f"Team creation failed: {e}")
