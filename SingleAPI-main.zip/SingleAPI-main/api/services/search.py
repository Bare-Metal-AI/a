import logging
from adapters.registry import registry as db_registry
from typing import List, Dict, Any
import asyncio

logger = logging.getLogger(__name__)

class SearchService:
    """Service for managing search operations with query planning."""

    def __init__(self):
        logger.info("Initialized SearchService")

    async def search(self, instance_id: str, collection_name: str, query: str, limit: int, query_vector: List[float] = None) -> List[Dict[str, Any]]:
        """Search with dynamic query planning."""
        try:
            db_type = instance_id.split("-")[0]
            adapter = db_registry.get(db_type)
            
            # Query planner: vector vs. full-text
            if query_vector:
                results = await adapter.search(instance_id, collection_name, query_vector, limit)
            else:
                # Simplified full-text search (assumes adapter support)
                results = await adapter.search_fulltext(instance_id, collection_name, query, limit)
            logger.info(f"Search completed for {collection_name} in {instance_id}: {len(results)} results")
            return results
        except Exception as e:
            logger.error(f"Search failed: {e}")
            raise RuntimeError(f"Search failed: {e}")
