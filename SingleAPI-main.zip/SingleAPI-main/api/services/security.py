from cryptography.fernet import Fernet
from config.settings import settings
import logging
import base64
import boto3
import time

logger = logging.getLogger(__name__)

class SecurityService:
    """Service for encryption and decryption operations with compliance features."""

    def __init__(self):
        self.kms = boto3.client("kms")
        self.key_id = None
        self.cipher = None
        self.last_rotation = 0
        self._load_or_rotate_key()
        logger.info("Security service initialized with Fernet cipher")

    def _load_or_rotate_key(self):
        """Load or rotate encryption key with KMS."""
        try:
            current_time = int(time.time())
            if current_time - self.last_rotation > settings.encryption_key_rotation_days * 86400:
                # Rotate key
                key = self.kms.generate_data_key(
                    KeyId="alias/vectordbcloud-encryption",
                    KeySpec="AES_256"
                )
                self.key_id = key["KeyId"]
                self.cipher = Fernet(base64.urlsafe_b64encode(key["Plaintext"][:32]))
                self.last_rotation = current_time
                logger.info(f"Encryption key rotated: {self.key_id}")
            else:
                # Load existing key (assume stored in KMS or env for simplicity)
                self.cipher = Fernet(base64.urlsafe_b64encode(settings.encryption_key.encode()[:32]))
            logger.debug("Encryption key loaded or reused")
        except Exception as e:
            logger.error(f"Failed to initialize security service: {e}")
            raise RuntimeError(f"Security initialization failed: {e}")

    def encrypt(self, data: str) -> str:
        """Encrypt data using Fernet symmetric encryption."""
        try:
            self._load_or_rotate_key()  # Check rotation on each use
            encrypted = self.cipher.encrypt(data.encode()).decode()
            logger.debug(f"Data encrypted: {len(data)} chars")
            return encrypted
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise RuntimeError(f"Encryption failed: {e}")

    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt data using Fernet."""
        try:
            self._load_or_rotate_key()
            decrypted = self.cipher.decrypt(encrypted_data.encode()).decode()
            logger.debug(f"Data decrypted: {len(decrypted)} chars")
            return decrypted
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise RuntimeError(f"Decryption failed: {e}")
