import boto3
import httpx
import logging
import subprocess

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

ecr_client = boto3.client("ecr")
s3_client = boto3.client("s3")

DB_REPOS = {
    "pgvector": "pgvector/pgvector",
    "chromadb": "chroma-core/chroma"
}

def lambda_handler(event, context):
    """Update database images from source repositories."""
    for db_type, repo in DB_REPOS.items():
        try:
            resp = httpx.get(f"https://api.github.com/repos/{repo}/releases/latest")
            resp.raise_for_status()
            latest_version = resp.json()["tag_name"]

            try:
                current_version = s3_client.get_object(Bucket="vectordb-versions", Key=f"{db_type}.txt")["Body"].read().decode()
            except s3_client.exceptions.NoSuchKey:
                current_version = "0.0.0"

            if latest_version != current_version:
                build_and_push_image(db_type, latest_version)
                s3_client.put_object(Bucket="vectordb-versions", Key=f"{db_type}.txt", Body=latest_version.encode())
                logger.info(f"Updated {db_type} to {latest_version}")
        except Exception as e:
            logger.error(f"Failed to update image for {db_type}: {e}")

def build_and_push_image(db_type, version):
    """Build and push Docker image."""
    try:
        registry_url = "your-account-id.dkr.ecr.us-east-1.amazonaws.com"
        image_tag = f"{registry_url}/vectordb-{db_type}:{version}"
        subprocess.run(["docker", "build", "-t", image_tag, f"https://github.com/{DB_REPOS[db_type]}.git#{version}"], check=True)
        subprocess.run(["docker", "push", image_tag], check=True)
        logger.debug(f"Built and pushed {image_tag}")
    except subprocess.CalledProcessError as e:
        logger.error(f"Docker operation failed: {e}")
        raise RuntimeError(f"Docker operation failed: {e}")
