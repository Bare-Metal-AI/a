import boto3
import json
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

dynamodb = boto3.client("dynamodb")

def lambda_handler(event, context):
    """Handle edge inference requests."""
    request = event["Records"][0]["cf"]["request"]
    uri = request["uri"]
    tenant_id = request["headers"].get("x-principal", [{"value": "anonymous"}])[0]["value"]
    
    try:
        cache_key = f"edge:{tenant_id}:usage"
        cached = dynamodb.get_item(TableName="VectorDBCache", Key={"CacheKey": {"S": cache_key}})
        if "Item" in cached:
            logger.debug(f"Cache hit for {cache_key}")
            return {
                "status": "200",
                "body": cached["Item"]["Data"]["S"],
                "headers": {"content-type": [{"key": "Content-Type", "value": "application/json"}]}
            }
        
        # Forward to origin if not cached
        logger.debug(f"Cache miss for {cache_key}, forwarding to origin")
        return request
    except Exception as e:
        logger.error(f"Edge inference failed: {e}")
        return request  # Fallback to origin
