import boto3
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

ecr_client = boto3.client("ecr")
ecs_client = boto3.client("ecs")

def lambda_handler(event, context):
    """Fetch and deploy a database image."""
    db_type = event["db_type"]
    try:
        ecr_client.describe_images(repositoryName=f"vectordb-{db_type}", imageIds=[{"imageTag": "latest"}])
        ecs_client.run_task(
            cluster="vectordb-cluster",
            taskDefinition=f"vectordb-{db_type}-task",
            count=1,
            launchType="FARGATE",
            networkConfiguration={
                "awsvpcConfiguration": {
                    "subnets": ["subnet-1"],  # Replace with real subnet
                    "securityGroups": ["sg-1"],  # Replace with real SG
                    "assignPublicIp": "ENABLED"
                }
            }
        )
        logger.info(f"Deployed {db_type} image")
        return {"statusCode": 200, "body": f"Deployed {db_type}"}
    except ecr_client.exceptions.ImageNotFoundException:
        logger.error(f"Image not found for {db_type}")
        return {"statusCode": 400, "body": f"Image for {db_type} not found"}
    except Exception as e:
        logger.error(f"Fetch image failed: {e}")
        return {"statusCode": 500, "body": f"Error: {str(e)}"}
