# VectorDBCloud Service Level Agreement (SLA)

## Uptime Guarantee
- **Target**: 99.9% monthly uptime.
- **Scope**: API availability at `https://api.vectordbcloud.com` across primary (us-east-1) and secondary (us-west-2) regions.
- **Measurement**: Excludes scheduled maintenance (notified 48 hours in advance).

## Failover
- **Mechanism**: Multi-region deployment with primary (us-east-1) and secondary (us-west-2) ECS clusters.
- **Recovery Time Objective (RTO)**: <5 minutes via ALB failover.
- **Recovery Point Objective (RPO)**: <1 hour via S3 backups.

## Support
- **Response Time**: 24/7 support, <1 hour for critical issues (enterprise tier).
- **Contact**: support@vectordbcloud.com
