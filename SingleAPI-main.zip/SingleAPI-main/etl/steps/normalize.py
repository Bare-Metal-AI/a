from .base import ETLStep
from utils.preprocessing import Preprocessor
import logging

logger = logging.getLogger(__name__)

class NormalizeStep(ETLStep):
    """ETL step for normalizing text data."""

    def __init__(self):
        self.preprocessor = Preprocessor()

    async def process(self, data: Dict[str, str]) -> Dict[str, str]:
        """Normalize text in the data."""
        try:
            if "text" in data:
                data["text"] = self.preprocessor.normalize_text(data["text"])
            logger.debug("Normalized text data")
            return data
        except Exception as e:
            logger.error(f"Normalization failed: {e}")
            raise RuntimeError(f"Normalization failed: {e}")
