from .base import ETLStep
from utils.preprocessing import Preprocessor
import logging

logger = logging.getLogger(__name__)

class AnonymizeStep(ETLStep):
    """ETL step for anonymizing text data."""

    def __init__(self):
        self.preprocessor = Preprocessor()

    async def process(self, data: Dict[str, str]) -> Dict[str, str]:
        """Anonymize text in the data."""
        try:
            if "text" in data:
                data["text"] = self.preprocessor.anonymize_text(data["text"])
            logger.debug("Anonymized text data")
            return data
        except Exception as e:
            logger.error(f"Anonymization failed: {e}")
            raise RuntimeError(f"Anonymization failed: {e}")
