import logging
import fireducks.pandas as pd  # Updated
from typing import Dict, Any
import PyPDF2
import docx
import openpyxl
import os

logger = logging.getLogger(__name__)

class ExtractStep:
    """Extract data from files using FireDucks."""

    def __init__(self):
        logger.info("Initialized ExtractStep")

    async def extract(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract data from a file."""
        try:
            if file_type == "pdf":
                with open(file_path, "rb") as f:
                    pdf = PyPDF2.PdfReader(f)
                    text = "".join(page.extract_text() for page in pdf.pages)
            elif file_type == "docx":
                doc = docx.Document(file_path)
                text = "\n".join(para.text for para in doc.paragraphs)
            elif file_type == "xlsx":
                wb = openpyxl.load_workbook(file_path)
                sheet = wb.active
                data = [[cell.value for cell in row] for row in sheet.rows]
                df = pd.DataFrame(data)  # FireDucks DataFrame
                text = df.to_string()
            elif file_type == "csv":
                df = pd.read_csv(file_path)  # FireDucks DataFrame
                text = df.to_string()
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            logger.debug(f"Extracted data from {file_path}: {text[:50]}...")
            return {"content": text, "metadata": {"file_type": file_type, "size": os.path.getsize(file_path)}}
        except Exception as e:
            logger.error(f"Extraction failed for {file_path}: {e}")
            raise RuntimeError(f"Extraction failed: {e}")
