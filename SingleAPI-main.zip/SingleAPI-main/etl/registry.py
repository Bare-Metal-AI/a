from .base import ETLStep
from .steps.normalize import NormalizeStep
from .steps.anonymize import AnonymizeStep
from typing import Dict
import logging

logger = logging.getLogger(__name__)

class ETLRegistry:
    """Registry for ETL steps."""

    def __init__(self):
        self.steps: Dict[str, ETLStep] = {
            "normalize": NormalizeStep(),
            "anonymize": AnonymizeStep(),
        }
        logger.info(f"Initialized ETL registry with {len(self.steps)} steps")

    def get(self, step_name: str) -> ETLStep:
        """Retrieve an ETL step by name."""
        step = self.steps.get(step_name)
        if not step:
            logger.error(f"No ETL step found for: {step_name}")
            raise ValueError(f"Unsupported ETL step: {step_name}")
        logger.debug(f"Retrieved ETL step: {step_name}")
        return step

registry = ETLRegistry()
